// ReTrapper DOM passes: shelf/nav/metadata hiding, content filters, row limits.
(function () {
  'use strict';
  const RT = window.RT;
  if (!RT) return;
  const { HOME, SUBS, CHAN } = RT.SEL;
  const S = () => RT.settings();
  const on = (id) => RT.on(id);
  const $$ = (sel, rootEl) => Array.from((rootEl || document).querySelectorAll(sel));

  function setHide(el, reason, flag, attr) {
    attr = attr || 'data-rt-h';
    const cur = (el.getAttribute(attr) || '').split(' ').filter(Boolean);
    const i = cur.indexOf(reason);
    if (flag && i < 0) cur.push(reason);
    else if (!flag && i >= 0) cur.splice(i, 1);
    else return;
    if (cur.length) el.setAttribute(attr, cur.join(' ')); else el.removeAttribute(attr);
  }
  RT.setHide = setHide;

  // ---- shelves by title ---------------------------------------------------------
  const SHELF_SEL = 'ytd-rich-section-renderer, ytd-shelf-renderer, ytd-horizontal-card-list-renderer, ytd-reel-shelf-renderer';
  const TITLE_RULES = [
    { flag: 'hideTrendingRow', pages: ['home'], re: /trending/i },
    { flag: 'hideTrending', pages: ['home', 'search', 'subs', 'channel'], re: /trending/i },
    { flag: 'hideForYou', pages: ['home', 'search', 'subs', 'channel'], re: /for you|recommended|you might like|picked for you/i },
    { flag: 'hidePeopleAlso', pages: ['search'], re: /people also|related searches|searches related/i },
    { flag: 'hideSearchRecs', pages: ['search'], re: /previously watched|people also watched|latest from|from related searches|for you|recommended|related to your search/i },
    { flag: 'hideSubsRecSections', pages: ['subs'], re: /recommended|suggested|you might like|for you|new to you/i },
    { flag: 'hideChannelRecs', pages: ['channel'], re: /featured channels|related channels|similar channels|other channels|recommended/i },
    { flag: 'hideLatest', pages: ['home', 'subs', 'channel'], re: /^latest\b/i }
  ];
  function shelfTitles(page) {
    const rules = TITLE_RULES.filter((r) => on(r.flag) && r.pages.includes(page));
    $$(SHELF_SEL).forEach((el) => {
      let hide = false;
      if (rules.length) {
        const t = el.querySelector('#title-text, #title, h2, yt-formatted-string.title');
        const title = ((t && t.textContent) || '').trim();
        hide = !!title && rules.some((r) => r.re.test(title));
      }
      setHide(el, 'title', hide);
    });
  }

  // ---- sidebar names ---------------------------------------------------------------
  function navNames() {
    const s = S();
    const secs = new Set(RT.lines(s.navSectionNames).map((x) => x.toLowerCase()));
    if (on('hideExplore')) secs.add('explore');
    if (on('hideMoreFromYT')) secs.add('more from youtube');
    const btns = new Set(RT.lines(s.navButtonNames).map((x) => x.toLowerCase()));
    if (on('hideHelperButtons')) ['settings', 'report history', 'help', 'send feedback'].forEach((x) => btns.add(x));
    $$('ytd-guide-section-renderer').forEach((el) => {
      const t = el.querySelector('#guide-section-title, h3, #header-entry .title');
      const title = ((t && t.textContent) || '').trim().toLowerCase();
      setHide(el, 'navsec', !!title && secs.has(title));
    });
    $$('ytd-guide-entry-renderer, ytd-mini-guide-entry-renderer').forEach((el) => {
      const a = el.querySelector('a[title]');
      const name = ((a && a.getAttribute('title')) || (el.textContent || '')).trim().toLowerCase();
      setHide(el, 'navbtn', !!name && btns.has(name));
    });
  }

  // ---- metadata text (views, dates, subscribers) ----------------------------------------
  const META_SEL = '.inline-metadata-item, #metadata-line span, .yt-content-metadata-view-model-wiz__metadata-text, .ytContentMetadataViewModelMetadataText, ' +
    '#info-strings yt-formatted-string, ytd-watch-info-text span, #owner-sub-count, #video-count';
  const MONTH = '(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\\.?';
  const META_RE = {
    hideViews: /^[\d.,]*\s*[KMB]?\s*(views?|watching)$|^no views$/i,
    hideTimeSince: /\bago$|^(streamed|premiered)\s.*\bago$/i,
    hidePubDate: new RegExp(`^((premiered|streamed|published|started streaming)\\s+)?(on\\s+)?(${MONTH}\\s+\\d{1,2},?\\s+\\d{4}|\\d{1,2}\\s+${MONTH}\\s+\\d{4})$`, 'i'),
    hideSubscribers: /^[\d.,]+\s*[KMB]?\s*subscribers?$/i,
    hideOtherMetrics: /^[\d.,]+\s*[KMB]?\s*(videos?|members?|watching( now)?)$/i
  };
  const isSep = (el) => el && (/^[•·|]$/.test((el.textContent || '').trim()) || /delimiter/i.test(el.className || ''));
  function metadata() {
    const flags = Object.keys(META_RE).filter((f) => f !== 'hideViews' && on(f));
    const seps = new Set();
    $$(META_SEL).forEach((el) => {
      if (el.children.length > 2) return;
      const txt = (el.textContent || '').trim();
      // views have two switches: one for the video page's own info line, one for video cards everywhere else
      const viewsOn = on(el.closest('ytd-watch-info-text, #info-strings, ytd-video-primary-info-renderer') ? 'hideViews' : 'hideCardViews');
      // newer cards show just "24K": the word "views" may be only in the label (home/subs), or nowhere at all
      // (search results), so a bare count in a card's own metadata line is taken as the view count too
      const viewsOnly = viewsOn && /^[\d.,]+\s*[KMB]?$/i.test(txt) && (
        /\b(views?|watching)\b/i.test(el.getAttribute('aria-label') || '')
        || (!el.hasAttribute('data-rt-orig') && el.matches('.inline-metadata-item, #metadata-line span')));
      const hit = !!txt && (viewsOnly || (viewsOn && META_RE.hideViews.test(txt)) || flags.some((f) => META_RE[f].test(txt)));
      setHide(el, 'meta', hit);
      if (!hit) return;
      [el.previousElementSibling, el.nextElementSibling].forEach((sib) => {
        if (isSep(sib) || (sib === el.previousElementSibling && viewsOnly && /LeadingIcon/.test(String((sib && sib.className) || '')))) { seps.add(sib); setHide(sib, 'metasep', true); }
      });
    });
    $$('[data-rt-h~="metasep"]').forEach((sib) => { if (!seps.has(sib)) setHide(sib, 'metasep', false); });
  }

  // ---- content filters -------------------------------------------------------------------------
  const CARD_SEL = 'ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer, ytd-grid-video-renderer, yt-lockup-view-model, ytd-reel-item-renderer, ytm-shorts-lockup-view-model';
  const PARENTAL = ['porn', 'xxx', 'nsfw', 'nude', 'nudes', 'sex tape', 'onlyfans', 'hentai', 'beheading', '18+', 'uncensored', 'erotic', 'fetish'];
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  let C = { ver: -1 };
  function regexes(lines) {
    const out = [];
    lines.forEach((l) => {
      const m = l.match(/^\/(.+)\/([gimsuy]*)$/);
      try { out.push(m ? new RegExp(m[1], m[2].replace('g', '')) : new RegExp(esc(l), 'i')); } catch (e) { /* skip bad regex */ }
    });
    return out;
  }
  const vidId = (x) => { const m = x.match(/(?:[?&]v=|youtu\.be\/|shorts\/|^)([\w-]{11})(?:[&?/]|$)/); return m ? m[1] : x; };
  const chanKey = (x) => x.toLowerCase().replace(/^.*youtube\.com\//, '').replace(/^(channel|c|user)\//, '').replace(/^@/, '').replace(/\/$/, '');
  function compile() {
    const s = S(), L = RT.lines, lc = (a) => a.map((x) => x.toLowerCase());
    C = {
      ver: RT.version(),
      videos: new Set(L(s.blockVideos).map(vidId)),
      channels: new Set(L(s.blockChannels).map(chanKey)),
      chanIds: new Set(lc(L(s.filterChannelIds))),
      chanWords: lc(L(s.filterChannelKeywords)),
      words: lc(L(s.blockKeywords)),
      titleWords: lc(L(s.filterVideoKeywords)),
      topics: lc(L(s.blockTopics)),
      muted: lc(L(s.muteTopics)),
      re: regexes(L(s.filterRegex)),
      recWords: lc(L(s.recKeywords)).concat(lc(L(s.recTopics))),
      recChans: new Set(L(s.recBlockedChannels).map(chanKey)),
      subsWords: lc(L(s.subsKeywords)),
      chanPageWords: lc(L(s.channelKeywords)),
      parental: PARENTAL.concat(lc(L(s.parentalWords))).map((w) => new RegExp('(^|[^a-z0-9])' + esc(w.toLowerCase()) + '([^a-z0-9]|$)', 'i')),
      cAuthors: new Set(L(s.blockCommentAuthors).map(chanKey)),
      cWords: lc(L(s.commentKeywords)),
      cRe: regexes(L(s.commentRegex))
    };
  }
  const text1 = (el, sel) => { const n = el.querySelector(sel); return n ? (n.textContent || '').trim() : ''; };
  function cardInfo(card) {
    const link = card.querySelector('a[href*="/watch?v="], a[href*="/shorts/"]');
    const href = link ? link.getAttribute('href') || '' : '';
    const chLink = card.querySelector('a[href^="/@"], a[href^="/channel/"], a[href^="/c/"], a[href^="/user/"]');
    const chHref = chLink ? chLink.getAttribute('href') || '' : '';
    let title = text1(card, '#video-title, .yt-lockup-metadata-view-model-wiz__title, .ytLockupMetadataViewModelTitle, h3');
    if (!title && link) title = link.getAttribute('title') || link.getAttribute('aria-label') || '';
    const badges = (text1(card, 'ytd-thumbnail-overlay-time-status-renderer, .badge-shape-wiz__text, .yt-badge-shape__text') || '');
    const all = (card.textContent || '').toLowerCase();
    const dur = (badges.match(/(\d+):(\d{2})(?::(\d{2}))?/) || []);
    const secs = dur.length ? (dur[3] != null ? +dur[1] * 3600 + +dur[2] * 60 + +dur[3] : +dur[1] * 60 + +dur[2]) : 0;
    return {
      href, id: (href.match(/(?:[?&]v=|shorts\/)([\w-]{11})/) || [])[1] || '',
      title: title.toLowerCase(), channel: ((chLink && chLink.textContent) || text1(card, '#channel-name, ytd-channel-name')).trim().toLowerCase(),
      chKey: chanKey(decodeURIComponent(chHref)), chId: (chHref.match(/channel\/(UC[\w-]+)/) || [])[1] || '',
      snippet: text1(card, '.metadata-snippet-text, #description-text').toLowerCase(), secs, all,
      live: !!card.querySelector('[overlay-style="LIVE"], .badge-style-type-live-now') || /\blive\b/.test(badges.toLowerCase()),
      upcoming: !!card.querySelector('[overlay-style="UPCOMING"]') || /premieres|scheduled for|upcoming/.test(all),
      members: /members[ -]only|members[ -]first|members[ -]exclusive|membership perk/.test(all), mix: /start_radio|[?&]list=RD/.test(href + (card.innerHTML.length < 20000 ? card.innerHTML.slice(0, 4000) : ''))
    };
  }
  const has = (list, ...hay) => list.some((w) => hay.some((h) => h && h.indexOf(w) >= 0));
  function judge(i, page) {
    const s = S();
    const ctx = page === 'watch' ? 'rec' : 'feed';
    const lists = on('filtersEnabled') && (ctx === 'rec' ? on('filterRecsOn') : on('filterFeeds'));
    let hide = false, mute = false;
    const why = [];
    if (lists) {
      if (on('matchVideos')) {
        if (i.id && C.videos.has(i.id)) hide = true;
        if (has(C.titleWords, i.title) || has(C.words, i.title, i.channel, i.snippet)) hide = true;
        if (C.re.some((r) => r.test(i.title) || r.test(i.channel))) hide = true;
      }
      if (on('matchChannels')) {
        if (i.chKey && (C.channels.has(i.chKey) || C.channels.has(i.channel))) hide = true;
        if (i.chId && C.chanIds.has(i.chId.toLowerCase())) hide = true;
        if (has(C.chanWords, i.channel)) hide = true;
        if ((page === 'home' || page === 'watch') && i.chKey && C.recChans.has(i.chKey)) hide = true;
      }
      if (on('matchTopics') && has(C.topics, i.title, i.channel, i.snippet)) hide = true;
      if (has(C.muted, i.title, i.channel, i.snippet)) mute = true;
      if ((page === 'home' || page === 'watch') && has(C.recWords, i.title, i.channel, i.snippet)) hide = true;
      if (page === 'subs' && has(C.subsWords, i.title, i.channel)) hide = true;
      if (page === 'channel' && has(C.chanPageWords, i.title)) hide = true;
    }
    if (on('parentalFilter') && C.parental.some((r) => r.test(i.title) || r.test(i.channel))) hide = true;
    if (i.secs) {
      if (s.minDurationMin > 0 && i.secs < s.minDurationMin * 60) hide = true;
      if (s.maxDurationMin > 0 && i.secs > s.maxDurationMin * 60) hide = true;
    }
    if (on('hideLiveStreams') && i.live) { hide = true; why.push('liveStreams'); }
    if (on('hidePremieres') && i.upcoming) { hide = true; why.push('premieres'); }
    if (on('hideMembersOnly') && i.members) { hide = true; why.push('membersOnly'); }
    if (on('hideMixes') && i.mix) { hide = true; why.push('mixes'); }
    if (hide && !why.length) why.push('filters/keywords/duration');
    return { hide, mute, why: why.join(',') };
  }
  function cards(page) {
    if (page === 'other' || page === 'shorts' || page === 'embed') return;
    $$(CARD_SEL).forEach((card) => {
      if (card.parentElement && card.parentElement.closest(CARD_SEL)) return;
      const first = card.querySelector('a[href*="/watch?v="], a[href*="/shorts/"]');
      const sig = RT.version() + '|' + (first ? first.getAttribute('href') : '');
      if (card.__rtSig === sig) return;
      card.__rtSig = sig;
      const r = judge(cardInfo(card), page);
      setHide(card, 'filter', r.hide);
      if (r.hide) card.setAttribute('data-rt-why', r.why); else card.removeAttribute('data-rt-why');
      if (r.mute) card.setAttribute('data-rt-m', '1'); else card.removeAttribute('data-rt-m');
    });
  }

  // ---- comments ----------------------------------------------------------------------------------------
  const SPAM = /sub4sub|check out my|follow me|giveaway|whatsapp|telegram|promo|dm me|click my|my channel|subscribe to my/i;
  function comments(page) {
    if (page !== 'watch') return;
    const kinds = (S().commentFilters || []);
    $$('ytd-comment-thread-renderer').forEach((el) => {
      const body = text1(el, '#content-text');
      const sig = RT.version() + '|' + body.length;
      if (el.__rtSig === sig) return;
      el.__rtSig = sig;
      const author = text1(el, '#author-text').toLowerCase();
      const t = body.toLowerCase();
      let hide = false;
      if (on('matchComments')) {
        if (on('filtersEnabled')) {
          if (C.cAuthors.has(chanKey(author)) || C.cAuthors.has(author)) hide = true;
          if (has(C.cWords, t) || C.cRe.some((r) => r.test(body))) hide = true;
        }
        if (kinds.includes('links') && /https?:\/\/|www\./i.test(body)) hide = true;
        if (kinds.includes('spam') && SPAM.test(body)) hide = true;
        const letters = body.replace(/[^A-Za-z]/g, '');
        if (kinds.includes('caps') && letters.length > 12 && letters.replace(/[^A-Z]/g, '').length / letters.length > 0.7) hide = true;
        if (kinds.includes('emoji') && body && !/[\p{L}\p{N}]/u.test(body)) hide = true;
        if (kinds.includes('short') && body && body.length < 6) hide = true;
      }
      setHide(el, 'filter', hide);
    });
  }

  // ---- rows / columns ------------------------------------------------------------------------------------
  function limitRows(page) {
    const rows = on('homeFirstRowOnly') ? 1 : on('homeExtraRows') ? Math.max(1, S().homeMaxRows | 0) : 0;
    const items = $$(`${HOME} ytd-rich-grid-renderer ytd-rich-item-renderer`);
    if (!rows || page !== 'home') { items.forEach((i) => setHide(i, 'rows', false)); return; }
    const grid = document.querySelector(`${HOME} ytd-rich-grid-renderer`);
    const cols = (grid && parseInt(getComputedStyle(grid).getPropertyValue('--ytd-rich-grid-items-per-row'), 10)) || 4;
    let n = 0;
    items.forEach((it) => {
      const reasons = (it.getAttribute('data-rt-h') || '').split(' ').filter((r) => r && r !== 'rows');
      const other = reasons.length > 0 || it.style.display === 'none';
      if (!other) n++;
      setHide(it, 'rows', !other && n > rows * cols);
    });
  }
  function columns() {
    const s = S(), list = on('legacyListViews') ? 1 : 0;
    [[HOME, Math.max(1, Math.min(7, +s.gridColumns || 6))], [SUBS, +s.subsColumns || list], [CHAN, (on('customChannelColumns') ? Math.max(1, Math.min(7, +s.channelSearchColumns || 4)) : 0) || +s.channelColumns || list]].forEach(([scope, n]) => {
      $$(`${scope} ytd-rich-grid-renderer`).forEach((g) => {
        if (n) { g.style.setProperty('--ytd-rich-grid-items-per-row', n, 'important'); g.setAttribute('data-rt-cols', '1'); }
        else if (g.hasAttribute('data-rt-cols')) { g.style.removeProperty('--ytd-rich-grid-items-per-row'); g.removeAttribute('data-rt-cols'); }
      });
    });
  }

  // The Home "videos per row" slider also drives the Search page and channel search.
  // Items that render with no height (empty ad slots and the like) still take a grid cell and leave a
  // blank gap. Mark ones that stay empty across two checks so the grid closes up around them.
  const emptySeen = new WeakMap();
  function pruneEmpty() {
    if (!/^(home|subscriptions)$/.test((document.querySelector('ytd-browse:not([hidden])') || {}).getAttribute ? (document.querySelector('ytd-browse:not([hidden])').getAttribute('page-subtype') || '') : '')) return;
    $$('ytd-browse:not([hidden]) ytd-rich-grid-renderer > #contents > ytd-rich-item-renderer, ytd-browse:not([hidden]) ytd-rich-grid-renderer > #contents > ytd-rich-section-renderer').forEach((it) => {
      // Anything holding a real video is never "empty" (a shelf can be 0px tall while it loads), and a
      // mark put on it earlier is lifted again.
      if (it.querySelector('a[href*="/watch?v="], a[href*="/shorts/"], yt-lockup-view-model')) {
        if (it.hasAttribute('data-rt-empty')) it.removeAttribute('data-rt-empty');
        emptySeen.delete(it);
        return;
      }
      // A block with real text in it (the "Latest" heading on Subscriptions, say) is not an empty slot: it is shown,
      // and a mark put on it while it was still loading is lifted again.
      if (it.tagName === 'YTD-RICH-SECTION-RENDERER' && it.querySelector('h2, #title, #title-text') && (it.textContent || '').replace(/\s+/g, '').length > 2 && !it.hasAttribute('data-rt-h')) {
        if (it.hasAttribute('data-rt-empty')) it.removeAttribute('data-rt-empty');
        emptySeen.delete(it);
        return;
      }
      if (it.hasAttribute('data-rt-empty') || it.hasAttribute('data-rt-h')) return;
      const r = it.getBoundingClientRect();
      const cs = getComputedStyle(it);
      if (cs.display === 'none') return;
      if (r.height < 4 || cs.visibility === 'hidden') { const n = (emptySeen.get(it) || 0) + 1; emptySeen.set(it, n); if (n >= 2) it.setAttribute('data-rt-empty', '1'); }
      else emptySeen.delete(it);
    });
  }
  setInterval(() => { try { pruneEmpty(); } catch (e) { /* ignore */ } }, 1200);

  // Empty full-width placeholders (a promoted-video slot with nothing in it, say) would force a new grid row
  // and split one batch of results from the next, so they are taken out of the grid flow.
  function searchGaps(active) {
    $$('[data-rt-empty]').forEach((e) => { if (!active) e.removeAttribute('data-rt-empty'); });
    if (!active) return;
    $$('ytd-search ytd-item-section-renderer > #contents > :not(ytd-video-renderer):not(yt-lockup-view-model), ytd-search ytd-section-list-renderer > #contents > :not(ytd-item-section-renderer):not(ytd-continuation-item-renderer)').forEach((e) => {
      const blank = !(e.textContent || '').trim() && !e.querySelector('a, img, video, canvas, iframe, yt-img-shadow');
      const flat = e.hasAttribute('data-rt-empty') ? blank : (blank && e.getBoundingClientRect().height < 2);
      if (flat) { if (!e.hasAttribute('data-rt-empty')) e.setAttribute('data-rt-empty', '1'); } else e.removeAttribute('data-rt-empty');
    });
  }
  function searchGrid() {
    const s = S(), root = document.documentElement;
    searchGaps(RT.page() === 'search' && on('searchGrid'));
    const n = Math.max(1, Math.min(7, +s.gridColumns || 6));
    if (n && RT.page() === 'search' && on('searchGrid')) {
      if (root.getAttribute('data-rt-sgrid') !== String(n)) root.setAttribute('data-rt-sgrid', String(n));
      root.style.setProperty('--rt-search-cols', String(n));
    } else if (root.hasAttribute('data-rt-sgrid')) {
      root.removeAttribute('data-rt-sgrid'); root.style.removeProperty('--rt-search-cols');
    }
  }


  // ---- watched videos -----------------------------------------------------------------------------
  // How much of a card's video has been watched (0-100), read from whichever progress marker YouTube
  // uses: the classic resume-playback bar, the newer progress-bar view model, or a "Watched" badge.
  const PCT = /(-?\d+(?:\.\d+)?)\s*%/;
  function watchedPct(card) {
    let best = 0;
    const take = (n) => { if (n > best) best = n; };
    card.querySelectorAll('ytd-thumbnail-overlay-resume-playback-renderer #progress, [class*="ProgressBar"] [style*="width"], [class*="progress-bar"] [style*="width"], [class*="WatchedProgress"][style*="width"], [class*="ProgressBarSegment"][style*="width"], [class*="ResumePlaybackProgress"][style*="width"]').forEach((e) => {
      const m = (e.getAttribute('style') || '').match(/width:\s*([\d.]+)%/);
      if (m) take(+m[1]);
    });
    if (!best && card.querySelector('ytd-thumbnail-overlay-resume-playback-renderer, yt-thumbnail-overlay-progress-bar-view-model, [class*="ThumbnailOverlayProgressBar"], [class*="ResumePlayback"]')) take(1);
    if (best < 100) {
      card.querySelectorAll('ytd-thumbnail-overlay-playback-status-renderer, [class*="ThumbnailBadge"], [class*="thumbnail-badge"], badge-shape, [class*="OverlayBadge"]').forEach((e) => {
        if (/^\s*watched\s*$/i.test(e.textContent || '')) take(100);
      });
    }
    return best;
  }
  const WATCHED_SEL = 'ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer, ytd-compact-video-renderer, yt-lockup-view-model';
  function watchedPass(page) {
    const scoped = on('hideWatched') && ['home', 'watch'].includes(page);
    const channelOnly = page === 'channel' && on('channelHideWatched');
    const subsOnly = page === 'subs' && on('subsHideWatched');
    const searchOnly = page === 'search' && on('searchHideWatched');
    if (!scoped && !channelOnly && !subsOnly && !searchOnly) {
      $$('[data-rt-h~="watched"]').forEach((e) => setHide(e, 'watched', false));
      return;
    }
    const min = Math.max(1, Math.min(100, +(page === 'subs' ? S().subsWatchedMinPct : S().watchedMinPct) || 1));
    $$(WATCHED_SEL).forEach((c) => {
      if (c.closest('#rt-chsearch, #watch-later-shelf-section, ytd-playlist-panel-renderer, ytd-playlist-video-list-renderer')) return;
      if (page === 'watch' && !c.closest('ytd-watch-next-secondary-results-renderer, #related, #secondary')) return;
      // A lockup inside a rich item: hide the rich item so no empty slot is left behind.
      const target = c.tagName === 'YT-LOCKUP-VIEW-MODEL' ? (c.closest('ytd-rich-item-renderer, ytd-compact-video-renderer, ytd-video-renderer') || c) : c;
      if (target !== c && target.tagName === 'YTD-RICH-ITEM-RENDERER' && !c.isConnected) return;
      const pct = watchedPct(target);
      setHide(target, 'watched', pct >= min);
      if (pct >= min) target.setAttribute('data-rt-wp', String(Math.round(pct))); else target.removeAttribute('data-rt-wp');
    });
  }

  // Videos that are in Watch later are hidden from the Home feed, so adding one feels like moving it to the shelf.
  function watchLaterPass(page) {
    const ids = RT.wlIds;
    if (page !== 'home' || S().hideWatchLaterHome === false || !ids || !ids.size) {
      $$('[data-rt-h~="wl"]').forEach((e) => setHide(e, 'wl', false));
      return;
    }
    $$(WATCHED_SEL).forEach((c) => {
      if (c.closest('#rt-chsearch, #watch-later-shelf-section')) return;
      const a = c.querySelector('a[href*="/watch?v="]');
      const m = a && (a.getAttribute('href') || '').match(/[?&]v=([\w-]{11})/);
      const target = c.tagName === 'YT-LOCKUP-VIEW-MODEL' ? (c.closest('ytd-rich-item-renderer') || c) : c;
      setHide(target, 'wl', !!(m && ids.has(m[1])));
    });
  }

  // ---- Shorts: hide every Short wherever it appears (backs up the CSS rules, which can miss renamed markup) ------------------
  const SHORT_HAS = 'a[href^="/shorts/"], a[href*="youtube.com/shorts/"], ytd-thumbnail-overlay-time-status-renderer[overlay-style="SHORTS"], ytm-shorts-lockup-view-model, ytm-shorts-lockup-view-model-v2, ytd-reel-item-renderer';
  const SHORT_CONT = 'ytd-rich-section-renderer, ytd-shelf-renderer, grid-shelf-view-model, ytd-reel-shelf-renderer, ytd-item-section-renderer, ytd-horizontal-card-list-renderer';
  const SHORT_ANY = CARD_SEL + ', ytd-playlist-video-renderer, ytd-playlist-panel-video-renderer, ' + SHORT_CONT;
  function shortsScope(page) {
    if (on('hideShortsAll')) return true;
    if (page === 'home') return on('hideShortsHome');
    if (page === 'subs') return on('hideShortsSubs');
    if (page === 'search') return on('hideShortsSearch');
    if (page === 'watch') return on('hideShortsRecs') || on('hideShortsSuggestions');
    return on('hideShortsSections');
  }
  function shortsPass(page) {
    const active = page !== 'shorts' && page !== 'embed' && page !== 'other' && shortsScope(page);
    if (!active) { $$('[data-rt-h~="short"]').forEach((e) => setHide(e, 'short', false)); return; }
    $$(SHORT_ANY).forEach((el) => {
      if (el.closest('#rt-chsearch, #watch-later-shelf-section')) return;
      const tag = el.tagName;
      let isShort = false;
      if (tag === 'YTD-REEL-SHELF-RENDERER' || tag === 'YTM-SHORTS-LOCKUP-VIEW-MODEL' || tag === 'YTM-SHORTS-LOCKUP-VIEW-MODEL-V2' || tag === 'YTD-REEL-ITEM-RENDERER') isShort = true;
      else if (el.matches(SHORT_CONT)) {
        // A shelf or section counts as Shorts if it is titled "Shorts" or holds only Shorts.
        const head = el.tagName === 'YTD-ITEM-SECTION-RENDERER' ? null : el.querySelector('#title, #title-text, h2, yt-formatted-string.ytd-shelf-renderer');
        const t = head ? (head.textContent || '').trim() : '';
        if (/^shorts\b/i.test(t) || /\bshorts\b.*\bremix/i.test(t) || el.querySelector('ytd-rich-shelf-renderer[is-shorts], ytd-reel-shelf-renderer')) isShort = true;
        else if (el.querySelector(SHORT_HAS) && !el.querySelector('a[href*="/watch?v="], a[href*="/playlist?list="]')) isShort = true;
      } else {
        if (el.parentElement && el.parentElement.closest(CARD_SEL)) return;
        isShort = !!el.querySelector(SHORT_HAS);
      }
      setHide(el, 'short', isShort);
    });
  }

  // ---- Memberships: hide shelves and sections about channel memberships, wherever they appear ------------------------------------
  const MEMBER_CONT = 'ytd-rich-section-renderer, ytd-shelf-renderer, grid-shelf-view-model, ytd-horizontal-card-list-renderer, ytd-channel-featured-content-renderer, ytd-guide-section-renderer, ytd-engagement-panel-section-list-renderer, ytd-mini-guide-entry-renderer, ytd-guide-entry-renderer';
  const MEMBER_RE = /^(members?(hip)?s?|members?[- ]?only( content| videos?)?|members?[- ]first|join( this channel)?|channel memberships?|from members|perks)$|members?[- ]only|membership/i;
  function membersPass() {
    const sel = MEMBER_CONT;
    if (!on('hideMembersOnly')) { $$('[data-rt-h~="member"]').forEach((e) => setHide(e, 'member', false)); return; }
    $$(sel).forEach((el) => {
      if (el.closest('#rt-chsearch, #watch-later-shelf-section')) return;
      let t = '';
      if (/GUIDE/.test(el.tagName)) { const a = el.querySelector('a[href*="/membership"], a[title*="Membership" i]'); t = a ? 'membership' : ''; }
      else { const head = el.querySelector('#title, #title-text, h2, yt-formatted-string.ytd-shelf-renderer'); t = head ? (head.textContent || '').trim() : ''; }
      setHide(el, 'member', t.length < 80 && MEMBER_RE.test(t));
    });
  }

  // ---- Home: YouTube featured / event promotion sections ---------------------------------------------------------------------------
  const FEATURED_RE = /youtube featured|^\s*your home for\b|sunday ticket|\bfeatured by youtube\b|^\s*(the )?official .{0,40} (home|hub)\b/i;
  function featuredPass(page) {
    const active = page === 'home' && on('hideFeaturedHome');
    if (!active) { $$('[data-rt-h~="featured"]').forEach((e) => setHide(e, 'featured', false)); return; }
    $$('ytd-browse[page-subtype="home"] ytd-rich-section-renderer').forEach((el) => {
      if (el.closest('#watch-later-shelf-section')) return;
      const head = el.querySelector('#title, #title-text, h2');
      const t = head ? (head.textContent || '').replace(/\s+/g, ' ').trim() : '';
      const all = (el.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 400);
      setHide(el, 'featured', FEATURED_RE.test(t) || /youtube featured/i.test(all) || /sunday ticket/i.test(all));
    });
  }

  // ---- Search: the "Watch again" shelf is always hidden (no setting) ---------------------------------------------------------
  const WA_SHELVES = 'ytd-shelf-renderer, ytd-horizontal-card-list-renderer, grid-shelf-view-model, ytd-vertical-list-renderer, ytd-rich-section-renderer, ytd-reel-shelf-renderer';
  function watchAgainPass(page) {
    $$('[data-rt-h~="wagain"]').forEach((e) => { if (page !== 'search') setHide(e, 'wagain', false); });
    if (page !== 'search') return;
    $$('ytd-search h2, ytd-search #title, ytd-search #title-text, ytd-search [role="heading"], ytd-search yt-formatted-string.ytd-shelf-renderer, ytd-search .yt-core-attributed-string').forEach((h) => {
      if (!/^\s*(watch again|latest from\s.+)\s*$/i.test((h.textContent || '').trim())) return;
      let box = h.closest(WA_SHELVES);
      if (!box) {
        // Newer markup: climb to the block that sits directly in the results list.
        box = h;
        for (let i = 0; i < 8 && box.parentElement && !(box.parentElement.id === 'contents' && box.parentElement.parentElement && /ITEM-SECTION|SECTION-LIST/.test(box.parentElement.parentElement.tagName)); i++) box = box.parentElement;
        if (!box.parentElement || box.parentElement.id !== 'contents') return;
      }
      // Safety: never hide a block that holds the normal results.
      if (box.querySelectorAll('ytd-video-renderer').length > 6) return;
      setHide(box, 'wagain', true);
    });
  }

  // ---- misc -------------------------------------------------------------------------------------------------
  function misc(page) {
    if (on('removeNotifications') && /^\(\d+\)\s/.test(document.title)) document.title = document.title.replace(/^\(\d+\)\s/, '');
    // Shorts links -> normal watch links
    $$('a[href^="/shorts/"], a[data-rt-short]').forEach((a) => {
      const orig = a.getAttribute('data-rt-short');
      if (on('shortsAsVideos') || on('hideShortsAll')) {
        const m = (orig || a.getAttribute('href')).match(/^\/shorts\/([\w-]{11})/);
        if (m) { if (!orig) a.setAttribute('data-rt-short', a.getAttribute('href')); a.setAttribute('href', '/watch?v=' + m[1]); }
      } else if (orig) { a.setAttribute('href', orig); a.removeAttribute('data-rt-short'); }
    });
    if (on('sidebarAutoCollapse') && !RT._collapsed) {
      const drawer = document.querySelector('tp-yt-app-drawer[opened]');
      const btn = document.querySelector('#guide-button button, button#guide-button');
      if (drawer && btn) { RT._collapsed = true; btn.click(); }
    }
  }

  // ---- hype / trending badges (every page, not just Home) -----------------------------------------
  // "#17 hyped" is rendered inline in the metadata row on channel pages (sharing the line with views and
  // date) and as its own badge element elsewhere. Hide the badge piece and its separator but keep views/date.
  function rowChildOf(el, row) { let n = el; while (n.parentElement && n.parentElement !== row) n = n.parentElement; return n; }
  function badgePass() {
    if (!on('hideBadges')) {
      $$('[data-rt-badge-hidden]').forEach((e) => { e.style.display = ''; e.removeAttribute('data-rt-badge-hidden'); });
      return;
    }
    const hideOne = (el) => {
      if (!el || el.hasAttribute('data-rt-badge-hidden')) return;
      el.style.display = 'none'; el.setAttribute('data-rt-badge-hidden', '1');
      const prev = el.previousElementSibling;
      if (prev && /Delimiter/i.test(prev.className || '') && !prev.hasAttribute('data-rt-badge-hidden')) {
        prev.style.display = 'none'; prev.setAttribute('data-rt-badge-hidden', '1');
      }
    };
    const targets = new Set();
    const hypedRows = new Set();
    $$('.ytContentMetadataViewModelBadge').forEach((b) => targets.add(b)); // trending/hype metadata badge
    $$('.ytContentMetadataViewModelMetadataRow span, .ytContentMetadataViewModelMetadataRow badge-shape').forEach((el) => {
      const t = (el.textContent || '').trim();
      if (t.length <= 24 && /\bhyped\b/i.test(t)) { targets.add(el); const r = el.closest('.ytContentMetadataViewModelMetadataRow'); if (r) hypedRows.add(r); }
    });
    // a bare rank like "#17" only when its row also carries a hyped badge (avoids touching unrelated text)
    hypedRows.forEach((r) => { $$('span, badge-shape', r).forEach((sp) => { if (/^#\d+$/.test((sp.textContent || '').trim())) targets.add(sp); }); });
    targets.forEach((badge) => {
      const row = badge.closest('.ytContentMetadataViewModelMetadataRow');
      if (row && row.textContent.trim() === (badge.textContent || '').trim()) {
        if (!row.hasAttribute('data-rt-badge-hidden')) { row.style.display = 'none'; row.setAttribute('data-rt-badge-hidden', '1'); }
      } else {
        hideOne(row ? rowChildOf(badge, row) : badge);
      }
    });
  }

  RT.runDom = function () {
    const page = RT.page();
    if (C.ver !== RT.version()) compile();
    shelfTitles(page);
    navNames();
    metadata();
    cards(page);
    comments(page);
    limitRows(page);
    columns();
    searchGrid();
    watchedPass(page);
    badgePass();
    watchLaterPass(page);
    shortsPass(page);
    membersPass();
    featuredPass(page);
    watchAgainPass(page);
    misc(page);
  };
  RT.cardInfo = cardInfo;
  RT.CARD_SEL = CARD_SEL;
})();
