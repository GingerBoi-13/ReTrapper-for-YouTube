const RT = window.RT;
const $ = (id) => document.getElementById(id);
let S = RT.defaults();
const save = (obj) => {
  // "Hide thumbnails" is one global setting; keep the shelf's legacy key in step with it.
  if ('thumbsHideAll' in obj) obj.hideThumbnails = !!obj.thumbsHideAll;
  if ('hideThumbnails' in obj && !('thumbsHideAll' in obj)) obj.thumbsHideAll = !!obj.hideThumbnails;
  return chrome.storage.local.set(obj);
};
const el = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };

// ---- section dropdown ---------------------------------------------------------
const LAST_KEY = 'retrapperSection';
let current = 'home';
try { current = localStorage.getItem(LAST_KEY) || 'home'; } catch (e) { /* ignore */ }
if (!RT.sectionById(current) || RT.sectionById(current).settings) current = 'home';
let settingsMode = false, mainId = current;
const menu = $('secMenu'), secBtn = $('secBtn');

function buildMenu() {
  menu.textContent = '';
  const order = ['password', 'backup', 'access', 'pageorder', 'report'];
  let list = RT.SECTIONS.filter((s) => !!s.settings === settingsMode && !s.hiddenFromMenu);
  if (settingsMode) list.sort((a, b) => order.indexOf(a.id) - order.indexOf(b.id));
  else list = RT.orderedIds(S.pageOrder).map((id) => RT.sectionById(id));
  list.forEach((s) => {
    const b = el('button', s.id === current ? 'active' : '', s.title);
    b.type = 'button'; b.setAttribute('role', 'option'); b.dataset.id = s.id;
    b.addEventListener('click', () => { closeMenu(); showSection(s.id, true); });
    menu.appendChild(b);
  });
}
function openMenu() {
  buildMenu(); menu.hidden = false; secBtn.setAttribute('aria-expanded', 'true');
  const a = menu.querySelector('.active'); if (a) { a.focus(); a.scrollIntoView({ block: 'center' }); }
}
function closeMenu() { menu.hidden = true; secBtn.setAttribute('aria-expanded', 'false'); }
secBtn.addEventListener('click', () => (menu.hidden ? openMenu() : closeMenu()));
document.addEventListener('click', (e) => { if (!menu.hidden && !menu.contains(e.target) && !secBtn.contains(e.target)) closeMenu(); });
document.addEventListener('keydown', (e) => {
  if (menu.hidden) return;
  const items = Array.from(menu.querySelectorAll('button')), i = items.indexOf(document.activeElement);
  if (e.key === 'Escape') { closeMenu(); secBtn.focus(); }
  else if (e.key === 'ArrowDown') { e.preventDefault(); (items[i + 1] || items[0]).focus(); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); (items[i - 1] || items[items.length - 1]).focus(); }
  else if (e.key === 'Home') { e.preventDefault(); items[0].focus(); }
  else if (e.key === 'End') { e.preventDefault(); items[items.length - 1].focus(); }
});

// ---- rows ------------------------------------------------------------------------
const rowsOnPage = [];
window.__rtRows = () => rowsOnPage; // lets developer tools read the rows
const visible = (it) => {
  if (!it.showIf) return true;
  if (Array.isArray(it.showIf)) return S[it.showIf[0]] === it.showIf[1];
  return !!S[it.showIf];
};
function refreshVisibility() { rowsOnPage.forEach((r) => { r.el.hidden = !visible(r.it); }); }
function set(id, v) { S[id] = v; save({ [id]: v }); refreshVisibility(); }

function label(it, row) {
  const wrap = el('div', 'lbl');
  wrap.appendChild(el('span', '', it.label));
  if (it.alts && it.alts.length) wrap.appendChild(el('span', 'alts', 'Also: ' + it.alts.join(' · ')));
  if (it.hint) wrap.appendChild(el('span', 'hint', it.hint));
  row.appendChild(wrap);
  return wrap;
}
function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

const builders = {
  toggle(it) {
    const row = el('div', 'row'); label(it, row);
    const sw = el('label', 'switch'); const inp = el('input'); inp.type = 'checkbox'; inp.checked = !!S[it.id];
    inp.addEventListener('change', () => set(it.id, inp.checked));
    sw.append(inp, el('span', 'slider')); row.appendChild(sw);
    return row;
  },
  select(it) {
    const row = el('div', 'row'); label(it, row);
    const sel = el('select');
    it.options.forEach(([v, l]) => { const o = el('option', '', l); o.value = v; sel.appendChild(o); });
    sel.value = String(S[it.id]);
    sel.addEventListener('change', () => set(it.id, sel.value));
    row.appendChild(sel);
    return row;
  },
  range(it) {
    const row = el('div', 'row'); label(it, row);
    const box = el('div'); box.style.cssText = 'display:flex;align-items:center;gap:6px';
    const r = el('input'); r.type = 'range'; r.min = it.min; r.max = it.max; r.step = it.step; r.value = S[it.id];
    const v = el('span', 'val', S[it.id] + (it.unit || ''));
    r.addEventListener('input', () => { v.textContent = r.value + (it.unit || ''); set(it.id, +r.value); });
    r.addEventListener('dblclick', () => { r.value = it.def; v.textContent = it.def + (it.unit || ''); set(it.id, it.def); });
    box.append(r, v); row.appendChild(box);
    return row;
  },
  number(it) {
    const row = el('div', 'row'); label(it, row);
    const n = el('input'); n.type = 'number'; n.min = it.min; if (it.max != null) n.max = it.max; n.value = S[it.id];
    n.addEventListener('change', () => { let x = parseInt(n.value, 10); if (isNaN(x)) x = it.def; x = Math.max(it.min || 0, it.max != null ? Math.min(it.max, x) : x); n.value = x; set(it.id, x); });
    row.appendChild(n);
    return row;
  },
  text(it) {
    const row = el('div', 'row col'); const l = label(it, row);
    const t = el('input'); t.type = 'text'; t.value = S[it.id] || ''; if (it.placeholder) t.placeholder = it.placeholder;
    t.addEventListener('input', debounce(() => set(it.id, t.value.trim()), 300));
    row.appendChild(t);
    if (it.swatches) {
      const box = el('div');
      it.swatches.forEach((c) => { const b = el('button', 'swatch'); b.type = 'button'; b.style.background = c; b.title = c; b.addEventListener('click', () => { t.value = c; set(it.id, c); }); box.appendChild(b); });
      const x = el('button', 'btn', 'Clear'); x.type = 'button'; x.addEventListener('click', () => { t.value = ''; set(it.id, ''); }); box.appendChild(x);
      row.appendChild(box);
    }
    return row;
  },
  textarea(it) {
    const row = el('div', 'row col'); label(it, row);
    const t = el('textarea'); t.value = S[it.id] || ''; if (it.placeholder) t.placeholder = it.placeholder; t.spellcheck = false;
    t.addEventListener('input', debounce(() => set(it.id, t.value), 400));
    row.appendChild(t);
    return row;
  },
  multi(it) {
    const row = el('div', 'row col'); label(it, row);
    const box = el('div');
    it.options.forEach((o) => {
      const l = el('label', 'chk'); const c = el('input'); c.type = 'checkbox'; c.checked = (S[it.id] || []).includes(o.v);
      c.addEventListener('change', () => {
        const cur = new Set(S[it.id] || []); if (c.checked) cur.add(o.v); else cur.delete(o.v);
        set(it.id, [...cur]);
      });
      l.append(c, document.createTextNode(o.l)); box.appendChild(l);
    });
    row.appendChild(box);
    return row;
  },
  hotkey(it) {
    const row = el('div', 'row'); label(it, row);
    const t = el('input'); t.type = 'text'; t.readOnly = true; t.placeholder = 'Click, press keys'; t.value = S[it.id] || ''; t.style.width = '120px';
    t.addEventListener('keydown', (e) => {
      e.preventDefault();
      if (e.key === 'Backspace' || e.key === 'Delete' || e.key === 'Escape') { t.value = ''; set(it.id, ''); return; }
      const k = e.key; if (['Control', 'Alt', 'Shift', 'Meta'].includes(k)) return;
      const parts = []; if (e.ctrlKey) parts.push('Ctrl'); if (e.altKey) parts.push('Alt'); if (e.shiftKey) parts.push('Shift'); if (e.metaKey) parts.push('Meta');
      let key = k.length === 1 ? k.toUpperCase() : k;
      if (e.altKey && /^Key[A-Z]$/.test(e.code)) key = e.code.slice(3);
      if (e.altKey && /^Digit\d$/.test(e.code)) key = e.code.slice(5);
      parts.push(key); t.value = parts.join('+'); set(it.id, t.value);
    });
    row.appendChild(t);
    return row;
  },
  header(it) { return el('h2', 'sub', it.label); },
  widget(it) { return widgets[it.kind](it); }
};

const widgets = {
  timer(it) {
    const row = el('div', 'row col'); label(it, row);
    const line = el('div'); line.style.cssText = 'display:flex;align-items:center;gap:6px;flex-wrap:wrap';
    const n = el('input'); n.type = 'number'; n.min = 1; n.max = 1440; n.value = it.def;
    const status = el('span', 'hint');
    const go = el('button', 'btn primary', 'Start'); go.type = 'button';
    const stop = el('button', 'btn', 'Stop'); stop.type = 'button';
    go.addEventListener('click', () => { const m = Math.max(1, parseInt(n.value, 10) || it.def); S[it.key] = Date.now() + m * 60000; save({ [it.key]: S[it.key] }); upd(); });
    stop.addEventListener('click', () => { S[it.key] = 0; save({ [it.key]: 0 }); upd(); });
    function upd() { const left = S[it.key] - Date.now(); status.textContent = left > 0 ? `Active, ${Math.ceil(left / 60000)} min left` : 'Off'; }
    line.append(n, el('span', '', 'min'), go, stop); row.append(line, status); upd();
    const t = setInterval(upd, 5000); window.addEventListener('unload', () => clearInterval(t));
    return row;
  },
  password(it) {
    const row = el('div', 'row col'); label(it, row);
    const title = row.querySelector('.lbl');
    const body = el('div');
    row.appendChild(body);
    let state = S.pwHash ? 'verify' : 'new';   // verify -> manage -> new (change)
    const blockTo = (info, title, items) => {
      info.appendChild(el('div', 'pw-title', title));
      const ul = el('ul'); items.forEach((t) => ul.appendChild(el('li', '', t))); info.appendChild(ul);
    };
    function render() {
      body.textContent = '';
      if (title) title.hidden = !S.pwHash;
      const msg = el('span', 'hint');
      if (state === 'verify') {
        body.appendChild(el('div', 'pw-title', 'Enter your current password'));
        const cur = el('input'); cur.type = 'password'; cur.placeholder = 'Current password'; cur.autocomplete = 'off';
        const go = el('button', 'btn primary', 'Continue'); go.type = 'button';
        const check = async () => {
          if (await RT.checkPassword(S, cur.value)) { state = 'manage'; render(); } else { msg.textContent = 'Wrong password.'; cur.value = ''; }
        };
        go.addEventListener('click', check);
        cur.addEventListener('keydown', (e) => { if (e.key === 'Enter') check(); });
        const line = el('div'); line.append(cur, go);
        body.append(line, msg);
        return;
      }
      if (state === 'manage') {
        body.appendChild(el('div', 'pw-title', 'A password is set'));
        const ch = el('button', 'btn primary', 'Change password'); ch.type = 'button';
        const rm = el('button', 'btn', 'Remove password'); rm.type = 'button';
        ch.addEventListener('click', () => { state = 'new'; render(); });
        rm.addEventListener('click', () => {
          S.pwHash = ''; S.pwSalt = ''; save({ pwHash: '', pwSalt: '' });
          state = 'new'; render();
          const m = body.querySelector('.hint'); if (m) m.textContent = 'Password removed.';
        });
        const line = el('div'); line.append(ch, rm);
        body.append(line, el('span', 'hint', 'A local lock for this popup. Someone with access to your browser profile can still remove the extension.'));
        return;
      }
      if (state === 'enter') {
        body.appendChild(el('div', 'pw-title', S.pwHash ? 'Choose a new password' : 'Choose a password'));
        const pw = el('input'); pw.type = 'password'; pw.placeholder = 'Password (4+ characters)'; pw.autocomplete = 'new-password';
        const ok = el('button', 'btn pw-yes', 'Set password'); ok.type = 'button';
        const no = el('button', 'btn pw-no', 'Cancel'); no.type = 'button';
        const set = async () => {
          if (pw.value.length < 4) { msg.textContent = 'Use at least 4 characters.'; pw.focus(); return; }
          const salt = Array.from(crypto.getRandomValues(new Uint8Array(8))).map((b) => b.toString(16).padStart(2, '0')).join('');
          const hash = await RT.sha256(salt + pw.value);
          S.pwSalt = salt; S.pwHash = hash; save({ pwSalt: salt, pwHash: hash });
          state = 'manage'; render();
          const m = body.querySelector('.hint'); if (m) m.textContent = 'Password set. The popup will ask for it next time.';
        };
        ok.addEventListener('click', set);
        pw.addEventListener('keydown', (e) => { if (e.key === 'Enter') set(); });
        no.addEventListener('click', () => { state = S.pwHash ? 'manage' : 'new'; render(); });
        const line = el('div'); line.append(pw);
        const btns = el('div', 'pw-btns'); btns.append(no, ok);
        body.append(line, msg, btns);
        setTimeout(() => pw.focus(), 0);
        return;
      }
      // state === 'new': instructions first; the password is asked for only after Accept
      const info = el('div', 'pw-info');
      blockTo(info, 'Setting it', [
        'Read the notes below, then scroll to the bottom of this page and press Accept.',
        'After you press Accept, you will be asked to type a password. It needs at least 4 characters.',
        'Press Never Mind to cancel. Once a password exists, you enter it here to change or remove it.'
      ]);
      blockTo(info, 'What it does', [
        'Each time you open the popup it shows \u201cSettings are locked\u201d with a password box. Nothing else is visible, and that includes the gear and backup panel.',
        'After you unlock, the popup stays unlocked for 2 minutes. That works even if you close and reopen it.',
        'It also protects the block and focus screens ReTrapper adds on YouTube. Any way past them asks for the password.'
      ]);
      blockTo(info, 'Good to know', [
        'Only a salted SHA-256 hash is stored, never the password itself.',
        'Backup codes leave the password out, so a code can never overwrite or leak it.',
        'It is a speed bump, not real security. Anyone with access to your browser profile can remove the extension or clear its data, and the lock goes with it.',
        'There is no recovery. If you forget the password, the only way back in is removing and reinstalling the extension, which resets your settings.'
      ]);
      const never = el('button', 'btn pw-no', 'Never Mind'); never.type = 'button';
      const accept = el('button', 'btn pw-yes', 'Accept'); accept.type = 'button';
      const btns = el('div', 'pw-btns'); btns.append(never, accept); info.appendChild(btns);
      never.addEventListener('click', () => { if (S.pwHash) { state = 'manage'; render(); } else $('scroll').scrollTop = 0; });
      accept.addEventListener('click', () => { state = 'enter'; render(); $('scroll').scrollTop = 0; });
      body.append(info);
    }
    render();
    return row;
  },
  presets(it) {
    const row = el('div', 'row col'); label(it, row);
    const list = el('div'); const msg = el('span', 'hint');
    const name = el('input'); name.type = 'text'; name.placeholder = 'Preset name';
    const saveBtn = el('button', 'btn primary', 'Save current settings'); saveBtn.type = 'button';
    function draw() {
      list.textContent = '';
      RT.presetNames(S.rtPresets).forEach((n) => {
        const r = el('div', 'preset'); const builtin = !!RT.BUILTIN_PRESETS[n] && !(S.rtPresets || {})[n];
        r.appendChild(el('span', 'name', (S.activePreset === n ? '● ' : '') + n + (builtin ? ' (built-in)' : '')));
        const load = el('button', 'btn', 'Load'); load.type = 'button';
        load.addEventListener('click', () => RT.applyPreset(n, () => { S.activePreset = n; msg.textContent = `Loaded "${n}".`; draw(); setTimeout(() => load2(), 150); }));
        r.appendChild(load);
        if (!builtin) {
          const del = el('button', 'btn', 'Delete'); del.type = 'button';
          del.addEventListener('click', () => { const all = Object.assign({}, S.rtPresets); delete all[n]; S.rtPresets = all; save({ rtPresets: all }); draw(); });
          r.appendChild(del);
        }
        list.appendChild(r);
      });
    }
    saveBtn.addEventListener('click', () => {
      const n = name.value.trim(); if (!n) { msg.textContent = 'Type a name first.'; return; }
      const all = Object.assign({}, S.rtPresets); all[n] = { values: RT.snapshot(S) };
      S.rtPresets = all; S.activePreset = n; save({ rtPresets: all, activePreset: n }); msg.textContent = `Saved "${n}".`; name.value = ''; draw();
    });
    draw(); row.append(list, name, saveBtn, msg);
    row.appendChild(el('span', 'hint', 'Built-ins: Work, Study, Relax, Minimal. Saving with a built-in name replaces it with your version.'));
    return row;
  }
};
function load2() { chrome.storage.local.get(null, (st) => { S = Object.assign(RT.defaults(), st); if (!S.thumbsHideAll && (S.hideThumbnails || S.thumbsHideHome || S.thumbsHideSearch || S.thumbsHideSubs || S.thumbsHideChannel || S.thumbsHideRecs)) { S.thumbsHideAll = true; chrome.storage.local.set({ thumbsHideAll: true, hideThumbnails: true }); }
    chrome.storage.local.remove(['thumbsHideHome', 'thumbsHideSearch', 'thumbsHideSubs', 'thumbsHideChannel', 'thumbsHideRecs']); showSection(current); }); }

// ---- rendering a section -----------------------------------------------------------
const GEAR_HTML = $('gearBtn').innerHTML;
const BACK_HTML = '<svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg><span style="font:500 12px Roboto,Arial,sans-serif;margin-left:2px">Back</span>';
function setGear(back) {
  const g = $('gearBtn');
  g.innerHTML = back ? BACK_HTML : GEAR_HTML;
  g.title = back ? 'Back' : 'Settings'; g.setAttribute('aria-label', back ? 'Back' : 'Settings');
  g.style.alignItems = 'center';
}
function drawOrder() {
  const box = $('orderList'); box.textContent = '';
  const ids = RT.orderedIds(S.pageOrder);
  const commit = (arr) => { S.pageOrder = arr; save({ pageOrder: arr }); drawOrder(); };
  ids.forEach((id, i) => {
    const row = el('div', 'ordRow'); row.dataset.id = id;
    row.appendChild(el('span', 'ordName', RT.sectionById(id).title));
    const mk = (txt, lab, dis, fn) => { const b = el('button', 'ordBtn', txt); b.type = 'button'; b.setAttribute('aria-label', lab + ' ' + RT.sectionById(id).title); b.disabled = dis; b.addEventListener('click', fn); return b; };
    row.appendChild(mk('\u25B2', 'Move up', i === 0, () => { const a = ids.slice(); a.splice(i - 1, 0, a.splice(i, 1)[0]); commit(a); }));
    row.appendChild(mk('\u25BC', 'Move down', i === ids.length - 1, () => { const a = ids.slice(); a.splice(i + 1, 0, a.splice(i, 1)[0]); commit(a); }));
    box.appendChild(row);
  });
}
$('orderReset').addEventListener('click', () => { S.pageOrder = []; save({ pageOrder: [] }); drawOrder(); });
function showSection(id, userNav) {
  let openWL = false;
  if (id === 'watchlater') { id = 'home'; openWL = true; }
  const sq = $('optSearch');
  if (userNav && sq) sq.value = '';
  if (sq && sq.value.trim()) { showSearch(sq.value.trim()); return; }
  const sec = RT.sectionById(id) || RT.SECTIONS[0];
  current = sec.id;
  settingsMode = !!sec.settings;
  if (!settingsMode) mainId = sec.id;
  $('gearBtn').setAttribute('aria-expanded', settingsMode ? 'true' : 'false');
  setGear(settingsMode);
  document.querySelector('.searchbar').hidden = settingsMode;
  $('settingsPanel').hidden = sec.id !== 'backup';
  $('reportPanel').hidden = sec.id !== 'report';
  $('orderPanel').hidden = sec.id !== 'pageorder';
  if (sec.id === 'pageorder') drawOrder();
  if (sec.id === 'report' && window.RTReport) window.RTReport.refresh();
  if (sec.id === 'backup' && window.RTBackup) window.RTBackup.refresh();
  try { if (!settingsMode) localStorage.setItem(LAST_KEY, current); } catch (e) { /* ignore */ }
  $('secName').textContent = sec.title;
  const dyn = $('dyn'); dyn.textContent = ''; rowsOnPage.length = 0;
  // The Watch Later shelf settings sit at the top of the Home page, always collapsed unless opened from search.
  $('wlGroup').hidden = sec.id !== 'home';
  $('wlGroup').open = openWL && sec.id === 'home';
  dyn.hidden = false;
  $('scroll').scrollTop = 0;
  const core = RT.CORE && RT.CORE[sec.id];
  const coreSet = core ? new Set(core) : null;
  const itemRows = sec.rows.filter((r) => typeof r !== 'object');
  const simple = !!coreSet && itemRows.length > core.length + 1;
  let more = null, moreBox = null;
  dyn.classList.toggle('simple', simple);
  const target = (r) => (simple && typeof r !== 'object' && !coreSet.has(r)) || (simple && typeof r === 'object' && r.header) ? ensureMore() : dyn;
  function ensureMore() {
    if (!more) {
      more = el('details', 'more'); more.appendChild(el('summary', '', 'More settings (' + (itemRows.length - core.filter((c) => itemRows.includes(c)).length) + ')'));
      moreBox = el('div', 'moreBox'); more.appendChild(moreBox); dyn.appendChild(more);
    }
    return moreBox;
  }
  // Main toggles first (in the page's own order), then the rest under "More settings".
  const ordered = simple ? sec.rows.filter((r) => typeof r !== 'object' && coreSet.has(r)).concat(sec.rows.filter((r) => typeof r === 'object' || !coreSet.has(r))) : sec.rows;
  let grp = null, grpBox = null, grpN = 0, grpSum = null, grpTitle = '';
  const endGrp = () => { if (grpSum) grpSum.textContent = grpTitle + ' (' + grpN + ')'; grp = null; grpBox = null; };
  ordered.forEach((r) => {
    if (typeof r === 'object' && r.header) {
      endGrp();
      if (simple) {
        // Inside "More settings", every group starts collapsed.
        grp = el('details', 'grp'); grpTitle = r.header; grpN = 0; grpSum = el('summary', '', r.header);
        grp.appendChild(grpSum); grpBox = el('div', 'grpBox'); grp.appendChild(grpBox); ensureMore().appendChild(grp);
      } else dyn.appendChild(el('h2', 'sub', r.header));
      return;
    }
    if (typeof r === 'object' && r.hub) {
      r.hub.forEach(([l, tgt]) => { const b = el('button', 'btn', l); b.type = 'button'; b.style.cssText = 'display:block;width:100%;text-align:left;margin:4px 0;padding:8px 12px'; b.addEventListener('click', () => showSection(tgt, true)); dyn.appendChild(b); });
      return;
    }
    const it = RT.ITEMS[r];
    if (!it) return;
    const row = builders[it.type](it);
    if (grpBox && target(r) !== dyn) { grpBox.appendChild(row); grpN++; } else { if (grpBox) endGrp(); target(r).appendChild(row); }
    rowsOnPage.push({ it, el: row });
  });
  endGrp();
  refreshVisibility();
}

// ---- search across every setting ------------------------------------------------------
const WL_SEARCH = 'watch later shelf from your watch later cards per row layout grid scroll text colour dearrow titles thumbnails';
function showSearch(raw) {
  const terms = raw.toLowerCase().split(/\s+/).filter(Boolean);
  const dyn = $('dyn'); dyn.textContent = ''; rowsOnPage.length = 0;
  $('wlGroup').hidden = true; dyn.hidden = false;
  $('secName').textContent = 'Search results';
  $('scroll').scrollTop = 0;
  const seen = new Set();
  let shown = 0;
  RT.SECTIONS.forEach((sec) => {
    const hits = [];
    if (sec.id === 'watchlater') {
      if (terms.every((t) => (WL_SEARCH + ' ' + sec.title.toLowerCase()).includes(t))) hits.push('__wl');
    } else {
      sec.rows.forEach((r) => {
        if (typeof r !== 'string' || seen.has(r)) return;
        const it = RT.ITEMS[r];
        if (!it) return;
        const hay = (it.label + ' ' + (it.alts || []).join(' ') + ' ' + (it.hint || '') + ' ' + sec.title + ' ' + r).toLowerCase();
        if (terms.every((t) => hay.includes(t))) { seen.add(r); hits.push(r); }
      });
    }
    if (!hits.length || shown >= 80) return;
    const head = el('div', 'sr-head'); head.appendChild(el('span', '', sec.title));
    const open = el('button', '', 'Open section'); open.type = 'button';
    open.addEventListener('click', () => { $('optSearch').value = ''; showSection(sec.id); });
    head.appendChild(open); dyn.appendChild(head);
    hits.forEach((r) => {
      if (r === '__wl') {
        const b = el('button', 'btn', 'Watch Later shelf settings'); b.type = 'button'; b.style.cssText = 'display:block;width:100%;text-align:left;margin:4px 0;padding:8px 12px';
        b.addEventListener('click', () => { $('optSearch').value = ''; showSection('watchlater'); }); dyn.appendChild(b); shown++;
        return;
      }
      const it = RT.ITEMS[r];
      const row = builders[it.type](it);
      dyn.appendChild(row); rowsOnPage.push({ it, el: row }); shown++;
    });
  });
  if (!shown) dyn.appendChild(el('p', 'hint', 'No settings match \u201c' + raw + '\u201d.'));
  refreshVisibility();
}
$('gearBtn').addEventListener('click', () => {
  closeMenu(); $('optSearch').value = '';
  showSection(settingsMode ? mainId : 'access');
});
$('optSearch').addEventListener('input', (e) => {
  const q = e.target.value.trim();
  if (q) showSearch(q); else showSection(current);
});
$('optSearch').addEventListener('keydown', (e) => { if (e.key === 'Escape') { e.target.value = ''; showSection(current); } });

// ---- Watch Later shelf page (unchanged controls) ---------------------------------------
const WL_CHECKS = ['showWatchLater', 'hideWatchLaterHome', 'autoRemoveWatched', 'useDearrow'];
const cardsRow = $('cardsRow'), cardsSlider = $('cardsPerRow'), cardsValue = $('cardsValue');
function setActiveTheme(c) { $('themeSun').classList.toggle('active', c === 'black'); $('themeMoon').classList.toggle('active', c === 'white'); }
function setActiveLayout(m) { $('layoutGrid').classList.toggle('active', m === 'grid'); $('layoutScroll').classList.toggle('active', m !== 'grid'); }
function loadWL() {
  WL_CHECKS.forEach((id) => { $(id).checked = !!S[id]; });
  setActiveTheme(S.watchLaterTextColor); setActiveLayout(S.layoutMode);
  cardsSlider.value = S.cardsPerRow; cardsValue.textContent = S.cardsPerRow; cardsRow.hidden = !S.thumbsHideAll;
}
WL_CHECKS.forEach((id) => $(id).addEventListener('change', (e) => { S[id] = e.target.checked; save({ [id]: e.target.checked }); }));
cardsSlider.addEventListener('input', (e) => { cardsValue.textContent = e.target.value; save({ cardsPerRow: parseInt(e.target.value, 10) }); });
$('themeSun').addEventListener('click', () => { const n = S.watchLaterTextColor === 'black' ? 'auto' : 'black'; S.watchLaterTextColor = n; setActiveTheme(n); save({ watchLaterTextColor: n }); });
$('themeMoon').addEventListener('click', () => { const n = S.watchLaterTextColor === 'white' ? 'auto' : 'white'; S.watchLaterTextColor = n; setActiveTheme(n); save({ watchLaterTextColor: n }); });
$('layoutGrid').addEventListener('click', () => { S.layoutMode = 'grid'; setActiveLayout('grid'); save({ layoutMode: 'grid' }); });
$('layoutScroll').addEventListener('click', () => { S.layoutMode = 'scroll'; setActiveLayout('scroll'); save({ layoutMode: 'scroll' }); });

// ---- popup light/dark theme (auto by default; buttons are an override) -----------------
function markTheme() {
  const t = window.__rtTheme.saved();
  $('popupLight').classList.toggle('active', t === 'light');
  $('popupDark').classList.toggle('active', t === 'dark');
}
window.__rtThemeChanged = markTheme;
$('popupLight').addEventListener('click', () => window.__rtTheme.set(window.__rtTheme.saved() === 'light' ? null : 'light'));
$('popupDark').addEventListener('click', () => window.__rtTheme.set(window.__rtTheme.saved() === 'dark' ? null : 'dark'));
markTheme();

// ---- start (with optional password lock) -----------------------------------------------------
// Which settings page matches the YouTube tab the menu was opened from.
function sectionForUrl(u) {
  let x; try { x = new URL(u); } catch (e) { return ''; }
  if (!/(^|\.)youtube\.com$/.test(x.hostname)) return '';
  const p = x.pathname;
  if (p === '/' || p === '/index') return 'home';
  if (p.startsWith('/shorts')) return 'shorts';
  if (p.startsWith('/watch') || p.startsWith('/live/')) return 'video';
  if (p.startsWith('/results')) return 'search';
  if (p.startsWith('/feed/subscriptions')) return 'subs';
  if (p.startsWith('/playlist') && x.searchParams.get('list') === 'WL') return 'home';
  if (/^\/(@|channel\/|c\/|user\/)/.test(p)) return 'channels';
  if (p.startsWith('/embed')) return 'embed';
  return '';
}
function start() {
  loadWL();
  let done = false;
  const go = (id) => { if (done) return; done = true; if (id && RT.sectionById(id)) current = id; showSection(current); };
  try {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      void chrome.runtime.lastError;
      go(sectionForUrl(tabs && tabs[0] && tabs[0].url));
    });
  } catch (e) { go(''); }
  setTimeout(() => go(''), 400);
}
function unlockThen(fn) {
  const done = () => { $('lock').hidden = true; $('scroll').hidden = false; $('secBtn').parentElement.hidden = false; $('gearBtn').hidden = false; fn(); };
  if (!S.pwHash) return done();
  const session = chrome.storage.session;
  const lockUi = () => {
    $('lock').hidden = false; $('scroll').hidden = true; $('secBtn').parentElement.hidden = true;
    const tryIt = async () => {
      if ((await RT.sha256(S.pwSalt + $('lockPw').value)) === S.pwHash) {
        if (session) session.set({ rtUnlock: Date.now() + 120000 });
        done();
      } else $('lockErr').textContent = 'Wrong password.';
    };
    $('lockBtn').onclick = tryIt;
    $('lockPw').onkeydown = (e) => { if (e.key === 'Enter') tryIt(); };
    $('lockPw').focus();
  };
  if (session) session.get(['rtUnlock'], (r) => (r && r.rtUnlock > Date.now() ? done() : lockUi())); else lockUi();
}
chrome.storage.local.get(null, (st) => { S = Object.assign(RT.defaults(), st); unlockThen(start); });
