// ReTrapper extras: runtime behaviour for the options in items-e.js
// (watch-page helpers, player tools, mouse wheel, audio, hotkeys, Shorts).
(function () {
  'use strict';
  const RT = window.RT;
  if (!RT || RT.extrasLoaded) return;
  RT.extrasLoaded = true;
  const S = () => RT.settings();
  const on = (id) => RT.on(id);
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => [...(r || document).querySelectorAll(s)];
  const page = () => RT.page();
  const isInput = (t) => !!t && (/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName) || t.isContentEditable);
  const video = () => $('video.html5-main-video') || $('#movie_player video') || $('video');
  const clickEl = (sel) => { const b = $(sel); if (b) { b.click(); return true; } return false; };
  const guard = (fn) => () => { try { fn(); } catch (e) { /* never break the page */ } };


  // ---- channel welcome video: thumbnail + play button instead of autoplay ------------------------------
  // The featured video on a channel's Home tab starts by itself. Pause it the moment it starts and cover the player
  // with its thumbnail and a play button. Clicking the button plays it.
  const FEATURED = 'ytd-channel-video-player-renderer, ytd-channel-featured-video-renderer';
  function featuredVideo(v) {
    if (page() !== 'channel' || !v || v.closest('ytd-video-preview, #inline-preview-player')) return null;
    return v.closest(FEATURED) || (v.closest('ytd-browse') ? v.closest('ytd-browse') : null);
  }
  function featuredOverlay(v, host) {
    const box = v.closest('ytd-player') || v.closest('.html5-video-player') || host;
    if (!box || box.querySelector(':scope > .rt-fp-overlay')) return;
    const link = host.querySelector && host.querySelector('a[href*="/watch?v="]');
    const m = link && (link.getAttribute('href') || '').match(/[?&]v=([\w-]{11})/);
    if (getComputedStyle(box).position === 'static') box.style.position = 'relative';
    const o = document.createElement('div');
    o.className = 'rt-fp-overlay';
    o.style.cssText = 'position:absolute;inset:0;z-index:2200;display:flex;align-items:center;justify-content:center;cursor:pointer;background:#000 center/cover no-repeat;' +
      (m ? "background-image:url('https://i.ytimg.com/vi/" + m[1] + "/hqdefault.jpg');" : '');
    o.innerHTML = '<div style="width:68px;height:48px;border-radius:14px;background:rgba(33,33,33,.85);display:flex;align-items:center;justify-content:center"><div style="border-left:20px solid #fff;border-top:12px solid transparent;border-bottom:12px solid transparent;margin-left:5px"></div></div>';
    o.addEventListener('click', (e) => {
      e.preventDefault(); e.stopPropagation();
      v.__rtAllowPlay = true; o.remove();
      try { v.muted = false; v.play(); } catch (err) { /* ignore */ }
    }, true);
    box.appendChild(o);
  }
  function featuredStop(e) {
    const v = e.target;
    if (!v || v.tagName !== 'VIDEO' || !on('channelNoAutoplay') || v.__rtAllowPlay) return;
    const host = featuredVideo(v);
    if (!host) return;
    try { v.pause(); } catch (err) { /* ignore */ }
    featuredOverlay(v, host);
  }
  document.addEventListener('play', featuredStop, true);
  document.addEventListener('playing', featuredStop, true);
  function featuredCleanup() {
    if (on('channelNoAutoplay') && page() === 'channel') return;
    $$('.rt-fp-overlay').forEach((o) => o.remove());
  }


  // ---- search box wording ---------------------------------------------------------------------------
  // YouTube's search box can read "Search or ask a question". Keep it plain: "Search". No setting for this.
  // The wording can sit in an attribute (placeholder, aria-label, ...) or in a text node, also inside shadow roots,
  // so look at everything inside the search box.
  const ASKY = /\bor ask\b|\bask a question\b/i;
  const SB_ATTRS = ['placeholder', 'aria-label', 'aria-placeholder', 'title', 'data-placeholder', 'label'];
  function searchBoxText() {
    const roots = $$('ytd-searchbox, yt-searchbox, #masthead #center, ytd-masthead #center, #search-input, form[role="search"]');
    const note = [];
    const stack = roots.slice();
    const seen = new Set();
    while (stack.length) {
      const n = stack.pop();
      if (!n || seen.has(n)) continue;
      seen.add(n);
      if (n.nodeType === 3) {
        if (ASKY.test(n.nodeValue) && n.nodeValue !== 'Search') { note.push('text:' + n.nodeValue.slice(0, 40)); n.nodeValue = 'Search'; }
        continue;
      }
      if (n.nodeType === 1) {
        if (/^(SCRIPT|STYLE)$/.test(n.tagName)) continue;
        SB_ATTRS.forEach((a) => {
          const v = n.getAttribute && n.getAttribute(a);
          if (v && ASKY.test(v) && v !== 'Search') { note.push(a + ':' + v.slice(0, 40)); n.setAttribute(a, 'Search'); }
        });
        if (n.shadowRoot) stack.push(n.shadowRoot);
      }
      for (let c = n.firstChild; c; c = c.nextSibling) stack.push(c);
    }
    if (note.length) { try { document.documentElement.setAttribute('data-rt-searchbox', note.slice(0, 4).join(' | ')); } catch (e) { /* ignore */ } }
  }
  (function watchSearchBox() {
    let t = 0;
    const kick = () => { if (t) return; t = setTimeout(() => { t = 0; guard(searchBoxText)(); }, 60); };
    const start = () => {
      const m = document.querySelector('ytd-masthead, #masthead-container');
      if (!m) { setTimeout(start, 500); return; }
      new MutationObserver(kick).observe(m, { subtree: true, childList: true, attributes: true, characterData: true, attributeFilter: SB_ATTRS });
      kick();
    };
    start();
  })();


  // ---- load the description and comments in the background -------------------------------------------
  // The description is part of the page and loads at once. YouTube only fetches comments once they scroll near the screen. Lift them into the viewport, invisible and
  // behind the page, until they have loaded, then put them back. Nothing moves on screen. Hidden parts are skipped.
  let pre = { id: '', t0: 0, c: null };
  function lift(holder, key, el) {
    if (!el || holder[key]) return;
    holder[key] = { el, css: el.getAttribute('style'), at: Date.now() };
    el.style.cssText = (holder[key].css || '') + ';position:fixed !important;top:0 !important;left:0 !important;width:min(100vw,640px) !important;opacity:0 !important;pointer-events:none !important;z-index:-1 !important;';
  }
  function drop(holder, key) {
    const h = holder[key];
    if (!h || h === true) return;
    if (h.css === null) h.el.removeAttribute('style'); else h.el.setAttribute('style', h.css);
    holder[key] = true;
  }
  function preloadWatch() {
    if (page() !== 'watch') { drop(pre, 'c'); pre = { id: '', t0: 0, c: null }; return; }
    const id = new URLSearchParams(location.search).get('v') || '';
    if (!id) return;
    if (pre.id !== id) { drop(pre, 'c'); pre = { id, t0: Date.now(), c: null }; }
    const now = Date.now();
    // If the page is scrolled while the comments are lifted, put them back at once: scrolling loads them anyway.
    if (window.scrollY > 300) { drop(pre, 'c'); return; }
    if (now - pre.t0 < 1500 || document.hidden) return;
    // comments
    if (!on('hideComments') && pre.c !== true) {
      const c = $('ytd-comments#comments') || $('ytd-comments');
      if (c) {
        const loaded = !!c.querySelector('ytd-comment-thread-renderer, ytd-comment-view-model, #message');
        if (loaded) drop(pre, 'c');
        else if (!pre.c) lift(pre, 'c', c);
        else if (now - pre.c.at > 9000) drop(pre, 'c');
      }
    }
  }


  // ---- disable the miniplayer ------------------------------------------------------------------------
  // The button and the miniplayer itself are hidden by the option's CSS. Here: the I shortcut, and closing the
  // miniplayer if YouTube opens it when you leave a video page.
  document.addEventListener('keydown', (e) => {
    if (!on('disableMiniplayer') || e.ctrlKey || e.metaKey || e.altKey) return;
    if ((e.key === 'i' || e.key === 'I') && !isInput(e.target)) { e.preventDefault(); e.stopImmediatePropagation(); }
  }, true);
  function closeMiniplayer() {
    if (!on('disableMiniplayer')) return;
    const mp = $('ytd-miniplayer');
    if (!mp) return;
    const active = mp.hasAttribute('active') || mp.hasAttribute('is-active') || mp.hasAttribute('miniplayer-active') || !!$('ytd-app[miniplayer-active_], ytd-app[miniplayer-is-active]');
    if (!active || page() === 'watch') return;
    let close = null;
    ['#close-button button', 'button[aria-label="Close"]', 'button[aria-label="Close player"]', '.ytmMiniplayerCloseButton', '#close-button'].some((q) => { close = $(q, mp); return !!close; });
    if (close) { try { close.click(); } catch (e) { /* ignore */ } }
    $$('video').forEach((v) => { if (!v.paused && v.closest('ytd-miniplayer')) { try { v.pause(); } catch (e) { /* ignore */ } } });
  }

  // ---- small on-screen message ------------------------------------------------------------------------
  let osdEl = null, osdT = 0;
  function osd(text) {
    const host = $('#movie_player') || document.body;
    if (!host) return;
    if (!osdEl || osdEl.parentNode !== host) {
      osdEl = document.createElement('div');
      osdEl.style.cssText = 'position:absolute;top:12%;left:50%;transform:translateX(-50%);z-index:2147483000;background:rgba(0,0,0,.7);color:#fff;font:600 18px Roboto,Arial,sans-serif;padding:6px 14px;border-radius:8px;pointer-events:none;transition:opacity .2s;';
      host.appendChild(osdEl);
    }
    osdEl.textContent = text;
    osdEl.style.opacity = '1';
    clearTimeout(osdT);
    osdT = setTimeout(() => { if (osdEl) osdEl.style.opacity = '0'; }, 900);
  }

  // ---- seek memory (for "undo seek") -------------------------------------------------------------------------
  let lastTime = 0, undoTo = null;
  document.addEventListener('timeupdate', (e) => { if (e.target && e.target.tagName === 'VIDEO' && !e.target.seeking) lastTime = e.target.currentTime; }, true);
  document.addEventListener('seeking', (e) => {
    const v = e.target;
    if (v && v.tagName === 'VIDEO' && Math.abs(v.currentTime - lastTime) > 1.5) undoTo = lastTime;
  }, true);

  // ---- view transforms (mirror / flip / rotate / zoom) ---------------------------------------------------------
  const view = { mx: 1, fy: 1, rot: 0, zoom: 1 };
  function applyView() {
    const v = video();
    if (!v) return;
    const reset = view.mx === 1 && view.fy === 1 && view.rot === 0 && view.zoom === 1;
    v.style.transform = reset ? '' : `rotate(${view.rot}deg) scale(${view.mx * view.zoom}, ${view.fy * view.zoom})`;
  }

  // ---- screenshot -----------------------------------------------------------------------------------------------------
  function screenshot() {
    const v = video();
    if (!v || !v.videoWidth) return osd('No video to capture');
    try {
      const c = document.createElement('canvas');
      c.width = v.videoWidth; c.height = v.videoHeight;
      c.getContext('2d').drawImage(v, 0, 0, c.width, c.height);
      const title = (($('ytd-watch-metadata h1') || {}).textContent || document.title || 'video').trim().replace(/[\\/:*?"<>|]+/g, '').slice(0, 60);
      const t = Math.floor(v.currentTime), stamp = `${Math.floor(t / 60)}m${String(t % 60).padStart(2, '0')}s`;
      c.toBlob((b) => {
        if (!b) return osd('Screenshot failed');
        const a = document.createElement('a');
        a.href = URL.createObjectURL(b);
        a.download = `${title} ${stamp}.png`;
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(a.href), 4000);
        osd('Screenshot saved');
      }, 'image/png');
    } catch (e) { osd('Screenshot blocked for this video'); }
  }
  function shotButton() {
    const bar = $('.ytp-right-controls');
    const want = on('screenshotButton') && bar;
    const ex = $('#rt-shot-btn');
    if (!want) { if (ex) ex.remove(); return; }
    if (ex && ex.isConnected) return;
    const b = document.createElement('button');
    b.id = 'rt-shot-btn'; b.className = 'ytp-button'; b.title = 'Screenshot';
    b.textContent = '📷';
    b.style.cssText = 'font-size:18px;line-height:1;opacity:.9;';
    b.addEventListener('click', (e) => { e.stopPropagation(); screenshot(); });
    bar.insertBefore(b, bar.firstChild);
  }

  // ---- picture in picture ----------------------------------------------------------------------------------------------
  function togglePip() {
    const v = video();
    if (!v) return;
    if (document.pictureInPictureElement) document.exitPictureInPicture().catch(() => {});
    else if (document.pictureInPictureEnabled && v.requestPictureInPicture) v.requestPictureInPicture().catch(() => osd('Picture-in-picture is not available'));
    else osd('Picture-in-picture is not available in this browser. Firefox users: use the button Firefox shows on the video.');
  }
  let pipSet = false;
  function autoPipSetup() {
    if (!on('autoPip') || page() !== 'watch') { if (pipSet) { try { navigator.mediaSession.setActionHandler('enterpictureinpicture', null); } catch (e) { /* ignore */ } pipSet = false; } return; }
    try {
      navigator.mediaSession.setActionHandler('enterpictureinpicture', () => { const v = video(); if (v && !document.pictureInPictureElement) v.requestPictureInPicture().catch(() => {}); });
      pipSet = true;
    } catch (e) { /* not supported */ }
  }
  document.addEventListener('visibilitychange', () => {
    if (!on('autoPip') || page() !== 'watch') return;
    const v = video();
    if (document.hidden && v && !v.paused && !document.pictureInPictureElement && document.pictureInPictureEnabled) v.requestPictureInPicture().catch(() => {});
    else if (!document.hidden && document.pictureInPictureElement) document.exitPictureInPicture().catch(() => {});
  });

  // ---- audio: volume boost and mono -------------------------------------------------------------------------------
  const graphs = new WeakMap();
  function audio(v) {
    const boost = Math.max(100, Math.min(400, +S().volumeBoost || 100)) / 100, mono = on('monoAudio');
    let g = graphs.get(v);
    if (!g) {
      if ((boost <= 1 && !mono) || !(navigator.userActivation && navigator.userActivation.hasBeenActive)) return;
      try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const src = ctx.createMediaElementSource(v);
        const m = ctx.createGain(), gain = ctx.createGain();
        src.connect(m); m.connect(gain); gain.connect(ctx.destination);
        g = { ctx, m, gain };
        graphs.set(v, g);
      } catch (e) { return; }
    }
    if (g.ctx.state === 'suspended') g.ctx.resume().catch(() => {});
    g.gain.gain.value = boost;
    g.m.channelCount = mono ? 1 : 2;
    g.m.channelCountMode = mono ? 'explicit' : 'max';
    g.m.channelInterpretation = 'speakers';
  }
  ['pointerdown', 'keydown'].forEach((t) => document.addEventListener(t, guard(() => { const v = video(); if (v && !graphs.has(v)) audio(v); }), true));

  // ---- per-channel speed ----------------------------------------------------------------------------------------------------
  let speeds = {}, speedsLoaded = false;
  try { chrome.storage.local.get('rtChannelSpeeds', (r) => { speeds = (r && r.rtChannelSpeeds) || {}; speedsLoaded = true; }); } catch (e) { /* ignore */ }
  const channelKey = () => {
    const a = $('ytd-watch-metadata ytd-video-owner-renderer a[href^="/"], ytd-watch-metadata #owner a[href^="/"], ytd-video-owner-renderer a[href^="/"]');
    const h = a && a.getAttribute('href');
    const m = h && h.match(/^\/(@[^/?]+|channel\/[^/?]+|c\/[^/?]+|user\/[^/?]+)/);
    return m ? m[1] : '';
  };
  let ps = { id: '', applied: false, learnAt: 0, ch: '' };
  document.addEventListener('ratechange', (e) => {
    const v = e.target;
    if (!on('perChannelSpeed') || page() !== 'watch' || !v || v.tagName !== 'VIDEO' || Date.now() < ps.learnAt || !ps.ch) return;
    const r = Math.round(v.playbackRate * 100) / 100;
    if (speeds[ps.ch] === r) return;
    speeds[ps.ch] = r;
    try { chrome.storage.local.set({ rtChannelSpeeds: speeds }); } catch (err) { /* ignore */ }
  }, true);
  function perChannel() {
    if (!on('perChannelSpeed') || page() !== 'watch' || !speedsLoaded) return;
    const v = video(), id = new URLSearchParams(location.search).get('v') || '';
    if (!v || !id) return;
    if (ps.id !== id) ps = { id, applied: false, learnAt: Date.now() + 4000, ch: '', t0: Date.now() };
    const ch = channelKey();
    if (!ch) return;
    ps.ch = ch;
    if (!ps.applied && Date.now() - ps.t0 > 2200 && v.readyState >= 1) {
      ps.applied = true;
      ps.learnAt = Date.now() + 1500;
      if (speeds[ch] && v.playbackRate !== speeds[ch]) { v.playbackRate = speeds[ch]; osd(speeds[ch] + 'x'); }
    }
  }

  // ---- mouse wheel over the player ----------------------------------------------------------------------------------
  document.addEventListener('wheel', (e) => {
    if (page() !== 'watch' && page() !== 'embed') return;
    const p = e.target && e.target.closest && e.target.closest('#movie_player');
    if (!p || e.target.closest('.ytp-chrome-bottom, .ytp-settings-menu, .ytp-popup')) return;
    const v = video();
    if (!v) return;
    const dir = (e.deltaY || e.deltaX) < 0 ? 1 : -1;
    if (e.altKey && on('wheelSpeed')) {
      e.preventDefault(); e.stopPropagation();
      const r = Math.min(4, Math.max(0.25, Math.round((v.playbackRate + dir * 0.25) * 100) / 100));
      v.playbackRate = r; osd(r + 'x');
    } else if (e.shiftKey && on('wheelSeek')) {
      e.preventDefault(); e.stopPropagation();
      undoTo = v.currentTime;
      v.currentTime = Math.max(0, Math.min(v.duration || 1e9, v.currentTime + dir * (+S().seekStep || 10)));
      osd((dir > 0 ? '+' : '-') + (+S().seekStep || 10) + 's');
    } else if (!e.altKey && !e.shiftKey && !e.ctrlKey && on('wheelVolume')) {
      e.preventDefault(); e.stopPropagation();
      setVolume(Math.round(Math.min(1, Math.max(0, v.volume + dir * 0.05)) * 100));
    }
  }, { capture: true, passive: false });
  function setVolume(pct) {
    const v = video();
    if (!v) return;
    v.muted = false; v.volume = pct / 100;
    RT.cmd && RT.cmd('volume', pct);
    osd('Volume ' + pct + '%');
  }

  // ---- hotkeys --------------------------------------------------------------------------------------------------------------
  const QUALITY = ['tiny', 'small', 'medium', 'large', 'hd720', 'hd1080', 'hd1440', 'hd2160', 'highres'];
  const NAMES = { tiny: '144p', small: '240p', medium: '360p', large: '480p', hd720: '720p', hd1080: '1080p', hd1440: '1440p', hd2160: '4K', highres: 'Max' };
  async function stepQuality(d) {
    const cur = await RT.cmd('getQuality');
    let i = QUALITY.indexOf(cur && cur.result);
    if (i < 0) i = QUALITY.indexOf('hd720');
    const n = QUALITY[Math.max(0, Math.min(QUALITY.length - 1, i + d))];
    await RT.cmd('quality', n);
    osd('Quality ' + NAMES[n]);
  }
  const seekBy = (d) => { const v = video(); if (!v) return; undoTo = v.currentTime; v.currentTime = Math.max(0, Math.min(v.duration || 1e9, v.currentTime + d)); osd((d > 0 ? '+' : '-') + Math.abs(d) + 's'); };
  const ACTIONS = {
    hk_like: () => clickEl('ytd-watch-flexy like-button-view-model button, ytd-watch-flexy #segmented-like-button button, ytd-reel-video-renderer[is-active] like-button-view-model button'),
    hk_dislike: () => clickEl('ytd-watch-flexy dislike-button-view-model button, ytd-watch-flexy #segmented-dislike-button button, ytd-reel-video-renderer[is-active] dislike-button-view-model button'),
    hk_screenshot: screenshot,
    hk_pip: togglePip,
    hk_mirror: () => { view.mx *= -1; applyView(); osd('Mirror'); },
    hk_flip: () => { view.fy *= -1; applyView(); osd('Flip'); },
    hk_rotate: () => { view.rot = (view.rot + 90) % 360; applyView(); osd('Rotate ' + view.rot + '°'); },
    hk_zoomIn: () => { view.zoom = Math.min(4, Math.round((view.zoom + 0.1) * 100) / 100); applyView(); osd('Zoom ' + Math.round(view.zoom * 100) + '%'); },
    hk_zoomOut: () => { view.zoom = Math.max(0.3, Math.round((view.zoom - 0.1) * 100) / 100); applyView(); osd('Zoom ' + Math.round(view.zoom * 100) + '%'); },
    hk_resetView: () => { view.mx = 1; view.fy = 1; view.rot = 0; view.zoom = 1; applyView(); osd('View reset'); },
    hk_seekFwd: () => seekBy(+S().seekStep || 10),
    hk_seekBack: () => seekBy(-(+S().seekStep || 10)),
    hk_undoSeek: () => { const v = video(); if (v && undoTo !== null) { const t = undoTo; undoTo = v.currentTime; v.currentTime = t; osd('Undo seek'); } },
    hk_volUp: () => { const v = video(); if (v) setVolume(Math.min(100, Math.round(v.volume * 100) + 5)); },
    hk_volDown: () => { const v = video(); if (v) setVolume(Math.max(0, Math.round(v.volume * 100) - 5)); },
    hk_speedUp: () => { const v = video(); if (v) { v.playbackRate = Math.min(4, Math.round((v.playbackRate + 0.25) * 100) / 100); osd(v.playbackRate + 'x'); } },
    hk_speedDown: () => { const v = video(); if (v) { v.playbackRate = Math.max(0.25, Math.round((v.playbackRate - 0.25) * 100) / 100); osd(v.playbackRate + 'x'); } },
    hk_qualityUp: () => stepQuality(1),
    hk_qualityDown: () => stepQuality(-1),
    hk_loop: () => { const v = video(); if (v) { v.loop = !v.loop; osd(v.loop ? 'Loop on' : 'Loop off'); } },
    hk_home: () => location.assign('/'),
    hk_subs: () => location.assign('/feed/subscriptions'),
    hk_shorts: () => location.assign('/shorts'),
    hk_top: () => window.scrollTo({ top: 0, behavior: 'smooth' })
  };
  RT.extraActions = ACTIONS;
  const normc = (c) => String(c).split('+').map((x) => x.trim().toLowerCase()).filter(Boolean).sort().join('+');
  let hmap = null, hver = -1;
  document.addEventListener('keydown', (e) => {
    if (isInput(e.target)) return;
    // Number keys off (0-9 jump around the video).
    if (on('noNumberKeys') && /^[0-9]$/.test(e.key) && !e.ctrlKey && !e.altKey && !e.metaKey && (page() === 'watch' || page() === 'shorts')) { e.stopImmediatePropagation(); return; }
    if (!on('hotkeysOn') || !RT.comboFromEvent) return;
    const combo = RT.comboFromEvent(e);
    if (!combo) return;
    if (!hmap || hver !== RT.version()) {
      hmap = new Map(); hver = RT.version();
      Object.keys(ACTIONS).forEach((k) => { if (S()[k]) hmap.set(normc(S()[k]), k); });
    }
    const k = hmap.get(normc(combo));
    if (k) {
      if (e.repeat && !/seek|vol|speed|zoom/i.test(k)) return;
      e.preventDefault(); e.stopImmediatePropagation();
      ACTIONS[k]();
    }
  }, true);

  // ---- pause other tabs ---------------------------------------------------------------------------------------------------
  let bc = null; const me = Math.random().toString(36).slice(2);
  try { bc = new BroadcastChannel('retrapper-playing'); bc.onmessage = (m) => { if (on('pauseOthers') && m.data && m.data.from !== me) { const v = video(); if (v && !v.paused) v.pause(); } }; } catch (e) { /* ignore */ }
  document.addEventListener('play', (e) => { if (bc && on('pauseOthers') && e.target && e.target.tagName === 'VIDEO' && (page() === 'watch' || page() === 'shorts')) bc.postMessage({ from: me }); }, true);

  // ---- "Video paused. Continue watching?" -------------------------------------------------------------------------------------
  function pausedPrompt() {
    if (!on('noPausedPrompt')) return;
    $$('yt-confirm-dialog-renderer, ytd-confirm-dialog-renderer, tp-yt-paper-dialog').forEach((d) => {
      if (!/continue watching|video paused/i.test(d.textContent || '')) return;
      const b = $('#confirm-button button, yt-button-renderer button, button', d);
      if (b) { b.click(); const v = video(); if (v && v.paused && !v.ended) v.play().catch(() => {}); }
    });
  }

  // ---- playlist end / shorts end ---------------------------------------------------------------------------------------------------
  let lastNext = 0;
  function endGuards() {
    const v = video();
    if (page() === 'watch' && on('noPlaylistAutoplay') && v && new URLSearchParams(location.search).get('list') && v.duration > 1 && !v.loop && v.currentTime >= v.duration - 0.4 && !v.paused) v.pause();
    if (page() === 'shorts' && (on('shortsAutoScroll') || on('shortsNoLoop'))) {
      const sv = $('ytd-reel-video-renderer[is-active] video') || v;
      if (sv && sv.duration > 1 && sv.currentTime >= sv.duration - 0.3 && !sv.paused) {
        if (on('shortsAutoScroll')) {
          if (Date.now() - lastNext > 1500) { lastNext = Date.now(); clickEl('#navigation-button-down button, ytd-shorts #navigation-button-down button'); }
        } else sv.pause();
      }
    }
  }

  // ---- remaining time -------------------------------------------------------------------------------------------------------------------
  function remaining() {
    const host = $('.ytp-time-display');
    const ex = $('#rt-remaining');
    if (!on('remainingTime') || !host) { if (ex) ex.remove(); return; }
    const v = video();
    if (!v || !(v.duration > 0) || !isFinite(v.duration)) { if (ex) ex.remove(); return; }
    const left = Math.max(0, (v.duration - v.currentTime) / (v.playbackRate || 1));
    const h = Math.floor(left / 3600), m = Math.floor((left % 3600) / 60), s = Math.floor(left % 60);
    const t = ' (-' + (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(s).padStart(2, '0') + ')';
    let el = ex;
    if (!el) { el = document.createElement('span'); el.id = 'rt-remaining'; el.style.cssText = 'margin-left:4px;opacity:.85;'; host.appendChild(el); }
    if (el.textContent !== t) el.textContent = t;
  }

  // ---- watch-page helpers (expand description / comments, live chat, sidebar comments) ---------------------------------
  let wid = '', did = {};
  function watchHelpers() {
    if (page() !== 'watch') return;
    const id = new URLSearchParams(location.search).get('v') || '';
    if (id !== wid) { wid = id; did = { t0: Date.now() }; }
    if (!on('autoExpandDescription') && !did.desc && RT.lines(S().autoExpandChannels).length) {
      // Only for the listed channels: match the name, @handle or channel id of the video's channel.
      const a = $('ytd-watch-metadata ytd-channel-name a, ytd-watch-metadata #owner a[href]');
      if (a) {
        const key = (x) => String(x || '').toLowerCase().replace(/^.*youtube\.com\//, '').replace(/^\//, '').replace(/^(channel|c|user)\//, '').replace(/^@/, '').replace(/\/$/, '').trim();
        const want = new Set(RT.lines(S().autoExpandChannels).map(key));
        const name = key(a.textContent);
        const href = key((a.getAttribute('href') || '').split('?')[0]);
        if (want.has(name) || want.has(href)) {
          const ex = $('ytd-watch-metadata ytd-text-inline-expander');
          if (ex && !ex.hasAttribute('is-expanded') && !ex.hasAttribute('expanded')) {
            const b = $('#expand, tp-yt-paper-button#expand, #snippet #expand', ex);
            if (b) { b.click(); did.desc = true; }
          } else if (ex) did.desc = true;
        }
      }
    }
    if (on('autoExpandDescription') && !did.desc) {
      const ex = $('ytd-watch-metadata ytd-text-inline-expander');
      if (ex && !ex.hasAttribute('is-expanded') && !ex.hasAttribute('expanded')) {
        const b = $('#expand, tp-yt-paper-button#expand, #snippet #expand', ex);
        if (b) { b.click(); did.desc = true; }
      } else if (ex) did.desc = true;
    }
    if (on('autoExpandComments')) {
      $$('ytd-comments #more, ytd-comment-view-model #more, ytd-comments ytd-expander[collapsed] #more, ytd-comments tp-yt-paper-button#more').forEach((b) => {
        if (b.offsetParent && !b.hidden && !b.closest('[hidden]') && !b.dataset.rtExp) { b.dataset.rtExp = '1'; b.click(); }
      });
    }
    if (on('noAutoLiveChat') && !did.chat) {
      const f = $('ytd-live-chat-frame');
      if (f && Date.now() - did.t0 > 1500) {
        did.chat = true;
        if (!f.hasAttribute('collapsed')) { const b = $('#show-hide-button button, #show-hide-button ytd-toggle-button-renderer button', f); if (b) b.click(); }
      }
    }
    if (on('forceOriginalAudio') && !did.audio && Date.now() - did.t0 > 2500) { did.audio = true; RT.cmd && RT.cmd('audioOriginal'); }
    commentsSidebar();
  }
  let marker = null;
  function commentsSidebar() {
    const c = $('ytd-comments#comments');
    const side = $('#secondary-inner');
    if (on('commentsInSidebar') && c && side) {
      if (c.parentElement !== side) {
        if (!marker) marker = document.createComment('rt-comments');
        c.parentElement.insertBefore(marker, c);
        const rel = $('#related', side);
        side.insertBefore(c, rel || null);
      }
    } else if (c && marker && marker.parentNode && c.parentElement === side) {
      marker.parentNode.insertBefore(c, marker);
      marker.remove();
    }
  }

  // ---- pin the player while scrolling ----------------------------------------------------------------------------------------------------------------
  let pinObs = null, pinTarget = null;
  function pinSetup() {
    const root = document.documentElement;
    const t = $('ytd-watch-flexy #player-container-outer, ytd-watch-flexy #player');
    if (!on('pinPlayer') || page() !== 'watch' || !t) { if (pinObs) { pinObs.disconnect(); pinObs = null; pinTarget = null; } root.removeAttribute('data-rt-pinned'); return; }
    if (pinObs && pinTarget === t) return;
    if (pinObs) pinObs.disconnect();
    pinTarget = t;
    pinObs = new IntersectionObserver((en) => {
      const e = en[0], v = video();
      const flexy = $('ytd-watch-flexy');
      const away = !e.isIntersecting && e.boundingClientRect.top < 0 && v && !v.paused && flexy && !flexy.hasAttribute('fullscreen');
      if (away) root.setAttribute('data-rt-pinned', '1'); else root.removeAttribute('data-rt-pinned');
    }, { threshold: 0 });
    pinObs.observe(t);
  }

  // ---- video focus --------------------------------------------------------------------------------------------------------------------------------------
  document.addEventListener('play', (e) => { if (e.target && e.target.tagName === 'VIDEO' && on('videoFocus') && page() === 'watch') document.documentElement.setAttribute('data-rt-vf', '1'); }, true);
  document.addEventListener('pause', (e) => { if (e.target && e.target.tagName === 'VIDEO') document.documentElement.removeAttribute('data-rt-vf'); }, true);

  // ---- search page: hide irrelevant blocks, open results in a new tab ---------------------------------------------------------------------------------
  const IRR = /(for you|people also watched|previously watched|people also search|related searches|from related searches|you may also like)/i;
  function searchBlocks() {
    const search = page() === 'search';
    $$('ytd-search ytd-shelf-renderer, ytd-search grid-shelf-view-model, ytd-search ytd-horizontal-card-list-renderer, ytd-search ytd-vertical-list-renderer, ytd-search ytd-reel-shelf-renderer').forEach((el) => {
      const h = $('#title, #title-text, h2, [role="heading"], .shelf-title, [class*="ShelfHeader"], [class*="header"] [class*="itle"]', el);
      const t = ((h && h.textContent) || '').trim();
      RT.setHide && RT.setHide(el, 'irr', search && on('hideIrrelevantSearch') && !!t && IRR.test(t));
    });
  }
  document.addEventListener('click', (e) => {
    if (e.button !== 0 || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
    const a = e.target && e.target.closest && e.target.closest('a[href]');
    if (!a) return;
    if (on('searchNewTab') && page() === 'search' && a.closest('ytd-search') && /^\/(watch|shorts)\b/.test(a.getAttribute('href') || '') && !a.closest('ytd-masthead')) {
      e.preventDefault(); e.stopImmediatePropagation();
      window.open(a.href, '_blank', 'noopener');
      return;
    }
    if (on('logoToSubs') && a.closest('ytd-masthead #logo, ytd-masthead ytd-topbar-logo-renderer')) {
      e.preventDefault(); e.stopImmediatePropagation();
      location.assign('/feed/subscriptions');
    }
  }, true);

  // ---- search: channels in one sideways row -------------------------------------------------------------------------------------------
  const chanHome = new Map();   // channel element -> comment marker left in its original place
  let chanWrap = null;
  const isChan = (el) => {
    if (!el || !el.tagName) return false;
    if (el.tagName === 'YTD-CHANNEL-RENDERER') return true;
    if (el.tagName !== 'YT-LOCKUP-VIEW-MODEL') return false;
    return !el.querySelector('a[href*="/watch"],a[href*="/playlist"],a[href*="/shorts"]') && !!el.querySelector('a[href^="/@"],a[href^="/channel/"]');
  };
  function channelRow() {
    const want = on('searchChannelRow') && page() === 'search';
    if (!want) {
      if (chanWrap) {
        chanHome.forEach((mk, el) => { if (mk.parentNode) { mk.parentNode.insertBefore(el, mk); mk.remove(); } });
        chanHome.clear(); chanWrap.remove(); chanWrap = null;
      }
      return;
    }
    const first = $('ytd-search ytd-item-section-renderer > #contents');
    if (!first) return;
    const found = $$('ytd-search ytd-item-section-renderer > #contents > *').filter((el) => isChan(el) && !(chanWrap && chanWrap.contains(el)));
    if (!found.length && !chanWrap) return;
    if (!chanWrap || !chanWrap.isConnected || chanWrap.parentElement !== first) {
      if (chanWrap) chanWrap.remove();
      chanWrap = document.createElement('div');
      chanWrap.id = 'rt-chan-wrap';
      const row = document.createElement('div'); row.id = 'rt-chan-row';
      const mkArrow = (cls, txt, dir) => {
        const b = document.createElement('button'); b.className = 'rt-chan-arrow ' + cls; b.type = 'button'; b.textContent = txt;
        b.addEventListener('click', () => row.scrollBy({ left: dir * 400, behavior: 'smooth' }));
        return b;
      };
      chanWrap.appendChild(mkArrow('rt-chan-l', '\u2039', -1)); chanWrap.appendChild(row); chanWrap.appendChild(mkArrow('rt-chan-r', '\u203A', 1));
      first.insertBefore(chanWrap, first.firstChild);
    }
    const row = $('#rt-chan-row', chanWrap);
    found.forEach((el) => {
      const mk = document.createComment('rt-chan');
      el.parentNode.insertBefore(mk, el);
      chanHome.set(el, mk);
      row.appendChild(el);
    });
    // A moved item that YouTube removed from the page should not linger in the map.
    chanHome.forEach((mk, el) => { if (!mk.isConnected) chanHome.delete(el); });
    chanWrap.style.display = row.children.length ? '' : 'none';
  }

  // ---- back to top ----------------------------------------------------------------------------------------------------------------------------------------------
  let topBtn = null;
  function topButton() {
    if (!on('backToTop')) { if (topBtn) { topBtn.remove(); topBtn = null; } return; }
    if (!topBtn || !topBtn.isConnected) {
      topBtn = document.createElement('button');
      topBtn.id = 'rt-top-btn'; topBtn.title = 'Back to top'; topBtn.textContent = '↑';
      topBtn.style.cssText = 'position:fixed;right:20px;bottom:64px;z-index:2147483000;width:42px;height:42px;border-radius:21px;border:0;background:#3f3f3f;color:#fff;font-size:20px;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.4);display:none;';
      topBtn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
      document.documentElement.appendChild(topBtn);
    }
    const show = (window.scrollY || document.documentElement.scrollTop) > 600;
    const d = show ? 'block' : 'none';
    if (topBtn.style.display !== d) topBtn.style.display = d;
  }
  window.addEventListener('scroll', guard(topButton), { passive: true });

  // ---- home page posts (fallback by heading text) -------------------------------------------------------------------------------------------------------
  function homePosts() {
    if (page() !== 'home') return;
    $$('ytd-rich-section-renderer, ytd-rich-shelf-renderer').forEach((el) => {
      const h = $('#title, #title-text, h2', el);
      const t = ((h && h.textContent) || '').trim();
      RT.setHide && RT.setHide(el, 'posts', on('hideHomePosts') && (/latest (youtube )?posts/i.test(t) || !!$('ytd-post-renderer', el)));
    });
  }

  // ---- main tick ------------------------------------------------------------------------------------------------------------------------------------------------------
  const tick = guard(() => {
    if (!RT.state) return;
    const v = (page() === 'watch' || page() === 'embed' || page() === 'shorts') ? video() : null;
    if (v) audio(v);
    shotButton(); remaining(); perChannel(); pausedPrompt(); endGuards(); autoPipSetup(); pinSetup();
    watchHelpers(); closeMiniplayer(); preloadWatch(); searchBoxText(); featuredCleanup(); channelRow(); searchBlocks(); homePosts(); topButton();
    if (!on('videoFocus')) document.documentElement.removeAttribute('data-rt-vf');
  });
  RT.bus.addEventListener('dom', tick);
  RT.bus.addEventListener('apply', tick);
  RT.bus.addEventListener('navigate', () => { view.mx = 1; view.fy = 1; view.rot = 0; view.zoom = 1; undoTo = null; setTimeout(tick, 300); });
  setInterval(tick, 700);
  setInterval(guard(endGuards), 250);
})();
