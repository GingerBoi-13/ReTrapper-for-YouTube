// ReTrapper feature schema (shared by popup and page scripts).
// Every option is defined once in RT.ITEMS; RT.SECTIONS says where it shows
// in the popup. Hide-style options are plain CSS lists, compiled by
// RT.buildCss() into rules gated on <html data-rt="...tokens...">.
(function (root) {
  'use strict';
  const RT = root.RT || (root.RT = {});
  RT.bus = new EventTarget();
  RT.state = null;

  const ITEMS = (RT.ITEMS = {});
  const SECTIONS = (RT.SECTIONS = []);

  const HIDE = 'display:none !important';
  const WATCH = 'ytd-watch-flexy';
  const HOME = 'ytd-browse[page-subtype="home"]';
  const SUBS = 'ytd-browse[page-subtype="subscriptions"]';
  const CHAN = 'ytd-browse[page-subtype="channels"]';
  const SRCH = 'ytd-search';
  RT.SEL = { HIDE, WATCH, HOME, SUBS, CHAN, SRCH };

  function def(id, o) {
    o.id = id;
    ITEMS[id] = o;
    return o;
  }
  const toggle = (id, label, o) => def(id, Object.assign({ type: 'toggle', label, def: false }, o));
  const select = (id, label, options, d, o) => def(id, Object.assign({ type: 'select', label, options, def: d }, o));
  const range = (id, label, min, max, step, d, o) => def(id, Object.assign({ type: 'range', label, min, max, step, def: d }, o));
  const number = (id, label, d, o) => def(id, Object.assign({ type: 'number', label, def: d, min: 0 }, o));
  const text = (id, label, o) => def(id, Object.assign({ type: 'text', label, def: '' }, o));
  const area = (id, label, o) => def(id, Object.assign({ type: 'textarea', label, def: '' }, o));
  const multi = (id, label, options, o) => def(id, Object.assign({ type: 'multi', label, options, def: [] }, o));
  const hotkey = (id, label, o) => def(id, Object.assign({ type: 'hotkey', label, def: '' }, o));
  const section = (id, title, rows) => SECTIONS.push({ id, title, rows });
  RT._h = { def, toggle, select, range, number, text, area, multi, hotkey, section };

  // Label-based button selectors on the watch page (English labels).
  RT.btn = (...labels) =>
    labels.flatMap((l) => [
      `${WATCH} #top-level-buttons-computed yt-button-view-model:has(button[aria-label^="${l}" i])`,
      `${WATCH} #top-level-buttons-computed button-view-model:has(button[aria-label^="${l}" i])`,
      `${WATCH} #top-level-buttons-computed ytd-button-renderer:has(button[aria-label^="${l}" i])`,
      `${WATCH} #flexible-item-buttons yt-button-view-model:has(button[aria-label^="${l}" i])`,
      `${WATCH} #flexible-item-buttons button-view-model:has(button[aria-label^="${l}" i])`
    ]);

  const THUMBS = ['ytd-thumbnail', 'yt-thumbnail-view-model', 'ytd-playlist-thumbnail', '.yt-lockup-view-model-wiz__content-image'];
  RT.onThumbs = (scopes, decl) => scopes.flatMap((sc) => THUMBS.map((t) => [`${sc} ${t}`, decl]));
  RT.THUMBS = THUMBS;

  // ---- helpers shared by all scripts ---------------------------------------
  RT.lines = (t) =>
    String(t || '')
      .split(/\r?\n/)
      .map((s) => s.trim())
      .filter((s) => s && s[0] !== '#');

  RT.SYSTEM_DEFAULTS = {
    rtPresets: {}, activePreset: '', pwHash: '', pwSalt: '',
    tempFocusUntil: 0, tempDistractUntil: 0, tempBlockUntil: 0,
    usageDay: '', usageSeconds: 0, aiSaved: {}, playerHeight: 0, rtAutoApplied: '', ytTheme: '', rtChannelSpeeds: {}
  };
  RT.WL_DEFAULTS = {
    showWatchLater: true, watchLaterTextColor: 'auto', layoutMode: 'scroll',
    hideThumbnails: false, useDearrow: false, cardsPerRow: 3, hideWatchLaterHome: true, autoRemoveWatched: false, pageOrder: [], settingsOrder: [], defaultPage: '', defaultSettingsPage: 'report'
  };
  // Keys that presets never touch.
  RT.PRESET_EXCLUDE = new Set(Object.keys(RT.SYSTEM_DEFAULTS).concat(['defaultPage', 'defaultSettingsPage']));

  RT.defaults = function () {
    const d = {};
    for (const id in ITEMS) {
      const it = ITEMS[id];
      if (it.type === 'button' || it.type === 'widget' || it.type === 'header') continue;
      d[id] = Array.isArray(it.def) ? it.def.slice() : it.def;
    }
    return Object.assign(d, RT.WL_DEFAULTS, RT.SYSTEM_DEFAULTS);
  };
  // Stored settings laid over the defaults. Views used to have one switch; someone who had it off keeps cards showing views.
  RT.mergeStored = (st) => {
    const s = Object.assign(RT.defaults(), st || {});
    if (st && st.hideCardViews === undefined && st.hideViews === false) s.hideCardViews = false;
    return s;
  };
  RT.featureKeys = () => Object.keys(ITEMS).concat(Object.keys(RT.WL_DEFAULTS));

  // Active tokens: enabled toggles (with `implies` expanded), select values,
  // multi options, plus any extra ids (temporary modes).
  RT.tokens = function (S, extra) {
    const on = new Set();
    const add = (id) => {
      if (on.has(id)) return;
      on.add(id);
      const it = ITEMS[id];
      if (it && it.implies) it.implies.forEach(add);
    };
    for (const id in ITEMS) {
      const it = ITEMS[id];
      const v = S[id];
      if (it.type === 'toggle') { if (v) add(id); }
      else if (it.type === 'select' && it.cssBy) { if (v != null && it.cssBy[v]) on.add(id + ':' + v); }
      else if (it.type === 'multi') { (Array.isArray(v) ? v : []).forEach((x) => on.add(id + ':' + x)); }
    }
    if (S.hideThumbnails) add('thumbsHideAll');
    (extra || []).forEach(add);
    return on;
  };

  const imp = (decl) =>
    decl.split(';').map((s) => s.trim()).filter(Boolean)
      .map((s) => (/!important/.test(s) ? s : s + ' !important')).join(';');

  RT.buildCss = function () {
    const out = [];
    const emit = (toks, sel, decl) => {
      const pre = 'html' + toks.map((t) => `[data-rt~="${t}"]`).join('');
      out.push((sel ? `${pre} ${sel}` : pre) + `{${decl}}`);
    };
    const spec = (token, s) => {
      (s.css || []).forEach((sel) => emit([token], sel, HIDE));
      (s.rules || []).forEach((r) => emit([token].concat(r[2] || []), r[0], imp(r[1])));
    };
    for (const id in ITEMS) {
      const it = ITEMS[id];
      if (it.type === 'toggle') spec(id, it);
      else if (it.type === 'select' && it.cssBy) { for (const v in it.cssBy) spec(id + ':' + v, it.cssBy[v]); }
      else if (it.type === 'multi') (it.options || []).forEach((o) => spec(id + ':' + o.v, o));
    }
    (RT.extraCss || []).forEach((r) => out.push(r));
    out.push('[data-rt-h]{display:none !important}');
    out.push('[data-rt-m]{opacity:.18 !important;filter:grayscale(1) !important;transition:opacity .2s}');
    out.push('[data-rt-m]:hover{opacity:1 !important;filter:none !important}');
    // DeArrow caps its replacement title at --cb-max-height (about three lines), so a long title loses its
    // last words when the card is hovered. Let the title grow to its full height while the card is hovered.
    const CARD_HOVER = ':is(yt-lockup-view-model,ytd-rich-item-renderer,ytd-video-renderer,ytd-compact-video-renderer,ytd-grid-video-renderer,ytd-playlist-video-renderer,ytd-rich-grid-media):hover';
    out.push(CARD_HOVER + ' :is([class*="cbTitle"],[class*="cbTitle"] span,.cbCustomTitle){-webkit-line-clamp:unset !important;max-height:none !important;overflow:visible !important}');
    out.push(CARD_HOVER + ' h3:has(:is([class*="cbTitle"],.cbCustomTitle)){max-height:none !important;overflow:visible !important;--cb-max-height:999px !important}');
    return out;
  };

  RT.pageType = function (loc) {
    const h = loc.hostname, p = loc.pathname;
    if (/^\/embed\//.test(p)) return 'embed';
    if (h.indexOf('youtube') === -1) return 'other';
    if (p === '/') return 'home';
    if (p === '/watch') return 'watch';
    if (p.indexOf('/shorts/') === 0) return 'shorts';
    if (p === '/results') return 'search';
    if (p === '/feed/subscriptions') return 'subs';
    if (p === '/playlist') return 'playlist';
    if (/^\/(@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)(\/|$)/.test(p)) return 'channel';
    return 'other';
  };

  // "HH:MM-HH:MM [Mon-Fri|Sat,Sun]" matching helper.
  const DAYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
  RT.inWindow = function (spec, d) {
    d = d || new Date();
    const m = String(spec).trim().match(/^(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})\s*(.*)$/);
    if (!m) return false;
    const now = d.getHours() * 60 + d.getMinutes();
    const a = +m[1] * 60 + +m[2], b = +m[3] * 60 + +m[4];
    const inTime = a <= b ? now >= a && now < b : now >= a || now < b;
    if (!inTime) return false;
    const days = m[5].trim().toLowerCase();
    if (!days) return true;
    const set = new Set();
    days.split(/[,\s]+/).forEach((part) => {
      const r = part.match(/^([a-z]{3})[a-z]*(?:-([a-z]{3})[a-z]*)?$/);
      if (!r) return;
      let i = DAYS.indexOf(r[1]);
      if (i < 0) return;
      if (!r[2]) { set.add(i); return; }
      const j = DAYS.indexOf(r[2]);
      for (let k = 0; k < 7 && j >= 0; k++) { set.add(i); if (i === j) break; i = (i + 1) % 7; }
    });
    return set.has(d.getDay());
  };
  // Lines: "09:00-17:00 Mon-Fri => Work" and optional "* => Relax" fallback.
  RT.pickPreset = function (textVal, d) {
    let fallback = null;
    for (const line of RT.lines(textVal)) {
      const [lhs, rhs] = line.split('=>').map((s) => s.trim());
      if (!rhs) continue;
      if (lhs === '*') { fallback = rhs; continue; }
      if (RT.inWindow(lhs, d)) return rhs;
    }
    return fallback;
  };

  // ---- presets (needs chrome.storage) ------------------------------------------------
  RT.presetKeys = () => Object.keys(ITEMS).filter((k) => !/^(widget|header)$/.test(ITEMS[k].type));
  RT.presetNames = (user) => Object.keys(RT.BUILTIN_PRESETS || {}).concat(Object.keys(user || {}).filter((n) => !(RT.BUILTIN_PRESETS || {})[n]));
  RT.snapshot = (S) => { const o = {}; RT.presetKeys().forEach((k) => { o[k] = S[k]; }); return o; };
  RT.applyPreset = function (name, cb) {
    chrome.storage.local.get(['rtPresets'], (st) => {
      const user = (st.rtPresets || {})[name];
      const vals = user ? user.values || user : (RT.BUILTIN_PRESETS || {})[name];
      if (!vals) { if (cb) cb(false); return; }
      const d = RT.defaults(), out = {};
      RT.presetKeys().forEach((k) => { out[k] = d[k]; });
      chrome.storage.local.set(Object.assign(out, vals, { activePreset: name }), () => { if (cb) cb(true); });
    });
  };

  RT.sha256 = async function (str) {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
    return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
  };
  RT.checkPassword = async (S, pw) => !S.pwHash || (await RT.sha256(S.pwSalt + pw)) === S.pwHash;
})(typeof window !== 'undefined' ? window : globalThis);
