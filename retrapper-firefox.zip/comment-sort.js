// Comment sorter. Reorders the loaded top-level comments with CSS `order`
// (the page's own list is never touched), keeping pinned comments first.
(function () {
  'use strict';
  const RT = window.RT;
  if (!RT) return;
  const OPTIONS = [
    ['top', 'Top', 'Featured comments'],
    ['newest', 'Newest', 'Recent comments, including potential spam'],
    ['likes', 'Most liked', 'Pinned comments stay first'],
    ['replies', 'Most replied', 'Pinned comments stay first']
  ];
  const NAME = { top: 'Top', newest: 'Newest', likes: 'Most liked', replies: 'Most replied' };
  const YT_INDEX = { top: 0, newest: 1 };
  const PIN = -2147483000, LAST = 2147483000;

  const mode = () => {
    const v = RT.state && RT.state.S && RT.state.S.commentSort;
    return NAME[v] ? v : 'top';
  };
  let ytSort = 'top'; // which of YouTube's own sorts is showing

  function count(str) {
    const m = String(str || '').replace(/,/g, '').match(/([\d.]+)\s*([KMB])?/i);
    if (!m) return 0;
    const mult = { K: 1e3, M: 1e6, B: 1e9 }[(m[2] || '').toUpperCase()] || 1;
    return Math.round(parseFloat(m[1]) * mult) || 0;
  }
  const own = (thread, sel) => [...thread.querySelectorAll(sel)].find((e) => !e.closest('#replies'));

  function likes(thread) {
    const v = own(thread, '#vote-count-middle');
    const t = v && v.textContent.trim();
    if (t) return count(t);
    const b = own(thread, '#like-button button, like-button-view-model button, #like-button');
    const a = (b && b.getAttribute('aria-label')) || '';
    const m = a.match(/along with ([\d,.]+\s*[KMB]?)/i);
    return m ? count(m[1]) + 1 : 0;
  }
  function replies(thread) {
    const r = thread.querySelector('ytd-comment-replies-renderer');
    if (!r) return 0;
    const els = [...r.querySelectorAll('#more-replies button, #more-replies, .more-button')];
    for (const el of els) {
      const n = count(el.getAttribute('aria-label') || el.textContent || '');
      if (n) return n;
    }
    return 0;
  }
  // the pinned badge: YouTube has used both ytd- and ytw- element names; match either, and the host class as a fallback
  const pinned = (thread) => !!own(thread, 'ytd-pinned-comment-badge-renderer, ytw-pinned-comment-badge-renderer, [class*="PinnedCommentBadge"]');

  function clear(parent) {
    if (!parent) return;
    parent.style.removeProperty('display');
    parent.style.removeProperty('flex-direction');
    [...parent.children].forEach((c) => c.style.removeProperty('order'));
  }

  function run() {
    const threads = [...document.querySelectorAll('ytd-comments ytd-comment-thread-renderer')]
      .filter((t) => !t.closest('ytd-comment-replies-renderer'));
    const parents = new Set(threads.map((t) => t.parentElement));
    const m = RT.page() === 'watch' ? mode() : 'top';
    const client = m === 'likes' || m === 'replies' ? m : 'off';
    parents.forEach((p) => {
      if (!p) return;
      if (client === 'off') { if (p.__rtSorted) { clear(p); p.__rtSorted = false; } return; }
      p.__rtSorted = true;
      p.style.display = 'flex';
      p.style.flexDirection = 'column';
      [...p.children].forEach((c) => {
        if (c.tagName === 'YTD-COMMENT-THREAD-RENDERER') {
          const score = client === 'replies' ? replies(c) * 1e6 + likes(c) : likes(c);
          c.style.order = String(pinned(c) ? PIN : -Math.min(score, 2e9));
        } else if (/CONTINUATION/.test(c.tagName)) c.style.order = String(LAST);
      });
    });
    chip();
    gifPass();
    autoStartLoadAll();
    onVideo();
  }

  // --- hide GIFs / images in comments ------------------------------------------------------------------
  // YouTube added image/GIF attachments to comments. We find them structurally (a sizeable image, or one from
  // a GIF host, that is not an avatar, custom emoji or badge) so it works whether the GIF sits inside the
  // comment text or in its own attachment box. A comment that is only a GIF (no text) is hidden entirely.
  const GIF_SKIP = '#author-thumbnail, #avatar, a#author-thumbnail, ytd-author-comment-badge-renderer, [id*="badge" i], #creator-heart, #sponsor-comment-badge, #channel-heart, #linked-comment-badge';
  function gifImgs(cm) {
    return [...cm.querySelectorAll('img, .yt-core-image')].filter((im) => {
      if (im.closest(GIF_SKIP)) return false;
      const src = im.currentSrc || im.src || im.getAttribute('src') || '';
      if (/tenor|giphy|\.gif(\?|$)|webp_animated/i.test(src)) return true; // GIF host / animated-webp / .gif
      const r = im.getBoundingClientRect();
      return r.width >= 48 && r.height >= 48;                        // large enough to be an attachment, not an emoji
    });
  }
  const commentText = (cm) => { const ct = cm.querySelector('#content-text'); return ct ? ct.textContent.replace(/\s+/g, ' ').trim() : ''; };
  // the media-only wrapper around an image, so hiding it collapses the attachment box but never swallows text
  function gifWrap(im, cm) {
    let n = im;
    const ct = cm.querySelector('#content-text');
    while (n.parentElement && n.parentElement !== cm && n.parentElement !== ct) {
      if ((n.parentElement.textContent || '').trim() !== '') break; // parent has text → stop, hide just the media
      n = n.parentElement;
    }
    return n;
  }
  // The attachment pieces to drop: YouTube's own comment image/GIF element (confirmed), plus a size/host
  // fallback for any variant it doesn't cover. The explicit element also matches before the image has loaded.
  function gifAttachments(cm) {
    const set = new Set();
    cm.querySelectorAll('ytw-comment-image-attachment-view-model, [class*="CommentImageAttachment" i]').forEach((a) => set.add(a));
    gifImgs(cm).forEach((im) => { if (!im.closest('ytw-comment-image-attachment-view-model')) set.add(gifWrap(im, cm)); });
    return [...set];
  }
  function gifPass() {
    const want = RT.on ? RT.on('hideCommentGifs') : false;
    const views = [...document.querySelectorAll('ytd-comments ytd-comment-view-model')];
    views.forEach((cm) => {
      if (!want) {
        cm.querySelectorAll('[data-rt-gif]').forEach((e) => { e.style.removeProperty('display'); e.removeAttribute('data-rt-gif'); });
        [cm, cm.closest('ytd-comment-thread-renderer')].forEach((h) => { if (h && h.hasAttribute('data-rt-gifonly')) { h.style.removeProperty('display'); h.removeAttribute('data-rt-gifonly'); } });
        return;
      }
      const atts = gifAttachments(cm);
      if (!atts.length) return;
      if (commentText(cm) === '') {
        const isReply = !!cm.closest('#replies, ytd-comment-replies-renderer');
        const host = isReply ? cm : (cm.closest('ytd-comment-thread-renderer') || cm);
        if (!host.hasAttribute('data-rt-gifonly')) { host.style.display = 'none'; host.setAttribute('data-rt-gifonly', '1'); }
      } else {
        atts.forEach((a) => { if (!a.hasAttribute('data-rt-gif')) { a.style.display = 'none'; a.setAttribute('data-rt-gif', '1'); } });
      }
    });
  }

  // Drives YouTube's own (hidden) sort menu for Top / Newest.
  function ytSelect(which, tries) {
    const menu = document.querySelector('ytd-comments-header-renderer #sort-menu');
    if (!menu) { if ((tries || 0) < 10) setTimeout(() => ytSelect(which, (tries || 0) + 1), 400); return; }
    const trigger = menu.querySelector('#trigger, tp-yt-paper-button, #label, button');
    if (!trigger) return;
    trigger.click();
    setTimeout(() => {
      const items = menu.querySelectorAll('tp-yt-paper-listbox a, #menu a, a[role="option"], tp-yt-paper-item');
      const item = items[YT_INDEX[which]];
      if (item) item.click();
      else trigger.click(); // close again
      ytSort = which;
    }, 180);
  }

  function choose(v) {
    try { chrome.storage.local.set({ commentSort: v }); } catch (err) { /* ignore */ }
    if (RT.state && RT.state.S) RT.state.S.commentSort = v;
    const want = v === 'newest' ? 'newest' : 'top'; // likes/replies sort YouTube's Top list
    if (want !== ytSort) ytSelect(want);
    run();
    if (v === 'likes' || v === 'replies') gatherMore(); // pull in more pages so the ranking has more to sort
  }

  // --- auto-gather: load more comment pages so Most liked / Most replied rank a larger pool --------------
  // YouTube loads comments a page (~20) at a time as the continuation scrolls into view. For the two
  // client-side sorts we briefly drive that loading ourselves up to a cap, re-sorting as they arrive, then
  // put the scroll position back. It yields to the user: any real scroll / key / wheel input aborts it.
  const GATHER_CAP = 250, MAX_PULSES = 25, PULSE_MS = 450;
  const ALL_CAP = 100000, ALL_PULSES = 4000; // "load all": effectively unbounded, with a safety ceiling
  const loadAll = () => !!(RT.on && RT.on('commentLoadAll'));
  const topThreads = () => [...document.querySelectorAll('ytd-comments ytd-comment-thread-renderer')].filter((t) => !t.closest('ytd-comment-replies-renderer'));
  const contItem = () => [...document.querySelectorAll('ytd-comments ytd-continuation-item-renderer')].find((c) => !c.closest('#replies'));
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  let gathering = false, abortGather = false;
  function stopGather() { if (gathering) abortGather = true; }
  ['wheel', 'touchmove', 'mousedown'].forEach((ev) => window.addEventListener(ev, stopGather, { passive: true }));
  window.addEventListener('keydown', (e) => { if (['PageUp', 'PageDown', 'Home', 'End', 'ArrowUp', 'ArrowDown', ' '].indexOf(e.key) !== -1) stopGather(); });

  // To load comments YouTube has to scroll them into view, which would scroll the video away. So while a
  // "load all" gather runs with the viewer still up at the video, we float the player in the corner (it keeps
  // playing) and put it straight back when done — the viewer can just keep watching without scrolling.
  let floatStyle = null;
  function floatVideo(on) {
    const mp = document.querySelector('#movie_player');
    if (!mp) return;
    if (on) {
      if (floatStyle !== null) return;
      floatStyle = mp.getAttribute('style') || '';
      mp.style.cssText += ';position:fixed;right:16px;bottom:16px;width:min(32vw,480px);height:auto;aspect-ratio:16/9;z-index:2500;border-radius:12px;overflow:hidden;box-shadow:0 6px 28px rgba(0,0,0,.55)';
      mp.setAttribute('data-rt-floated', '1');
    } else {
      if (floatStyle === null) return;
      if (floatStyle) mp.setAttribute('style', floatStyle); else mp.removeAttribute('style');
      mp.removeAttribute('data-rt-floated');
      floatStyle = null;
    }
  }

  async function gatherMore() {
    if (gathering || RT.page() !== 'watch') return;
    const m = mode();
    const all = loadAll();
    if (!all && m !== 'likes' && m !== 'replies') return; // nothing to do for Top/Newest unless "load all" is on
    const cap = all ? ALL_CAP : GATHER_CAP;
    const pulses = all ? ALL_PULSES : MAX_PULSES;
    const se = document.scrollingElement || document.documentElement;
    const startY = se.scrollTop;
    const floatIt = all && startY < 300; // viewer is still up at the video → keep it visible while we load
    gathering = true; abortGather = false;
    if (floatIt) floatVideo(true);
    let last = topThreads().length, stale = 0;
    try {
      for (let i = 0; i < pulses && !abortGather; i++) {
        if (topThreads().length >= cap) break;
        const c = contItem();
        if (!c) break; // no continuation left → the whole section is loaded
        c.scrollIntoView({ block: 'center' });
        await wait(PULSE_MS);
        if (abortGather) break;
        run();
        const now = topThreads().length;
        if (now <= last) { if (++stale >= 3) break; } else stale = 0;
        last = now;
      }
    } finally {
      gathering = false;
      se.scrollTop = startY; window.scrollTo(0, startY);
      if (floatIt) floatVideo(false);
      run();
    }
  }

  // With "Load all comments" on, start the gather automatically in the background as soon as the first
  // comments render — the viewer never has to scroll down to it. One-shot per video.
  let autoVid = '';
  function autoStartLoadAll() {
    if (!loadAll() || RT.page() !== 'watch' || gathering) return;
    if (!document.querySelector('ytd-comments') || topThreads().length < 1) return; // wait for the first page
    const vid = new URLSearchParams(location.search).get('v') || '';
    if (!vid || vid === autoVid) return;
    autoVid = vid;
    setTimeout(() => { if (loadAll() && !gathering && RT.page() === 'watch') gatherMore(); }, 1200);
  }

  // Colours come from ReTrapper's theme detector, so they follow the page's
  // real light / dark state instead of relying on YouTube's CSS variables.
  function pal() {
    const t = (RT.theme && RT.theme.theme) || (RT.detectTheme && RT.detectTheme().theme) || 'light';
    return t === 'dark'
      ? { fg: '#f1f1f1', sub: '#aaaaaa', menu: '#282828', hover: 'rgba(255,255,255,.15)', shadow: '0 4px 32px rgba(0,0,0,.6)' }
      : { fg: '#0f0f0f', sub: '#606060', menu: '#ffffff', hover: 'rgba(0,0,0,.08)', shadow: '0 4px 32px rgba(0,0,0,.25)' };
  }
  function paintChip() {
    const el = document.getElementById('rt-comment-sort');
    if (el) { el.style.color = pal().fg; el.style.background = 'transparent'; }
  }
  RT.bus.addEventListener('theme', () => { paintChip(); closePopup(); });

  let popup = null;
  const closePopup = () => { if (popup) { popup.remove(); popup = null; } };
  function openPopup(btn) {
    closePopup();
    popup = document.createElement('div');
    popup.id = 'rt-comment-sort-menu';
    popup.style.cssText = 'position:absolute;z-index:3000;min-width:260px;padding:8px 0;border-radius:12px;' +
      'background:' + pal().menu + ';color:' + pal().fg + ';box-shadow:' + pal().shadow + ';font-family:Roboto,Arial,sans-serif';
    OPTIONS.forEach(([id, label, sub]) => {
      const row = document.createElement('div');
      row.style.cssText = 'padding:8px 16px 8px 40px;cursor:pointer;position:relative;line-height:1.3';
      const t = document.createElement('div'); t.textContent = label; t.style.cssText = 'font-size:14px;font-weight:' + (id === mode() ? 600 : 400);
      const d = document.createElement('div'); d.textContent = sub; d.style.cssText = 'font-size:12px;color:' + pal().sub;
      if (id === mode()) { const ck = document.createElement('span'); ck.textContent = '✓'; ck.style.cssText = 'position:absolute;left:14px;top:8px;font-size:14px'; row.appendChild(ck); }
      row.append(t, d);
      row.addEventListener('mouseenter', () => { row.style.background = pal().hover; });
      row.addEventListener('mouseleave', () => { row.style.background = ''; });
      row.addEventListener('click', (e) => { e.stopPropagation(); closePopup(); choose(id); });
      popup.appendChild(row);
    });
    document.body.appendChild(popup);
    const r = btn.getBoundingClientRect();
    popup.style.left = Math.max(8, Math.min(r.left + scrollX, scrollX + innerWidth - 276)) + 'px';
    popup.style.top = r.bottom + scrollY + 6 + 'px';
  }
  document.addEventListener('click', (e) => { if (popup && !popup.contains(e.target) && e.target.id !== 'rt-comment-sort') closePopup(); }, true);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closePopup(); });

  // Our "Sort by" button replaces YouTube's, in the same spot.
  function chip() {
    const hdr = document.querySelector('ytd-comments-header-renderer');
    let el = document.getElementById('rt-comment-sort');
    if (!hdr || RT.page() !== 'watch') { if (el) el.remove(); closePopup(); return; }
    const menu = hdr.querySelector('#sort-menu');
    if (menu && !menu.__rtHidden) {
      menu.__rtHidden = true;
      // Kept in the page (we drive it for Top / Newest) but invisible.
      menu.style.cssText += ';position:absolute !important;opacity:0 !important;pointer-events:none !important;width:1px;height:1px;overflow:hidden';
    }
    if (!el) {
      el = document.createElement('button');
      el.id = 'rt-comment-sort';
      el.type = 'button';
      el.style.cssText = 'display:inline-flex;align-items:center;gap:6px;vertical-align:middle;margin-left:8px;padding:0 12px;height:36px;border-radius:18px;border:0;cursor:pointer;' +
        'font:500 14px Roboto,Arial,sans-serif;background:transparent;color:' + pal().fg;
      el.addEventListener('mouseenter', () => { el.style.background = pal().hover; });
      el.addEventListener('mouseleave', () => { el.style.background = 'transparent'; });
      el.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); popup ? closePopup() : openPopup(el); });
    }
    const head = menu ? menu.parentElement : hdr.querySelector('#title') || hdr;
    if (menu) { if (el.previousElementSibling !== menu) menu.after(el); }
    else if (el.parentElement !== head) head.appendChild(el);
    paintChip();
    const text = gathering
      ? 'Sort by: ' + NAME[mode()] + ' · loading ' + topThreads().length + '… ▾'
      : 'Sort by: ' + NAME[mode()] + ' ▾';
    if (el.textContent !== text) el.textContent = text;
  }

  // New video: YouTube starts on Top again; apply the saved choice.
  let lastVid = '';
  function onVideo() {
    const id = new URLSearchParams(location.search).get('v') || '';
    if (!id || id === lastVid || RT.page() !== 'watch') return;
    lastVid = id;
    ytSort = 'top';
    if (mode() === 'newest') setTimeout(() => ytSelect('newest'), 1500);
  }

  let t = 0;
  const soon = () => { clearTimeout(t); t = setTimeout(run, 150); };
  ['apply', 'navigate', 'dom'].forEach((ev) => RT.bus.addEventListener(ev, soon));
  setInterval(() => { if (RT.page() === 'watch') run(); }, 2500);
})();
