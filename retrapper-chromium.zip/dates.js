// Shows the exact upload date (DD/MM/YYYY HH:MM) in place of "3 days ago" on
// the home page, subscriptions, search, recommendations, the video page and
// Shorts. The time is only shown when YouTube provides one.
(function () {
  'use strict';
  const RT = window.RT;
  if (!RT) return;
  try { document.documentElement.dataset.rtVersion = chrome.runtime.getManifest().version; } catch (e) { /* ignore */ }
  const KEY = 'rtDates';
  const cache = new Map(); // id -> formatted string | '' (known to be unavailable)
  const waiting = new Set();
  const failedAt = new Map();

  try {
    const saved = JSON.parse(localStorage.getItem(KEY) || '{}');
    Object.keys(saved).forEach((k) => cache.set(k, saved[k]));
  } catch (e) { /* no cache */ }
  let saveTimer = 0;
  function save() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      try {
        const o = {};
        [...cache.entries()].filter(([, v]) => v).slice(-4000).forEach(([k, v]) => { o[k] = v; });
        localStorage.setItem(KEY, JSON.stringify(o));
      } catch (e) { /* storage full or blocked */ }
    }, 1500);
  }

  const pad = (n) => String(n).padStart(2, '0');
  function format(iso) {
    if (!iso) return '';
    if (/T/.test(iso)) {
      const d = new Date(iso);
      if (isNaN(d)) return '';
      return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
    }
    const m = iso.match(/^(\d{4})-(\d{2})-(\d{2})/);
    return m ? `${m[3]}/${m[2]}/${m[1]}` : ''; // date only: no time to show
  }

  const enabled = () => !!(RT.state && RT.state.tokens.has('showFullDates') && !RT.state.tokens.has('hidePubDate') && !RT.state.tokens.has('hideTimeSince'));

  const de = document.documentElement;
  const stat = { req: 0, bridge: 0, fallback: 0, none: 0, err: '' };
  const report = () => { de.dataset.rtDatesInfo = JSON.stringify(stat); };

  // For other parts of ReTrapper (the Watch Later shelf): the formatted date for a video, if known.
  RT.dateOf = (id) => {
    if (!enabled()) return '';
    const v = cache.get(id);
    if (v) return v;
    request(id);
    return '';
  };

  function got(id, iso, via) {
    waiting.delete(id);
    const f = format(iso);
    if (f) { cache.set(id, f); stat[via]++; de.dataset.rtDates = 'ok ' + id; }
    else { failedAt.set(id, Date.now()); stat.none++; de.dataset.rtDates = 'none ' + id; }
    report();
    save();
    scan();
    window.dispatchEvent(new CustomEvent('rt-dates-changed'));
  }

  window.addEventListener('rt-date-res', (e) => {
    let r;
    try { r = JSON.parse(e.detail); } catch (err) { return; }
    if (r && r.id && !cache.has(r.id)) got(r.id, r.date, 'bridge');
  });

  // Fallback that does not depend on the page bridge: read the video's own
  // page and stop as soon as the upload date has streamed past.
  let fbActive = 0;
  const fbQueue = [];
  async function fallbackFetch(id) {
    try {
      const res = await fetch('/watch?v=' + encodeURIComponent(id), { credentials: 'same-origin' });
      if (!res.ok || !res.body) return '';
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = '';
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const m = buf.match(/"(?:uploadDate|publishDate)":"([^"]+)"/);
        if (m) { reader.cancel(); return m[1]; }
        if (buf.length > 4e6) { reader.cancel(); break; }
      }
    } catch (e) { stat.err = String(e).slice(0, 80); }
    return '';
  }
  function pumpFallback() {
    while (fbActive < 2 && fbQueue.length) {
      const id = fbQueue.shift();
      if (cache.has(id)) continue;
      fbActive++;
      fallbackFetch(id).then((iso) => { fbActive--; if (!cache.has(id)) got(id, iso, 'fallback'); pumpFallback(); });
    }
  }

  function request(id) {
    if (cache.has(id) || waiting.has(id)) return;
    if (failedAt.has(id) && Date.now() - failedAt.get(id) < 10 * 60 * 1000) return;
    if (waiting.size >= 30) return;
    waiting.add(id);
    stat.req++; report();
    window.dispatchEvent(new CustomEvent('rt-date-req', { detail: JSON.stringify({ id }) }));
    // If the page bridge has not answered shortly, look it up directly.
    setTimeout(() => { if (waiting.has(id) && !cache.has(id)) { fbQueue.push(id); pumpFallback(); } }, 3000);
    setTimeout(() => waiting.delete(id), 20000);
  }

  function setText(el, text) {
    if (el.textContent !== text) {
      if (!el.dataset.rtOrig) el.dataset.rtOrig = el.textContent;
      el.textContent = text;
    }
  }
  const isFiller = (s) => /^[•·\s]*$/.test(s);
  const skip = /watching|waiting|premiere|scheduled|upcoming/i;

  // Text that is a bare date: "Mar 2, 2026", "2 Mar 2026", "3 days ago", "Streamed live on ..."
  const DATE_TEXT = /^((streamed live on|streamed|premiered|published on|started streaming)\s+)?((?:[A-Za-z]{3,9}\.?\s+\d{1,2},?\s+\d{4})|(?:\d{1,2}\s+[A-Za-z]{3,9}\.?\s+\d{4})|(?:.*\bago))$/i;
  const COMBINED = /^(.*?)(\s*[•·]\s*)((?:streamed|premiered)?\s*.*\bago)$/i;
  const NOT_META = '#video-title, #video-title-link, h3, ytd-channel-name, #channel-name, #description-text, .metadata-snippet-text, [class*="Snippet"]';

  function cardDate(card) {
    const link = card.matches('a[href*="/watch?v="]') ? card : card.querySelector('a[href*="/watch?v="]');
    const m = link && (link.getAttribute('href') || '').match(/[?&]v=([\w-]{11})/);
    if (!m) return;
    const id = m[1];
    const f = cache.get(id);

    // 1) By content: any small text in the card that reads like a date / "x ago".
    //    Independent of YouTube's (frequently renamed) class names.
    const leaves = [...card.querySelectorAll('span, yt-formatted-string')].filter((e) => !e.children.length && !e.closest(NOT_META));
    for (const e of leaves) {
      const orig = (e.dataset.rtOrig || e.textContent || '').trim();
      if (!orig || orig.length > 80 || skip.test(orig)) continue;
      const c = orig.match(COMBINED);
      if (c && !skip.test(c[3])) { if (f) setText(e, c[1] + c[2] + f); else request(id); return; }
      if (DATE_TEXT.test(orig)) { if (f) setText(e, f); else request(id); return; }
    }

    // 2) By position: second item of the metadata row (other languages).
    const rows = card.querySelectorAll('#metadata-line, [class*="etadataRow"], [class*="metadata-row"]');
    for (const row of rows) {
      const spans = [...row.querySelectorAll('span')]
        .filter((s) => !s.children.length && !isFiller(s.dataset.rtOrig || s.textContent) && !s.closest(NOT_META));
      if (spans.length < 2) continue;
      const target = spans[spans.length - 1];
      if (skip.test(target.dataset.rtOrig || target.textContent)) return;
      if (f) setText(target, f); else request(id);
      return;
    }
  }

  const NOT_INFO = 'yt-animated-rolling-number, animated-rolling-character, #view-count, #snippet, #expanded, #attributed-snippet-text, ytd-text-inline-expander, #comments, ytd-comments, #owner, #actions, #title';

  function watchDate() {
    const id = new URLSearchParams(location.search).get('v') || '';
    if (!/^[\w-]{11}$/.test(id)) return;
    const f = cache.get(id);
    const found = new Set();
    // YouTube's info line, both collapsed ("3 days ago") and expanded ("Mar 2, 2026").
    document.querySelectorAll('ytd-watch-metadata *, ytd-watch-info-text *').forEach((e) => {
      if (e.children.length || e.closest(NOT_INFO)) return;
      const t = (e.dataset.rtOrig || e.textContent || '').trim();
      if (t && t.length < 60 && !/watching|waiting|scheduled|upcoming/i.test(t) && DATE_TEXT.test(t)) found.add(e);
    });
    // Fallback by position when the wording is not recognised.
    if (!found.size) {
      const spans = [...document.querySelectorAll('ytd-watch-metadata #info span, ytd-watch-info-text #info span')]
        .filter((s) => !s.querySelector('span') && !isFiller(s.dataset.rtOrig || s.textContent) && !/^#/.test(s.textContent.trim()));
      if (spans[1] && !skip.test(spans[1].textContent)) found.add(spans[1]);
    }
    if (found.size) { if (f) found.forEach((e) => setText(e, f)); else request(id); }
    deepDate(id, f);
  }

  // Catch-all for a date that sits in a text node the element search cannot
  // see (inside a shadow root, or in a container outside the info line).
  const BARE_DATE = /^((streamed live on|streamed|premiered|published on|started streaming)\s+)?((?:[A-Za-z]{3,9}\.?\s+\d{1,2},?\s+\d{4})|(?:\d{1,2}\s+[A-Za-z]{3,9}\.?\s+\d{4}))$/i;
  const origText = new WeakMap();
  function deepDate(id, f) {
    const root = document.querySelector('ytd-watch-metadata');
    if (!root) return;
    const stack = [root];
    let seen = false;
    while (stack.length) {
      const n = stack.pop();
      if (n.nodeType === 3) {
        if (n.parentNode && n.parentNode.closest && n.parentNode.closest('yt-animated-rolling-number, animated-rolling-character')) continue;
        const orig = origText.get(n) || n.nodeValue.trim();
        if (orig.length < 40 && BARE_DATE.test(orig)) {
          seen = true;
          if (f) {
            if (!origText.has(n)) origText.set(n, orig);
            if (n.nodeValue !== f) n.nodeValue = f;
          }
        }
        continue;
      }
      if (n.shadowRoot) stack.push(n.shadowRoot);
      for (let c = n.lastChild; c; c = c.previousSibling) stack.push(c);
    }
    if (seen && !f) request(id);
  }

  // The overlay shown over the paused player: "Channel   2,301,262 views   5y ago".
  function overlayDate() {
    const id = new URLSearchParams(location.search).get('v') || '';
    const f = cache.get(id);
    if (!f) return;
    document.querySelectorAll('[class*="PlayerOverlayVideoDetails"] span').forEach((e) => {
      if (e.children.length) return;
      const t = e.dataset.rtOrig || e.textContent;
      const m = t.match(/^(.*?)(\d+\s*[a-z]+\s+ago)\s*$/i);
      if (m) setText(e, m[1] + f);
    });
  }

  function shortDate() {
    const m = location.pathname.match(/^\/shorts\/([\w-]{11})/);
    let el = document.getElementById('rt-short-date');
    if (!m) { if (el) el.remove(); return; }
    const host = document.querySelector('ytd-reel-video-renderer[is-active] #metapanel, ytd-reel-video-renderer[is-active] ytd-reel-player-overlay-renderer');
    const f = cache.get(m[1]);
    if (!f) { request(m[1]); if (el) el.remove(); return; }
    if (!host) return;
    if (!el) {
      el = document.createElement('div');
      el.id = 'rt-short-date';
      el.style.cssText = 'font:500 12px Roboto,Arial,sans-serif;color:#fff;text-shadow:0 0 4px rgba(0,0,0,.8);margin:0 0 6px 0;pointer-events:none';
    }
    if (el.dataset.id !== m[1]) { el.dataset.id = m[1]; el.textContent = f; }
    if (el.parentElement !== host) host.prepend(el);
  }

  function inView(el) {
    const r = el.getBoundingClientRect();
    return r.bottom > -300 && r.top < innerHeight + 1500;
  }

  function scan() {
    try { scanInner(); } catch (e) { stat.err = String(e).slice(0, 120); report(); }
  }

  function scanInner() {
    if (!enabled()) {
      document.querySelectorAll('[data-rt-orig]').forEach((e) => { e.textContent = e.dataset.rtOrig; delete e.dataset.rtOrig; });
      const s = document.getElementById('rt-short-date'); if (s) s.remove();
      return;
    }
    const page = RT.page();
    if (page === 'watch') { watchDate(); overlayDate(); }
    if (page === 'shorts') shortDate();
    if (page !== 'shorts' && page !== 'embed') {
      document.querySelectorAll((RT.CARD_SEL || 'ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer, yt-lockup-view-model') + ', a.ytp-modern-videowall-still, a.ytp-videowall-still').forEach((c) => {
        if (inView(c)) cardDate(c);
      });
    }
  }

  let t = 0;
  const soon = () => { clearTimeout(t); t = setTimeout(scan, 200); };
  ['apply', 'dom', 'navigate'].forEach((ev) => RT.bus.addEventListener(ev, soon));
  window.addEventListener('scroll', soon, { passive: true });
  document.addEventListener('yt-navigate-finish', () => setTimeout(scan, 500));
  setInterval(scan, 2000); // YouTube re-renders metadata text; keep ours on top
})();
