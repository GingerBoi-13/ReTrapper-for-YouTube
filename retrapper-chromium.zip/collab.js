// Collab videos: YouTube shows "A and B" (or "A, B and 2 more") as one block that opens a popup.
// This turns each channel name into its own link, so you can go straight to either channel.
(function () {
  'use strict';
  const RT = window.RT;
  if (!RT) return;
  let vid = '', channels = null, tries = 0, waiting = false, lastAsk = 0;

  window.addEventListener('rt-collab-res', (e) => {
    waiting = false;
    let r; try { r = JSON.parse(e.detail); } catch (err) { return; }
    if (r.v !== vid) return;
    channels = r.channels || [];
    if (channels.length < 2 && tries < 6) { channels = null; return; } // the data may not be ready yet; ask again
    document.documentElement.setAttribute('data-rt-collab', 'channels:' + channels.length);
    apply();
  });

  function go(ch, ev) {
    ev.stopPropagation();
    if (ev.button !== 0 || ev.ctrlKey || ev.metaKey || ev.shiftKey || ev.altKey) return; // open in a new tab the normal way
    ev.preventDefault();
    const detail = {
      commandMetadata: { webCommandMetadata: { url: ch.path, webPageType: 'WEB_PAGE_TYPE_CHANNEL', rootVe: 3611 } },
      browseEndpoint: { browseId: ch.id, canonicalBaseUrl: ch.path }
    };
    window.dispatchEvent(new CustomEvent('watch-later-shelf-navigate', { detail: JSON.stringify(detail) }));
    const from = location.href;
    setTimeout(() => { if (location.href === from) location.assign(ch.path); }, 1500);
  }
  // Fallback: take the picture from YouTube's own overlapping avatar stack, in the same order as the channels.
  function avatarFor(ch) {
    const i = channels.indexOf(ch);
    const els = document.querySelectorAll('ytd-video-owner-renderer yt-avatar-stack-view-model avatar-view-model');
    const el = els[i];
    if (!el) return '';
    const img = el.querySelector('img');
    if (img && img.src) return img.src;
    let m = '';
    el.querySelectorAll('*').forEach((x) => { if (!m) { const bg = (x.style && x.style.backgroundImage) || getComputedStyle(x).backgroundImage; const r = /url\(["']?([^"')]+)/.exec(bg || ''); if (r) m = r[1]; } });
    return m;
  }
  function link(ch, plain) {
    const a = document.createElement('a');
    a.href = ch.path; a.setAttribute('data-rt-collab', ch.id); a.title = 'Go to ' + ch.name;
    a.style.cssText = plain ? 'color:inherit;text-decoration:none;cursor:pointer' : 'color:inherit;text-decoration:none;cursor:pointer;display:inline-flex;align-items:center;gap:8px;vertical-align:middle;line-height:24px';
    const src = plain ? '' : (ch.img || avatarFor(ch));
    if (src) {
      const im = document.createElement('img');
      im.src = src; im.alt = ''; im.setAttribute('data-rt-collab-img', '1');
      im.style.cssText = 'width:24px;height:24px;border-radius:50%;object-fit:cover;flex:none';
      a.appendChild(im);
    }
    a.appendChild(document.createTextNode(ch.name));
    if (ch.verified && !plain) {
      const v = document.createElement('span');
      v.setAttribute('data-rt-collab-badge', '1'); v.title = 'Verified';
      v.style.cssText = 'display:inline-flex;flex:none;width:14px;height:14px;margin-left:-2px;opacity:.7';
      v.innerHTML = '<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M12 2a10 10 0 100 20 10 10 0 000-20zm-2 15l-5-5 1.4-1.4L10 14.2l7.6-7.6L19 8l-9 9z"/></svg>';
      a.appendChild(v);
    }
    a.addEventListener('mouseenter', () => { a.style.textDecoration = 'underline'; });
    a.addEventListener('mouseleave', () => { a.style.textDecoration = 'none'; });
    a.addEventListener('click', (ev) => go(ch, ev), true);
    a.addEventListener('mousedown', (ev) => ev.stopPropagation());
    return a;
  }

  // Splits a piece of text into plain text and channel links. Returns null unless it really lists 2+ channels.
  function build(raw, list, plain, min) {
    list = list || channels;
    const text = (raw || '').replace(/\s+/g, ' ').trim();
    if (!text) return null;
    const left = list.slice();
    const parts = []; // strings are plain text, elements are channel links
    let rest = text, placed = 0;
    const done = new Set();
    while (rest) {
      let best = -1, bi = -1;
      left.forEach((c, i) => { const p = rest.indexOf(c.name); if (p >= 0 && (best < 0 || p < best || (p === best && c.name.length > left[bi].name.length))) { best = p; bi = i; } });
      if (bi < 0) break;
      if (best > 0) parts.push(rest.slice(0, best));
      parts.push(link(left[bi], plain)); placed++; done.add(left[bi].id);
      rest = rest.slice(best + left[bi].name.length);
      left.splice(bi, 1);
    }
    if (rest) {
      const m = rest.match(/(\d+)\s+more\b/i);
      if (m && left.length) {
        parts.push(rest.slice(0, m.index));
        // channels not named in the text: one link per channel (never twice for the same one)
        left.filter((c) => { if (done.has(c.id)) return false; done.add(c.id); return true; }).forEach((c, i) => { if (i) parts.push(','); parts.push(link(c, plain)); placed++; });
        parts.push(rest.slice(m.index + m[0].length));
      } else parts.push(rest);
    }
    if (placed < (min || 2)) return null;
    if (plain) {
      const f = document.createDocumentFragment();
      parts.forEach((p, i) => {
        if (typeof p !== 'string') { f.appendChild(p); return; }
        const t = p.trim();
        if (!t) return;
        // the joining word ("and") gets the same fixed gap on both sides; commas stay tight to the name before them
        const s = document.createElement('span');
        s.textContent = t;
        const before = i > 0 && typeof parts[i - 1] !== 'string', after = i < parts.length - 1 && typeof parts[i + 1] !== 'string';
        if (t !== ',') s.setAttribute('data-rt-and', '1'); s.style.cssText = 'display:inline-block;vertical-align:middle;white-space:pre;margin:0 ' + (after ? (t === ',' ? '6px' : '8px') : '0') + ' 0 ' + (before ? (t === ',' ? '0' : '8px') : '0');
        f.appendChild(s);
      });
      return f;
    }
    const frag = document.createDocumentFragment();
    parts.forEach((p, i) => {
      if (typeof p !== 'string') { frag.appendChild(p); return; }
      const t = p.trim();
      if (!t) return;
      const s = document.createElement('span');
      s.textContent = t;
      // same gap on both sides of "and" / commas, whatever whitespace YouTube had around it
      if (t !== ',') s.setAttribute('data-rt-and', '1'); s.style.cssText = 'display:inline-block;vertical-align:middle;white-space:pre;margin:0 ' + (typeof parts[i + 1] !== 'string' && parts[i + 1] ? '8px' : '0') + ' 0 ' + (typeof parts[i - 1] !== 'string' && parts[i - 1] ? (t === ',' ? '0' : '8px') : '0');
      frag.appendChild(s);
    });
    return frag;
  }
  function names(txt, list) { return (list || channels).filter((c) => txt.indexOf(c.name) >= 0).length; }
  const SKIP = 'a[data-rt-collab], tp-yt-paper-tooltip, [hidden], button, ytd-subscribe-button-renderer, yt-subscribe-button-view-model';

  // Finds the text that lists the channels, wherever YouTube puts it inside the owner block, and links the names.
  function apply() {
    if (!channels || channels.length < 2) return;
    const root = document.querySelector('ytd-watch-metadata ytd-video-owner-renderer') || document.querySelector('ytd-video-owner-renderer');
    if (!root) return;
    let done = root.querySelectorAll('a[data-rt-collab]').length ? 1 : 0;
    // YouTube shows its own badge after the last name only when that channel is verified; trust it as well as the data
    if (!done && root.querySelector('.ytAttributedStringInlineBlockMod')) channels[channels.length - 1].verified = true;
    // 1) the names sit in one text node (YouTube puts it directly inside its own link, next to the badge icon)
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes = [];
    for (let n = walker.nextNode(); n; n = walker.nextNode()) nodes.push(n);
    nodes.forEach((n) => {
      const txt = n.nodeValue || '';
      if (!txt.trim() || !n.parentElement || n.parentElement.closest(SKIP)) return;
      if (names(txt) < 2 && !(names(txt) >= 1 && /\d+\s+more\b/i.test(txt))) return;
      const frag = build(txt);
      if (frag) { n.parentNode.replaceChild(frag, n); done++; }
    });
    // 2) the names are split over several elements: rebuild the innermost element that holds them all
    if (!root.querySelector('a[data-rt-collab]')) {
      root.querySelectorAll('*').forEach((el) => {
        if (el.closest(SKIP) || el.querySelector('a[data-rt-collab]')) return;
        const txt = el.textContent || '';
        if (names(txt) < 2 && !/\d+\s+more\b/i.test(txt)) return;
        if ([].some.call(el.children, (c) => names(c.textContent || '') >= 2)) return; // a child holds them all, go deeper
        const frag = build(txt);
        if (frag) { el.textContent = ''; el.appendChild(frag); done++; }
      });
    }
    // YouTube's own badge only follows the last name; once ours are shown, hide it so nothing is doubled
    root.querySelectorAll('.ytAttributedStringInlineBlockMod').forEach((el) => {
      el.style.display = root.querySelector('[data-rt-collab-badge]') ? 'none' : '';
    });
    const stack = root.querySelector('#avatar-stack');
    if (stack) stack.style.display = root.querySelectorAll('img[data-rt-collab-img]').length >= 2 ? 'none' : '';
    document.documentElement.setAttribute('data-rt-collab', 'channels:' + channels.length + ' verified:' + channels.filter((c) => c.verified).length + ' linked:' + done);
  }


  // Collab videos shown as cards anywhere on YouTube: link each channel name in the byline.
  // The byline is often split into separate pieces ("Apashe", an icon, "and Majestic Collective"), so each
  // text piece is handled on its own, but only when the byline as a whole names at least two of the channels.
  function cards() {
    window.dispatchEvent(new CustomEvent('rt-collab-scan'));
    document.querySelectorAll('[data-rt-cc]').forEach((card) => {
      if (card.closest('ytd-video-owner-renderer')) return;
      if (card.querySelector('a[data-rt-collab]')) { pictures(card); if (card.hasAttribute('data-rt-cpic')) spacing(card); else tidy(card); subLabel(card); muteLabels(card); return; } // names already linked: keep trying for the pictures
      let list; try { list = JSON.parse(card.getAttribute('data-rt-cc')); } catch (e) { return; }
      // an entry that is really the video's title (its data also holds a link to the uploader) is not a channel name
      const ttl = ((card.querySelector('#video-title, h3 a[title], h3') || {}).textContent || '').replace(/\s+/g, ' ').trim();
      if (ttl) list = list.filter((c) => c.name !== ttl);
      // the byline only (never the title or description), and only the copy that is actually shown:
      // YouTube keeps a hidden duplicate of the byline in some layouts
      let region = null, known = false;
      ['#attributed-channel-name', 'yt-content-metadata-view-model', 'ytd-channel-name', '#byline-container', '#metadata'].some((s) => {
        const all = card.querySelectorAll(s);
        if (all.length) known = true;
        region = [].find.call(all, (e) => !e.closest('[hidden]')) || null;
        return !!region;
      });
      if (!region) { if (known) return; region = card; } // a known byline that is hidden: leave alone; unknown layout: use the card
      const walker = document.createTreeWalker(region, NodeFilter.SHOW_TEXT);
      const nodes = [];
      for (let n = walker.nextNode(); n; n = walker.nextNode()) {
        const el = n.parentElement;
        if (!el || !(n.nodeValue || '').trim() || el.closest(SKIP + ', h1, h2, h3, #video-title, yt-formatted-string#video-title')) continue;
        nodes.push(n);
      }
      const seen = new Set();
      nodes.forEach((n) => list.forEach((c) => { if ((n.nodeValue || '').indexOf(c.name) >= 0) seen.add(c.id); }));
      const more = nodes.some((n) => /\d+\s+more\b/i.test(n.nodeValue || ''));
      if (seen.size < 2 && !(seen.size >= 1 && more)) return;
      nodes.forEach((n) => {
        const txt = n.nodeValue || '';
        const hit = list.some((c) => txt.indexOf(c.name) >= 0) || /\d+\s+more\b/i.test(txt);
        if (!hit) return;
        const frag = build(txt, list, true, 1);
        if (frag) n.parentNode.replaceChild(frag, n);
      });
      pictures(card);
      subLabel(card); muteLabels(card);
    });
  }

  // Spacing for the pictures-only look: the verified tick sits right against its own picture and the wider gap comes after it.
  // Done with a style sheet and marks (not inline styles) so it survives YouTube redrawing the row.
  (function () {
    if (document.getElementById('rt-collab-style')) return;
    const st = document.createElement('style'); st.id = 'rt-collab-style';
    st.textContent = '[data-rt-cpic] a[data-rt-collab][data-rt-gap="t"]{margin-right:3px !important}[data-rt-cpic] a[data-rt-collab][data-rt-gap="n"]{margin-right:14px !important}html body div.cloned-channel-name[data-rt-subnames][data-rt-subnames]{font-size:0 !important;line-height:0 !important}html body div.cloned-channel-name[data-rt-subnames][data-rt-subnames] > *:not([data-rt-lab]){display:none !important}html body div.cloned-channel-name[data-rt-subnames][data-rt-subnames] > [data-rt-lab]{display:inline-flex !important;align-items:center;flex-wrap:wrap;font-size:var(--rt-fs,20px) !important;line-height:1.4 !important}[data-rt-lab]{margin-left:var(--rt-shift,0px) !important}[data-rt-lab] [data-rt-lp]{display:inline-flex;align-items:center;gap:6px}[data-rt-lab] [data-rt-lp] img{width:36px;height:36px;border-radius:50%;object-fit:cover;flex:none}[data-rt-and]:not([data-rt-dl]){display:inline !important;margin:0 8px !important;line-height:inherit !important;vertical-align:baseline !important}[data-rt-cc]:not([data-rt-cpic]) a[data-rt-collab]{display:inline !important;line-height:inherit !important;vertical-align:baseline !important;margin:0 !important}[data-rt-lab] [data-rt-la]{margin:0 .45em;white-space:pre}[data-rt-labpics] .ytLockupMetadataViewModelAvatar{display:none !important}[data-rt-dl]{display:inline-block !important;opacity:0 !important;width:1px !important;min-width:0 !important;margin:0 -1px 0 0 !important;padding:0 !important;overflow:hidden !important}[data-rt-tick]{margin-inline-end:14px !important;margin-inline-start:0 !important}';
    (document.head || document.documentElement).appendChild(st);
  })();
  const TICK = '.ytContentMetadataViewModelIcon:not(.ytContentMetadataViewModelLeadingIcon), .ytAttributedStringLinkInheritColor';
  function spacing(card) {
    card.querySelectorAll('.ytContentMetadataViewModelDelimiter').forEach((el) => {
      if (el.closest('yt-content-metadata-view-model') && !el.closest('[data-rt-hidden-views]') && !el.hasAttribute('data-rt-dl')) el.setAttribute('data-rt-dl', '1');
    });
    card.querySelectorAll('a[data-rt-collab]').forEach((a) => {
      let el = a;
      if (!el.nextElementSibling && a.parentElement && /ytContentMetadataViewModelMetadataText/.test(a.parentElement.className || '')) el = a.parentElement;
      let sib = el.nextElementSibling;
      while (sib && (sib.style.display === 'none' || sib.hasAttribute('data-rt-dl')) && !sib.matches(TICK)) sib = sib.nextElementSibling;
      const tick = sib && sib.matches(TICK) && (sib.matches('.ytContentMetadataViewModelIcon') || sib.querySelector('.ytAttributedStringInlineBlockMod')) ? sib : null;
      const want = tick ? 't' : 'n';
      if (a.getAttribute('data-rt-gap') !== want) a.setAttribute('data-rt-gap', want);
      if (tick && !tick.hasAttribute('data-rt-tick')) tick.setAttribute('data-rt-tick', '1');
    });
  }


  // The channels the viewer is subscribed to, asked for once from the page (it is a list YouTube already serves).
  // On collab videos the big channel name in the list layout then shows only those, whichever of the channels they are.
  let subs = null, subsStamp = 0;
  try { const c = JSON.parse(localStorage.getItem('rt-subs-cache') || 'null'); if (c && c.ids && c.ids.length) { subs = new Set(c.ids); subsStamp = c.t || 0; } } catch (e) { /* no cache */ }
  let subsTries = 0, subsBusy = false, subsErr = '', subsNext = 0, subsSteps = '';
  const subsMark = () => document.documentElement.setAttribute('data-rt-subs', 'n:' + (subs ? subs.size : 'none') + ' tries:' + subsTries + (subsErr ? ' err:' + subsErr : '') + (subsSteps ? ' ' + subsSteps : ''));
  window.addEventListener('rt-subs-res', (e) => {
    subsBusy = false;
    let d; try { d = JSON.parse(e.detail); } catch (err) { return; }
    subsSteps = (d && d.steps) || '';
    if (d && d.ids && d.ids.length) { subs = new Set(d.ids); subsStamp = Date.now(); try { localStorage.setItem('rt-subs-cache', JSON.stringify({ t: subsStamp, ids: d.ids })); } catch (e) { /* ignore */ } subsErr = ''; if (d.exact === false) subsSteps += ' broad'; } else { subsErr = (d && d.error) || 'empty'; subsNext = Date.now() + 6000 * subsTries; }
    subsMark();
    setTimeout(cards, 0);
  });
  function wantSubs() {
    if ((subs && Date.now() - subsStamp < 3600000) || subsBusy || subsTries >= 6 || Date.now() < subsNext) return;
    subsBusy = true; subsTries++; subsMark();
    window.dispatchEvent(new CustomEvent('rt-subs-req'));
    setTimeout(() => { subsBusy = false; }, 20000);
  }
  // The picture next to the big name: the subscribed channel's own picture (one of them, picked at random, when both are subscribed).
  function subPic(card, root, mineC) {
    const box = root.querySelector('.ytLockupMetadataViewModelAvatar');
    if (!box) return;
    let pick = mineC.find((c) => c.id === card.getAttribute('data-rt-pick'));
    if (!pick) { pick = mineC[Math.floor(Math.random() * mineC.length)]; card.setAttribute('data-rt-pick', pick.id); }
    const own = card.querySelector('a[data-rt-collab="' + pick.id + '"] img[data-rt-collab-img]');
    const src = (own && own.src) || pick.img || '';
    if (!src) return; // the pictures are not ready yet: tried again on the next pass
    const host = box.querySelector('a.custom-avatar-link') || box;
    let im = box.querySelector('img[data-rt-subpic]');
    if (!im) {
      im = document.createElement('img'); im.setAttribute('data-rt-subpic', '1'); im.alt = '';
      im.style.cssText = 'width:36px;height:36px;min-width:36px;border-radius:50%;object-fit:cover;display:block';
      host.insertBefore(im, host.firstChild);
    }
    if (im.getAttribute('src') !== src) im.src = src;
    if (host.tagName === 'A' && pick.path && host.getAttribute('data-rt-avpath') !== pick.id) { host.setAttribute('href', pick.path); host.setAttribute('data-rt-avpath', pick.id); }
  }
  function subLabel(card) {
    const root = card.closest('ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer') || card;
    const lab = root.querySelector('.cloned-channel-name');
    if (!lab) return;
    let list = []; try { list = JSON.parse(card.getAttribute('data-rt-cc') || '[]'); } catch (e) { list = []; }
    const ttl = ((card.querySelector('#video-title, h3 a[title], h3') || {}).textContent || '').replace(/\s+/g, ' ').trim();
    if (ttl) list = list.filter((c) => c.name !== ttl);
    const mineC = list.filter((c) => c.name); // every creator, not only the ones subscribed to
    const mine = mineC.map((c) => c.name);
    if (!mine.length) return;
    // the channel's own picture stays as YouTube draws it
    const txt = mine.length > 1 ? mine.slice(0, -1).join(', ') + ' and ' + mine[mine.length - 1] : mine[0];
    const key = txt + '|' + mineC.map((c) => (c.img ? 1 : 0)).join('');
    if (lab.getAttribute('data-rt-subnames') === key && lab.querySelector(':scope > [data-rt-lab]')) return;
    if (!lab.hasAttribute('data-rt-subnames')) { const fs = parseFloat(getComputedStyle(lab).fontSize); if (fs > 0) lab.style.setProperty('--rt-fs', fs + 'px'); }
    lab.removeAttribute('data-rt-nolabel');
    // each creator is its own picture + name pair, joined by "and", like the names under the title
    [].forEach.call(lab.querySelectorAll(':scope > [data-rt-lab]'), (e) => e.remove());
    // the pictures start where YouTube's own channel picture starts on the other videos
    if (!root.hasAttribute('data-rt-labpics')) {
      const av = root.querySelector('.ytLockupMetadataViewModelAvatar'); const ab = av && av.getBoundingClientRect(), lb = lab.getBoundingClientRect();
      if (ab && ab.width && lb.width) lab.style.setProperty('--rt-shift', Math.round(ab.left - lb.left) + 'px');
    }
    const stackImgs = [].slice.call(root.querySelectorAll('yt-avatar-stack-view-model img'));
    const wrap = document.createElement('span'); wrap.setAttribute('data-rt-lab', '1');
    mineC.forEach((c, i) => {
      if (i > 0) { const w = document.createElement('span'); w.setAttribute('data-rt-la', '1'); w.textContent = i === mineC.length - 1 ? 'and' : ','; wrap.appendChild(w); }
      const pair = document.createElement('span'); pair.setAttribute('data-rt-lp', '1');
      const src = c.img || ((stackImgs[i] || {}).src) || '';
      if (src) { const im = document.createElement('img'); im.src = src; im.alt = ''; pair.appendChild(im); }
      pair.appendChild(document.createTextNode(c.name)); wrap.appendChild(pair);
    });
    lab.appendChild(wrap);
    lab.setAttribute('data-rt-subnames', key);
    root.setAttribute('data-rt-labpics', '1');
  }

  // Names-only look: the dot-gap YouTube keeps between the creators is dropped, so "and" has the same space on both sides.
  function tidy(card) {
    card.querySelectorAll('.ytContentMetadataViewModelDelimiter').forEach((el) => {
      if (el.hasAttribute('data-rt-dl') || !el.closest('yt-content-metadata-view-model')) return;
      const pv = el.previousElementSibling, nx = el.nextElementSibling;
      if (pv && nx && pv.querySelector('a[data-rt-collab]') && nx.querySelector('a[data-rt-collab], [data-rt-and]')) el.setAttribute('data-rt-dl', '1');
    });
    // "and" is drawn in exactly the size, colour and weight of the names beside it
    const ref = card.querySelector('a[data-rt-collab]');
    if (ref) {
      const cs = getComputedStyle(ref);
      card.querySelectorAll('[data-rt-and]:not([data-rt-dl])').forEach((e) => {
        ['font-size', 'font-weight', 'font-family', 'letter-spacing', 'color'].forEach((k) => {
          const v = cs.getPropertyValue(k);
          if (v && e.style.getPropertyValue(k) !== v) e.style.setProperty(k, v, 'important');
        });
      });
    }
  }
  // Earlier versions hid stray name text here; that is no longer done (it could catch real links), this only clears old marks.
  function muteLabels(card) {
    const root = card.closest('ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer') || card;
    root.querySelectorAll('[data-rt-nolabel]').forEach((e) => e.removeAttribute('data-rt-nolabel'));
  }

  // Give each linked name its own channel picture, taken from YouTube's overlapping avatar stack
  // (same order as the names), then hide the stack so the pictures are not shown twice.
  function pictures(card) {
    if (card.hasAttribute('data-rt-cpic')) return;
    const links = [].slice.call(card.querySelectorAll('a[data-rt-collab]'));
    const stack = card.querySelector('yt-avatar-stack-view-model');
    if (links.length < 3 || !stack) return; // two creators keep their names; pictures only from three up
    // the stack's images can arrive a moment after the names, so this is retried on every pass
    const raw = [].slice.call(stack.querySelectorAll('img')).filter((i) => i.src);
    if (raw.length !== links.length) return;
    // which picture belongs to which name: by the picture address from the card's data when it has one, otherwise by
    // where the pictures sit (an overlapping cluster is read left to right), otherwise in page order
    const base = (u) => String(u || '').replace(/^https?:/, '').split('=')[0];
    let list = []; try { list = JSON.parse(card.getAttribute('data-rt-cc') || '[]'); } catch (e) { list = []; }
    const wanted = links.map((a) => { const c = list.find((x) => x.id === a.getAttribute('data-rt-collab') && x.img); return c ? base(c.img) : ''; });
    let how = 'order', imgs = raw;
    const byUrl = wanted.map((w) => (w ? raw.find((r) => base(r.src) === w) : null));
    if (byUrl.every(Boolean) && new Set(byUrl).size === byUrl.length) { imgs = byUrl; how = 'url'; }
    else if (raw.some((r) => { const cs = r.closest('[style*="position"]'); return cs && /absolute/.test(cs.style.position || ''); })) {
      imgs = raw.slice().sort((x, y) => x.getBoundingClientRect().left - y.getBoundingClientRect().left || x.getBoundingClientRect().top - y.getBoundingClientRect().top); how = 'visual';
    }
    card.setAttribute('data-rt-pichow', how);
    links.forEach((a, i) => {
      // pictures only: the picture is the link, the name is dropped (it stays as the hover text)
      a.style.cssText = 'color:inherit;text-decoration:none;cursor:pointer;display:inline-flex;align-items:center;vertical-align:middle;margin-right:6px';
      const im = document.createElement('img');
      im.src = imgs[i].src; im.alt = a.title || ''; im.setAttribute('data-rt-collab-img', '1');
      im.style.cssText = 'width:20px;height:20px;min-width:20px;max-width:20px;box-sizing:border-box;border-radius:50%;object-fit:cover;flex:none;display:block;margin:0';
      // the name text stays in the link, hidden, so other extensions and pages that read the channel name from the row still find it
      [].slice.call(a.childNodes).forEach((n) => {
        if (n.nodeType !== 3) return;
        const sp = document.createElement('span'); sp.setAttribute('data-rt-collab-name', '1'); sp.style.cssText = 'position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;opacity:0;pointer-events:none'; sp.textContent = n.nodeValue;
        a.replaceChild(sp, n);
      });
      a.setAttribute('aria-label', (a.title || '').replace(/^Go to /, ''));
      a.insertBefore(im, a.firstChild);
      // the joining words and commas we added around the names
      [].slice.call(a.parentNode.children).forEach((el) => { if (el !== a && el.tagName !== 'A' && el.style.display === 'inline-block' && !el.querySelector('a')) el.setAttribute('data-rt-dl', '1'); });
    });
    // the dots between items go; the verified tick stays, tight against its own picture, with the wider gap after it
    card.querySelectorAll('.ytContentMetadataViewModelDelimiter').forEach((el) => {
      if (el.closest('yt-content-metadata-view-model') && !el.closest('[data-rt-hidden-views]')) el.setAttribute('data-rt-dl', '1');
    });
    spacing(card);
    // the byline box can be only one text line tall and clip the bottom of the pictures: let them show in full
    links.forEach((a) => {
      for (let el = a.parentElement, n = 0; el && el !== card && n < 8; el = el.parentElement, n++) {
        const cs = getComputedStyle(el);
        if (cs.overflow !== 'visible' || cs.overflowY !== 'visible') el.style.setProperty('overflow', 'visible', 'important');
        if (/^(ytd-video-meta-block|yt-content-metadata-view-model)$/i.test(el.tagName)) break;
        if (el.id === 'attributed-channel-name') { el.style.setProperty('min-height', '26px', 'important'); el.style.setProperty('max-height', 'none', 'important'); el.style.setProperty('height', 'auto', 'important'); }
      }
    });
    stack.style.display = 'none';
    card.setAttribute('data-rt-cpic', '1');
  }

  function tick() {
    cards();
    if (RT.page() !== 'watch') { vid = ''; channels = null; return; }
    const v = new URLSearchParams(location.search).get('v') || '';
    if (v !== vid) { vid = v; channels = null; tries = 0; waiting = false; document.documentElement.removeAttribute('data-rt-collab'); }
    if (channels) { apply(); return; }
    if (!document.querySelector('ytd-video-owner-renderer') || tries >= 6 || waiting || Date.now() - lastAsk < 1200) return;
    tries++; waiting = true; lastAsk = Date.now();
    window.dispatchEvent(new CustomEvent('rt-collab-req'));
    setTimeout(() => { waiting = false; }, 1500);
  }
  ['apply', 'dom', 'navigate'].forEach((ev) => RT.bus.addEventListener(ev, tick));
  setInterval(tick, 700);
  let moT = 0;
  try { new MutationObserver((ms) => { if (moT || !ms.some((m) => m.addedNodes && m.addedNodes.length)) return; moT = setTimeout(() => { moT = 0; try { cards(); } catch (e) { /* next tick */ } }, 150); }).observe(document.documentElement, { childList: true, subtree: true }); } catch (e) { /* the timer still runs */ }
})();
