// ReTrapper focus & access tools: temporary modes, schedules, opening delay,
// intention prompt, time limits, time badge, preset schedule.
(function () {
  'use strict';
  const RT = window.RT;
  if (!RT) return;
  const S = () => RT.settings();
  const on = (id) => RT.on(id);
  const today = () => new Date().toISOString().slice(0, 10);
  const ss = {
    get: (k) => { try { return sessionStorage.getItem(k); } catch (e) { return null; } },
    set: (k, v) => { try { sessionStorage.setItem(k, v); } catch (e) { /* ignore */ } }
  };
  const sessionMin = () => (+ss.get('rtSessionSec') || 0) / 60;
  let dailySec = 0;
  // After the extension is reloaded or updated, old tabs keep this script alive but chrome.* throws
  // "Extension context invalidated". Detect that and stop quietly.
  const alive = () => { try { return !!(chrome.runtime && chrome.runtime.id); } catch (e) { return false; } };

  // ---- temporary / scheduled modes -------------------------------------------------
  const prev = RT.extraTokens;
  RT.extraTokens = () => {
    const s = S(), now = Date.now(), out = prev();
    if (s.tempFocusUntil > now) out.push('focusMode');
    if (s.tempDistractUntil > now) out.push('distractionBlocking');
    if (s.autoFocusMode === 'always' || (s.autoFocusMode === 'schedule' && RT.inWindow(s.focusSchedule || ''))) out.push('focusMode');
    if (s.autoDistractionBlock && sessionMin() >= Math.max(1, s.autoDistractAfterMin)) out.push('distractionBlocking');
    return out;
  };

  // ---- overlay -----------------------------------------------------------------------------
  let el = null, key = '', cleanup = null;
  function remove() { if (cleanup) cleanup(); cleanup = null; if (el) el.remove(); el = null; key = ''; }
  function show(k, title, body, build) {
    if (key === k && el && el.isConnected) return;
    remove();
    key = k;
    el = document.createElement('div');
    el.id = 'rt-gate';
    el.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:#0b0b0bf2;color:#f1f1f1;display:flex;align-items:center;justify-content:center;font-family:Roboto,Arial,sans-serif;';
    const card = document.createElement('div');
    card.style.cssText = 'max-width:420px;padding:28px;text-align:center;';
    const h = document.createElement('div'); h.textContent = title; h.style.cssText = 'font-size:22px;font-weight:600;margin-bottom:10px;';
    const p = document.createElement('div'); p.textContent = body; p.style.cssText = 'font-size:15px;color:#bbb;margin-bottom:18px;line-height:1.4;';
    card.append(h, p);
    if (build) cleanup = build(card) || null;
    el.appendChild(card);
    document.documentElement.appendChild(el);
  }
  function button(label, fn, primary) {
    const b = document.createElement('button');
    b.textContent = label;
    b.style.cssText = `margin:4px;padding:9px 18px;border-radius:18px;border:1px solid #666;font:500 14px Roboto,Arial,sans-serif;cursor:pointer;background:${primary ? '#f1f1f1' : 'transparent'};color:${primary ? '#0f0f0f' : '#f1f1f1'};`;
    b.addEventListener('click', fn);
    return b;
  }
  async function askPassword() {
    const s = S();
    if (!s.pwHash) return true;
    const pw = window.prompt('Password:');
    return pw != null && (await RT.checkPassword(s, pw));
  }
  const hm = (ms) => { const m = Math.max(0, Math.ceil(ms / 60000)); return m + ' min'; };

  function evaluate() {
    const s = S(), now = Date.now(), pt = RT.page();
    if (pt === 'embed' || pt === 'other' && !RT.state) return remove();
    const snooze = +ss.get('rtSnoozeUntil') || 0;
    if (s.tempBlockUntil > now) {
      return show('block', 'YouTube is blocked', 'Back in ' + hm(s.tempBlockUntil - now) + '. You turned this on in ReTrapper.', (c) => {
        const t = setInterval(evaluate, 15000);
        c.appendChild(button('Go back', () => history.length > 1 ? history.back() : window.close()));
        return () => clearInterval(t);
      });
    }
    if (RT.rules && RT.rules.block) return show('rule', 'Blocked by a rule', 'A custom automation rule blocks this page.', (c) => c.appendChild(button('Go back', () => history.back())));
    if (now > snooze) {
      if (s.dailyLimitMin > 0 && dailySec / 60 >= s.dailyLimitMin) return limit('daily', 'Daily limit reached', `You've used your ${s.dailyLimitMin} minutes for today.`);
      if (s.sessionLimitMin > 0 && sessionMin() >= s.sessionLimitMin) return limit('session', 'Session limit reached', `You've been here for ${s.sessionLimitMin} minutes.`);
    }
    if (on('focusRestrictions') && on('focusMode') && ['home', 'shorts', 'subs', 'channel'].includes(pt)) {
      return show('restrict', 'Focus mode is on', 'This page is blocked while you focus. Search for something specific instead.', (c) => {
        c.appendChild(button('Search', () => { remove(); const i = document.querySelector('input#search, input[name="search_query"]'); if (i) i.focus(); }, true));
        c.appendChild(button('Go back', () => history.back()));
      });
    }
    const needGate = (s.openingDelay > 0 || s.accessIntent) && !ss.get('rtGateDone');
    if (needGate) return openingGate(s);
    remove();
  }
  function limit(k, title, body) {
    show(k, title, body, (c) => {
      c.appendChild(button('Snooze 5 min', async () => { if (await askPassword()) { ss.set('rtSnoozeUntil', String(Date.now() + 300000)); evaluate(); } }));
      c.appendChild(button('Leave YouTube', () => { location.href = 'about:blank'; }, true));
    });
  }
  function openingGate(s) {
    show('open', s.accessIntent ? 'What do you want to do here?' : 'Take a breath', s.accessIntent ? 'Write your intention to continue.' : 'YouTube opens in a moment.', (c) => {
      let left = Math.max(0, s.openingDelay | 0);
      const input = document.createElement('input');
      if (s.accessIntent) {
        input.placeholder = 'e.g. watch the lecture on…';
        input.style.cssText = 'display:block;width:100%;padding:10px 14px;margin-bottom:14px;border-radius:10px;border:1px solid #666;background:#1c1c1c;color:#fff;font-size:15px;box-sizing:border-box;';
        c.appendChild(input);
      }
      const go = button('Continue', () => { ss.set('rtGateDone', '1'); if (input.value.trim()) ss.set('rtIntent', input.value.trim()); evaluate(); }, true);
      const upd = () => {
        const okIntent = !s.accessIntent || input.value.trim().length >= 3;
        go.disabled = left > 0 || !okIntent;
        go.style.opacity = go.disabled ? '.4' : '1';
        go.textContent = left > 0 ? `Continue (${left})` : 'Continue';
      };
      input.addEventListener('input', upd);
      c.appendChild(go);
      upd();
      const t = setInterval(() => { if (left > 0) left--; upd(); document.querySelectorAll('video').forEach((v) => v.pause()); }, 1000);
      return () => clearInterval(t);
    });
  }

  // ---- usage tracking, badge, reminders ------------------------------------------------------
  let badge = null, lastRemind = 0;
  function tickUsage() {
    if (!alive()) { timers.forEach(clearInterval); return; }
    if (document.visibilityState !== 'visible' || RT.page() === 'embed') return;
    ss.set('rtSessionSec', String((+ss.get('rtSessionSec') || 0) + 5));
    dailySec += 5;
    if (dailySec % 15 === 0) { try { chrome.storage.local.set({ usageDay: today(), usageSeconds: dailySec }); } catch (e) { /* context gone */ } }
    const s = S();
    if (on('timeBadge')) {
      if (!badge || !badge.isConnected) {
        badge = document.createElement('div');
        badge.id = 'rt-time-badge';
        badge.style.cssText = 'position:fixed;left:16px;top:70px;z-index:2147483000;background:#202020cc;color:#ddd;border-radius:14px;padding:4px 10px;font:12px Roboto,Arial,sans-serif;pointer-events:none;';
        document.documentElement.appendChild(badge);
      }
      const intent = ss.get('rtIntent');
      badge.textContent = `${Math.floor(dailySec / 60)} min today · ${Math.floor(sessionMin())} min this visit` + (intent ? ' · ' + intent : '');
    } else if (badge) { badge.remove(); badge = null; }
    if (s.timeReminderMin > 0 && sessionMin() - lastRemind >= s.timeReminderMin) {
      lastRemind = sessionMin();
      toast(`You've been on YouTube for ${Math.round(sessionMin())} minutes.`);
    }
  }
  function toast(msg) {
    const t = document.createElement('div');
    t.textContent = msg;
    t.style.cssText = 'position:fixed;left:50%;bottom:60px;transform:translateX(-50%);z-index:2147483000;background:#f1f1f1;color:#0f0f0f;border-radius:18px;padding:10px 18px;font:14px Roboto,Arial,sans-serif;';
    document.documentElement.appendChild(t);
    setTimeout(() => t.remove(), 6000);
  }

  // ---- preset schedule + timed token refresh --------------------------------------------------
  let lastKey = '';
  function schedule() {
    const s = S(), now = Date.now();
    const k = RT.extraTokens().sort().join(',');
    if (k !== lastKey) { lastKey = k; if (RT._applied) RT.apply(); }
    if (s.presetAuto) {
      const name = RT.pickPreset(s.presetSchedule);
      if (name && name !== s.rtAutoApplied && (RT.BUILTIN_PRESETS[name] || (s.rtPresets || {})[name])) {
        RT.applyPreset(name, () => RT.save({ rtAutoApplied: name }));
      } else if (!name && s.rtAutoApplied) RT.save({ rtAutoApplied: '' });
    }
    if (s.tempBlockUntil && s.tempBlockUntil <= now) RT.save({ tempBlockUntil: 0 });
  }

  try { chrome.storage.local.get(['usageDay', 'usageSeconds'], (st) => { dailySec = st && st.usageDay === today() ? +st.usageSeconds || 0 : 0; }); } catch (e) { /* context gone */ }
  RT.bus.addEventListener('apply', evaluate);
  RT.bus.addEventListener('navigate', evaluate);
  const timers = [setInterval(tickUsage, 5000)];
  timers.push(setInterval(() => { if (!alive()) { timers.forEach(clearInterval); return; } try { schedule(); evaluate(); } catch (e) { /* ignore */ } }, 20000));
  RT.bus.addEventListener('apply', () => setTimeout(schedule, 0));
})();
