// Items: Interface, Playback extras, Automation, Focus, Presets, Shortcuts, Transcript, Access, Embeds.
(function () {
  'use strict';
  const RT = window.RT;
  const { def, toggle, number, select, range, text, area, multi, hotkey } = RT._h;
  const { WATCH, HOME, SUBS, CHAN, SRCH } = RT.SEL;

  // ---- Interface --------------------------------------------------------------------
  toggle('showFullDates', 'Show exact upload date and time (DD-MM-YYYY HH:MM)', {
    def: true,
    hint: 'Replaces "3 days ago" on the home page, subscriptions, search, recommendations, the video page and Shorts. The time is left out when YouTube does not provide one.'
  });
  toggle('minimalInterface', 'Minimal interface', {
    implies: ['hideHomeChips', 'hideGuideFooter', 'removePromoUI', 'hideBannerAds', 'hideBadges']
  });
  toggle('minimalLayout', 'Minimal layout', {
    rules: [[`${HOME} ytd-rich-grid-renderer`, 'max-width:1280px;margin-left:auto;margin-right:auto'],
      [`${SUBS} ytd-rich-grid-renderer`, 'max-width:1280px;margin-left:auto;margin-right:auto'],
      [`${SRCH} ytd-two-column-search-results-renderer`, 'max-width:960px;margin:0 auto'],
      [`${WATCH} #columns`, 'max-width:1500px;margin:0 auto']]
  });
  toggle('cinemaMode', 'Cinema mode', {
    hint: 'Dims everything except the player on watch pages; hover to bring it back.',
    rules: [[`${WATCH} #below`, 'opacity:.12;transition:opacity .25s', ['rtWatch']], [`${WATCH} #below:hover`, 'opacity:1', ['rtWatch']],
      [`${WATCH} #secondary`, 'opacity:.12;transition:opacity .25s', ['rtWatch']], [`${WATCH} #secondary:hover`, 'opacity:1', ['rtWatch']],
      ['ytd-masthead', 'opacity:.15;transition:opacity .25s', ['rtWatch']], ['ytd-masthead:hover', 'opacity:1', ['rtWatch']],
      ['ytd-app', '--yt-spec-base-background:#000', ['rtWatch']]]
  });
  const theme = (bg, raised, extra) => ({
    rules: [['', `--yt-spec-base-background:${bg};--yt-spec-raised-background:${raised};--yt-spec-menu-background:${raised};` +
      `--yt-spec-general-background-a:${bg};--yt-spec-general-background-b:${bg};--yt-spec-general-background-c:${raised}` + (extra ? ';' + extra : '')]]
  });
  select('customTheme', 'Custom themes', [['default', 'YouTube default'], ['amoled', 'AMOLED black'], ['midnight', 'Midnight blue'],
    ['graphite', 'Graphite'], ['nord', 'Nord'], ['solarized', 'Solarized dark'], ['sepia', 'Sepia (light)']], 'default', {
    cssBy: {
      amoled: theme('#000', '#0b0b0b'), midnight: theme('#0b1220', '#131c31'), graphite: theme('#1c1c1e', '#2c2c2e'),
      nord: theme('#2e3440', '#3b4252'), solarized: theme('#002b36', '#073642'),
      sepia: theme('#f4ecd8', '#eadfc4', '--yt-spec-text-primary:#3b2f1e;--yt-spec-text-secondary:#6b5b45')
    }
  });
  text('customAccent', 'Accent color (hex)', { placeholder: '#3ea6ff', swatches: ['#ff0033', '#3ea6ff', '#2ba640', '#f5a623', '#a56cf0', '#ff5fa2'] });
  toggle('legacyLayout', 'Legacy YouTube layout', {
    alts: ['Old YouTube layout'], hint: 'Square thumbnails and flat chips.',
    rules: [...RT.onThumbs(['html'], 'border-radius:0'), ['ytd-thumbnail a', 'border-radius:0'], ['yt-img-shadow.ytd-thumbnail', 'border-radius:0'],
      ['yt-chip-cloud-chip-renderer', 'border-radius:2px'], ['ytd-rich-grid-media', 'border-radius:0']]
  });
  toggle('legacyListViews', 'Legacy list views', { hint: 'One video per row on Home, Subscriptions and channels.' });
  toggle('grayscaleUI', 'Grayscale');
  range('grayscaleAmount', 'Grayscale amount', 0, 100, 5, 100, { unit: '%', showIf: 'grayscaleUI' });
  toggle('blurCards', 'Blur', {
    hint: 'Blurs video cards until you hover them.',
    rules: ['ytd-rich-item-renderer', 'ytd-video-renderer', 'ytd-compact-video-renderer', 'ytd-grid-video-renderer'].flatMap((c) =>
      [[c, 'filter:blur(7px);transition:filter .2s'], [c + ':hover', 'filter:none']])
  });
  toggle('hideVisualElements', 'Hide visual elements', {
    css: ['#avatar-container', 'ytd-video-owner-renderer #avatar', 'ytd-comment-view-model #author-thumbnail', 'ytd-comment-renderer #author-thumbnail',
      'yt-decorated-avatar-view-model', 'ytd-thumbnail-overlay-time-status-renderer', 'ytd-thumbnail-overlay-toggle-button-renderer',
      'ytd-thumbnail-overlay-now-playing-renderer', 'ytd-thumbnail-overlay-hover-text-renderer']
  });
  toggle('removeClutter', 'Remove visual clutter', {
    implies: ['hideBadges', 'hideBannerAds', 'hideAdSlots', 'removePromoUI', 'hideShortsSections', 'hideHomeChips', 'hideOtherRows',
      'hideGuideFooter', 'hideMoreFromYT', 'hideProducts', 'hideChannelDistractions', 'hideVideoOverlays', 'hideEndscreenInfo']
  });
  number('pageMaxWidth', 'Customize page layouts: max width (px, 0 = off)', 0, { max: 3000 });
  range('gridColumns', 'Videos per row', 1, 7, 1, 6);
  area('customHideSelectors', 'Customize individual UI elements (CSS selectors to hide)', { placeholder: 'ytd-guide-entry-renderer:nth-child(3)' });
  area('customCss', 'Custom CSS', { placeholder: 'ytd-masthead { background: #111 !important; }' });

  // ---- Automation ----------------------------------------------------------------------
  number('openingDelay', 'Opening delay (seconds)', 0, { max: 120, alts: ['Opening delays'], hint: 'A countdown screen when YouTube opens in a tab.' });
  select('autoFocusMode', 'Automatic focus behavior', [['off', 'Off'], ['always', 'Always on'], ['schedule', 'On a schedule']], 'off');
  text('focusSchedule', 'Focus schedule', { placeholder: '09:00-17:00 Mon-Fri', showIf: ['autoFocusMode', 'schedule'] });
  toggle('autoDistractionBlock', 'Automatic distraction blocking', { hint: 'Turns distraction blocking on after a while.' });
  number('autoDistractAfterMin', 'Start after (minutes)', 20, { min: 1, max: 600, showIf: 'autoDistractionBlock' });
  area('customRules', 'Custom automation rules',
    { placeholder: 'watch => speed:1.5\n/shorts/ => redirect:/\nsearch => hide:ytd-shelf-renderer',
      hint: 'pattern => action. Pattern: a page (home, watch, search, subs, channel, shorts, playlist), a /regex/, or text in the URL. Actions: redirect:URL, hide:SELECTOR, speed:N, quality:hd1080, theater, loop, mute, captions, focus, zen, distraction, block.' });

  // ---- Focus -----------------------------------------------------------------------------
  toggle('distractionBlocking', 'Distraction blocking', {
    implies: ['hideAllSuggestions', 'hideHomeChips', 'hideShortsAll', 'hideComments', 'hideRelated', 'hideEndscreenSuggestions', 'hideLiveChat', 'hideBell', 'hideAds']
  });
  toggle('focusMode', 'Focus mode', {
    implies: ['distractionBlocking', 'hideSidebarAll', 'hideWatchSidebar', 'hideExplore', 'hideTrending', 'hideVideoOverlays', 'disableAutoplay']
  });
  toggle('zenMode', 'Zen mode', {
    implies: ['focusMode', 'hideLogo', 'hideCreate', 'hideMenuButtons', 'hideDescription', 'hideChannelInfo', 'hideVideoMetadata', 'minimalPlayer']
  });
  toggle('minimalistMode', 'Minimalist mode', {
    implies: ['hideHomeChips', 'hideShortsAll', 'hideBadges', 'hideHomeAds', 'hideBell', 'hideGuideFooter', 'removePromoUI', 'hideBannerAds']
  });
  number('sessionLimitMin', 'Session limit (minutes per tab session, 0 = off)', 0, { max: 1440, alts: ['Session limits'] });
  number('dailyLimitMin', 'Daily limit (minutes, 0 = off)', 0, { max: 1440 });
  toggle('timeBadge', 'Time-awareness badge', { alts: ['Time-awareness tools'], hint: 'Shows time spent on YouTube today.' });
  number('timeReminderMin', 'Remind me every (minutes, 0 = off)', 0, { max: 600 });
  toggle('accessIntent', 'Intentional access', { alts: ['Intentional access controls'], hint: 'Asks what you came to do before YouTube opens.' });
  toggle('focusRestrictions', 'Focus restrictions', { hint: 'While focus mode is on, only watch, search and playlist pages open.' });
  def('wTimerFocus', { type: 'widget', kind: 'timer', key: 'tempFocusUntil', label: 'Temporary focus mode', unit: 'minutes', def: 25 });
  def('wTimerDistract', { type: 'widget', kind: 'timer', key: 'tempDistractUntil', label: 'Temporary distraction blocking', unit: 'minutes', def: 30 });
  def('wTimerBlock', { type: 'widget', kind: 'timer', key: 'tempBlockUntil', label: 'Temporary blocking of YouTube', unit: 'minutes', def: 15 });
  def('wPassword', { type: 'widget', kind: 'password', label: 'Password-protected settings' });
  def('wPresets', { type: 'widget', kind: 'presets', label: 'Presets' });

  // ---- Presets ------------------------------------------------------------------------------
  toggle('presetAuto', 'Preset-based automation');
  area('presetSchedule', 'Preset schedule', {
    placeholder: '09:00-17:00 Mon-Fri => Work\n20:00-23:00 => Relax\n* => Minimal', showIf: 'presetAuto'
  });
  RT.BUILTIN_PRESETS = {
    Work: { distractionBlocking: true, homeRedirect: 'watchlater', autoSkipPromos: true },
    Study: { focusMode: true, autoTheater: true, defaultSpeed: '1.25', autoCaptions: true, hideComments: true },
    Relax: { autoTheater: true, hideBadges: true, hideAds: true, hideShortsAll: true },
    Minimal: { minimalistMode: true, minimalLayout: true, hideRelated: true }
  };

  // ---- Keyboard shortcuts ----------------------------------------------------------------------
  toggle('hotkeysOn', 'Custom keyboard shortcuts', { def: true, alts: ['Custom hotkeys'] });
  hotkey('hk_focus', 'Toggle focus mode');
  hotkey('hk_zen', 'Toggle zen mode');
  hotkey('hk_distraction', 'Toggle distraction blocking');
  hotkey('hk_nextPreset', 'Switch to next preset');
  hotkey('hk_theater', 'Toggle theater mode');
  area('customHotkeys', 'Shortcut-triggered actions', {
    placeholder: 'Alt+C = toggle:hideComments\nAlt+1 = preset:Work\nAlt+H = goto:/',
    hint: 'Key = action. Actions: toggle:ID, preset:Name, nextPreset, goto:/path, speed:+0.25, speed:1.5, loop, theater, fullscreen, transcript.'
  });

  // ---- AI summaries & transcript (on-device, extractive) -------------------------------------------
  const LANGS = ['en English', 'es Spanish', 'fr French', 'de German', 'pt Portuguese', 'it Italian', 'nl Dutch', 'sv Swedish', 'da Danish', 'no Norwegian',
    'fi Finnish', 'pl Polish', 'cs Czech', 'sk Slovak', 'hu Hungarian', 'ro Romanian', 'bg Bulgarian', 'el Greek', 'tr Turkish', 'ru Russian',
    'uk Ukrainian', 'he Hebrew', 'ar Arabic', 'fa Persian', 'hi Hindi', 'bn Bengali', 'ur Urdu', 'ta Tamil', 'te Telugu', 'mr Marathi',
    'th Thai', 'vi Vietnamese', 'id Indonesian', 'ms Malay', 'fil Filipino', 'ja Japanese', 'ko Korean', 'zh-Hans Chinese (Simplified)',
    'zh-Hant Chinese (Traditional)', 'hr Croatian', 'sr Serbian', 'sl Slovenian', 'lt Lithuanian', 'lv Latvian', 'et Estonian', 'sw Swahili'];
  select('aiLang', 'Transcript language', [['auto', 'Original']].concat(LANGS.map((s) => [s.split(' ')[0], s.slice(s.indexOf(' ') + 1)])), 'auto', {
    alts: ['Multilingual summaries', 'Translation', 'Summaries in 40+ languages', 'Multilingual transcript/summary support'],
    hint: 'Non-original languages use YouTube\'s caption translation when it is available for the video.'
  });
  toggle('trEnhanced', 'Enhanced transcript', { alts: ['AI-generated transcript'], hint: 'Adds a Transcript button with search, copy and download.' });
  toggle('trImproved', 'Improved transcript generation', { def: true, hint: 'Merges caption fragments into readable paragraphs.' });
  toggle('trNavigation', 'Transcript navigation', { def: true, hint: 'Search with next / previous match.' });
  toggle('trTimestamps', 'Timestamp navigation', { def: true, hint: 'Click a time to jump there.' });
  toggle('trExpand', 'Transcript expansion', { hint: 'Opens the transcript automatically on watch pages.' });
  toggle('trAutoGenerated', 'Use auto-generated captions when needed', { def: true });

  // ---- Embedded YouTube ---------------------------------------------------------------------------------
  toggle('embedPlayerSettings', 'Apply player settings to embedded videos', { def: true, hint: 'Speed, quality, volume, loop, captions and video filters.' });
  toggle('embedVisualSettings', 'Apply visual settings to embedded video', { def: true, hint: 'Grayscale, blur and theme variables.' });
  toggle('embedHideDistractions', 'Hide embedded-player distractions', {
    css: ['.ytp-pause-overlay', '.ytp-endscreen-content', '.ytp-ce-element', '.ytp-cards-teaser', '.ytp-impression-link']
  });
  multi('embedCustom', 'Customize embedded players', [
    { v: 'title', l: 'Title bar', css: ['.ytp-chrome-top'] },
    { v: 'watchlater', l: 'Watch later / share', css: ['.ytp-watch-later-button', '.ytp-share-button'] },
    { v: 'logo', l: 'YouTube logo', css: ['.ytp-youtube-button', '.ytp-watermark'] },
    { v: 'controls', l: 'Controls', css: ['.ytp-chrome-bottom'] }
  ]);
})();
