// Extra options: grid tweaks, watch-page helpers, player tools and hotkeys.
// Behaviour for the non-CSS ones lives in extras.js.
(function () {
  'use strict';
  const RT = window.RT;
  const { toggle, select, range, hotkey, area } = RT._h;
  const { WATCH, HOME, SUBS, CHAN, SRCH } = RT.SEL;
  const GRID = [`${HOME} ytd-rich-grid-renderer`, `${SUBS} ytd-rich-grid-renderer`, `${CHAN} ytd-rich-grid-renderer`];
  const each = (sels, tail) => sels.map((s) => `${s} ${tail}`);

  // ---- Grids and cards ------------------------------------------------------------------
  // Video card options apply to every video card on the whole site (Home, Subscriptions, Search, channels, recommendations, playlists).
  const CARDS = ['ytd-rich-item-renderer', 'ytd-video-renderer', 'ytd-grid-video-renderer', 'ytd-compact-video-renderer', 'ytd-playlist-video-renderer', 'yt-lockup-view-model'];
  toggle('gridHideAvatars', 'Video cards: hide channel pictures', {
    hint: 'Removes the small round channel picture on video cards, on every page.',
    css: CARDS.flatMap((c) => [`${c} #avatar-container`, `${c} #avatar-link`, `${c} #channel-thumbnail`, `${c} yt-decorated-avatar-view-model`, `${c} .ytLockupMetadataViewModelAvatar`,
      `${c} .yt-lockup-metadata-view-model-wiz__avatar`])
  });
  toggle('gridSmallFont', 'Video cards: smaller text', {
    hint: 'Smaller titles and details on video cards, on every page. Scales whatever size YouTube is already showing, so it follows your zoom and text settings.',
    rules: CARDS.flatMap((g) => [
      [`${g} #video-title`, 'zoom:.85'],
      [`${g} .ytLockupMetadataViewModelTitle, ${g} .yt-lockup-metadata-view-model-wiz__title`, 'zoom:.85'],
      [`${g} #metadata-line, ${g} ytd-channel-name, ${g} .ytContentMetadataViewModelMetadataText`, 'zoom:.9']
    ])
  });
  toggle('hideCardViews', 'Video cards: hide views', {
    alts: ['Hide views on cards'], def: true,
    hint: 'Hides the view count on video cards on every page (home, search, subscriptions, channels, the sidebar). The video page has its own switch.'
  });
  toggle('cardHideDuration', 'Video cards: hide video length', {
    hint: 'Removes the length badge (like 12:34) from thumbnails on every page.',
    css: ['ytd-thumbnail-overlay-time-status-renderer', 'yt-thumbnail-overlay-badge-view-model', 'yt-thumbnail-badge-view-model', '.yt-badge-shape--thumbnail-default', '.yt-badge-shape--thumbnail-badge', 'ytd-thumbnail #overlays #time-status']
  });
  toggle('fullTitles', 'Show full video titles', {
    hint: 'No more cut-off titles on cards.',
    rules: [
      ['#video-title, yt-formatted-string#video-title', '-webkit-line-clamp:unset;max-height:none;overflow:visible'],
      ['.ytLockupMetadataViewModelTitle, .ytLockupMetadataViewModelTitle span, .yt-lockup-metadata-view-model-wiz__title', '-webkit-line-clamp:unset;max-height:none;overflow:visible'],
      ['h3.ytLockupMetadataViewModelHeadingReset', 'max-height:none;overflow:visible']
    ]
  });
  toggle('fullChannelName', 'Show full channel name and upload time', {
    hint: 'Stops names and dates from being cut off with "...".',
    rules: [
      ['ytd-channel-name, ytd-channel-name #container, ytd-channel-name #text-container, ytd-channel-name yt-formatted-string, ytd-channel-name #text', 'max-width:none;white-space:normal;text-overflow:clip;overflow:visible'],
      ['#metadata-line, #metadata-line span, .ytContentMetadataViewModelMetadataText, .ytContentMetadataViewModelMetadataRow', 'white-space:normal;text-overflow:clip;overflow:visible;-webkit-line-clamp:unset;max-height:none']
    ]
  });
  const PLAY = 'a[href*="/playables"]';
  toggle('hidePlayables', 'Hide YouTube Playables', {
    def: true,
    hint: 'Removes the Playables games shelf, game cards in feeds and search, and the Playables link in the sidebar.',
    css: [
      `ytd-rich-section-renderer:has(${PLAY})`, `ytd-rich-shelf-renderer:has(${PLAY})`, `ytd-rich-item-renderer:has(${PLAY})`,
      `ytd-shelf-renderer:has(${PLAY})`, `ytd-item-section-renderer:has(> #contents > ${PLAY})`,
      `ytd-video-renderer:has(${PLAY})`, `yt-lockup-view-model:has(${PLAY})`, `ytd-reel-shelf-renderer:has(${PLAY})`,
      `ytd-guide-entry-renderer:has(${PLAY})`, `ytd-mini-guide-entry-renderer:has(${PLAY})`,
      'ytd-rich-section-renderer:has(ytd-rich-shelf-renderer[is-playables])', 'ytd-rich-shelf-renderer[is-playables]', 'ytd-game-card-renderer'
    ]
  });
  toggle('hideHomePosts', 'Homepage: hide Latest YouTube posts', {
    css: [`${HOME} ytd-rich-section-renderer:has(ytd-post-renderer)`, `${HOME} ytd-rich-shelf-renderer:has(ytd-post-renderer)`,
      `${HOME} ytd-rich-section-renderer:has(ytd-rich-shelf-renderer[is-post])`, `${HOME} ytd-post-renderer`]
  });
  toggle('animations', 'More animations', {
    hint: 'Cards lift and fade in; thumbnails zoom slightly on hover.',
    rules: [
      ['ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer', 'transition:transform .18s ease'],
      ['ytd-rich-item-renderer:hover, ytd-compact-video-renderer:hover', 'transform:translateY(-3px)'],
      ['ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer, ytd-comment-thread-renderer', 'animation:rtFade .35s ease both'],
      ['ytd-thumbnail img, yt-thumbnail-view-model img', 'transition:transform .25s ease'],
      ['ytd-thumbnail:hover img, yt-thumbnail-view-model:hover img', 'transform:scale(1.04)']
    ]
  });
  toggle('compactSidebar', 'Compact left sidebar', {
    rules: [
      ['ytd-guide-entry-renderer a.yt-simple-endpoint', 'padding-top:0;padding-bottom:0;min-height:32px;height:32px'],
      ['ytd-guide-entry-renderer yt-formatted-string', 'font-size:1.3rem'],
      ['ytd-guide-section-renderer', 'padding-top:4px;padding-bottom:4px'],
      ['ytd-mini-guide-entry-renderer', 'height:56px;padding:0'],
      ['ytd-mini-guide-renderer', 'width:56px']
    ]
  });
  toggle('compactHeader', 'Compact header bar', {
    rules: [
      ['', '--ytd-masthead-height:44px'],
      ['ytd-masthead', 'height:44px'],
      ['ytd-masthead #container', 'height:44px'],
      ['ytd-masthead yt-searchbox', 'margin-top:0;height:34px'],
      ['ytd-masthead #logo-icon, ytd-masthead ytd-topbar-logo-renderer', 'transform:scale(.85)']
    ]
  });
  toggle('backToTop', 'Show back-to-top button', { hint: 'A small button appears after you scroll down.' });

  // ---- Search -----------------------------------------------------------------------------------
  toggle('hideIrrelevantSearch', 'Hide irrelevant search results', {
    hint: 'Removes "For you", "People also watched", "Previously watched" and similar blocks.'
  });
  toggle('hidePlaylistsSearch', 'Hide playlists in search results', {
    css: [`${SRCH} ytd-playlist-renderer`, `${SRCH} ytd-radio-renderer`, `${SRCH} yt-lockup-view-model:has(yt-collection-thumbnail-view-model)`,
      `${SRCH} yt-lockup-view-model:has([class*="CollectionStack"])`, `${SRCH} yt-lockup-view-model:has(a[href^="/playlist?"])`]
  });
  toggle('hideSearchDescriptions', 'Hide video descriptions in search results', {
    def: true,
    css: [`${SRCH} ytd-video-renderer .metadata-snippet-container`, `${SRCH} ytd-video-renderer #description-text`, `${SRCH} ytd-video-renderer yt-formatted-string.metadata-snippet-text`,
      `${SRCH} ytd-video-renderer .metadata-snippet-text`, `${SRCH} ytd-video-renderer [class*="snippet" i]`, `${SRCH} ytd-video-renderer [id*="snippet" i]`,
 `${SRCH} ytd-channel-renderer #description`, `${SRCH} ytd-playlist-renderer #description`,
      `${SRCH} yt-lockup-view-model .ytLockupMetadataViewModelDescription`, `${SRCH} yt-lockup-view-model [class*="MetadataDescription"]`,
      `${SRCH} yt-lockup-view-model [class*="MetadataSnippet"]`, `${SRCH} yt-lockup-view-model [class*="DescriptionSnippet"]`]
  });
  toggle('hideSearchChannelDesc', 'Hide channel descriptions in search results', {
    css: [`${SRCH} ytd-channel-renderer #description`, `${SRCH} ytd-channel-renderer yt-formatted-string#description`, `${SRCH} ytd-channel-renderer .description`,
      `${SRCH} yt-lockup-view-model:has(a[href^="/@"]):not(:has(a[href*="/watch"])) [class*="Description"]`]
  });
  toggle('searchChannelRow', 'Channels in a sideways-scrolling row at the top', {
    hint: 'Channel results sit in one row above the videos, with the name under the picture, so you reach videos without scrolling.', def: true
  });
  toggle('searchGrid', 'Search results in grid view', { hint: 'Uses the "Videos per row" slider from the Home page.' });
  toggle('searchNewTab', 'Open search results in a new tab');

  // ---- Header -----------------------------------------------------------------------------------
  toggle('logoToSubs', 'YouTube logo goes to Subscriptions');

  // ---- Watch page ---------------------------------------------------------------------------------
  toggle('autoExpandDescription', 'Auto-expand video description');
  area('autoExpandChannels', 'Auto-expand the description only for these channels', { placeholder: '@somechannel\nSome Channel', hint: 'One per line: the channel name, @handle or channel ID. Only used while "Auto-expand video description" is off.' });
  toggle('autoExpandComments', 'Auto-expand comments', { hint: 'Opens "Read more" on long comments as they load.' });
  toggle('commentSearch', 'Search bar for comments', { def: true, hint: 'Adds a search box above the comments. Type words to find a comment, or @name to find comments by that user. Searches the comments that have loaded.' });
  toggle('commentsInSidebar', 'Show comments in sidebar', { hint: 'Moves the comments next to the video, above the related videos.' });
  toggle('sidebarChannelLinks', 'Allow opening channels from the sidebar', { hint: 'Makes channel names on related videos clickable.',
    rules: [[`${WATCH} #secondary a[href^="/@"], ${WATCH} #secondary a[href^="/channel/"]`, 'pointer-events:auto;cursor:pointer']] });
  toggle('redSubscribe', 'Bring back the red Subscribe button', {
    rules: [[`${WATCH} #subscribe-button button:not([aria-label^="Subscribed" i]):not([aria-label^="Unsubscribe" i]), ${WATCH} yt-subscribe-button-view-model button:not([aria-label^="Subscribed" i]):not([aria-label^="Unsubscribe" i]), ${WATCH} ytd-subscribe-button-renderer button:not([aria-label^="Subscribed" i])`,
      'background:#cc0000;color:#fff']]
  });
  toggle('videoFocus', 'Video focus', { hint: 'Dims everything except the video while it plays. Move the mouse over a dimmed area to see it.' });
  toggle('pinPlayer', 'Pin video while scrolling', { hint: 'Keeps the playing video in a small corner window when you scroll down.' });

  // ---- Live chat ---------------------------------------------------------------------------------------
  toggle('noAutoLiveChat', 'Disable auto-opening of live chat');
  toggle('liveChatDefault', 'Use "Live chat" instead of "Top chat"', { hint: 'In live streams and replays.' });

  // ---- Player ---------------------------------------------------------------------------------------------
  toggle('perChannelSpeed', 'Remember playback speed per channel', { hint: 'Change the speed on a video and that channel keeps it next time.' });
  toggle('wheelVolume', 'Mouse wheel over the video changes volume');
  toggle('wheelSpeed', 'Alt + mouse wheel changes playback speed');
  toggle('wheelSeek', 'Shift + mouse wheel seeks the video');
  range('volumeBoost', 'Volume boost', 100, 400, 25, 100, { unit: '%', hint: 'Above 100% makes quiet videos louder. Starts after your first click on the page.' });
  toggle('monoAudio', 'Mono audio');
  toggle('forceOriginalAudio', 'Force the original audio track', { hint: 'For videos with auto-dubbed audio.' });
  toggle('screenshotButton', 'Video screenshot button', { hint: 'Adds a camera button to the player. Saves a PNG.' });
  toggle('pauseOthers', 'Pause the previous video when another starts', { hint: 'Works across YouTube tabs.' });
  toggle('disableMiniplayer', 'Disable the miniplayer', {
    alts: ['Turn off miniplayer', 'No miniplayer'],
    hint: 'Removes the miniplayer button and the I shortcut. When you leave a video page the video closes instead of shrinking into the corner.',
    css: ['.ytp-miniplayer-button', 'ytd-miniplayer', 'ytd-miniplayer-toast', '.ytp-miniplayer-ui']
  });
  toggle('noPausedPrompt', 'Disable "Video paused. Continue watching?"');
  toggle('noPlaylistAutoplay', 'Disable auto-play of the next video in playlists');
  toggle('noNumberKeys', 'Disable number-key shortcuts', { hint: 'Stops 0-9 from jumping around in the video.' });
  toggle('autoPip', 'Auto picture-in-picture on tab change', { hint: 'Chrome may ask once before it allows this.' });
  toggle('remainingTime', 'Show video remaining time');
  toggle('hideControlsOnPause', 'Hide video controls on pause', {
    rules: [['.html5-video-player.paused-mode .ytp-chrome-bottom, .html5-video-player.paused-mode .ytp-gradient-bottom, .html5-video-player.paused-mode .ytp-chrome-top', 'opacity:0']]
  });
  toggle('alwaysProgress', 'Always show the progress bar', {
    rules: [['.html5-video-player.ytp-autohide .ytp-chrome-bottom', 'opacity:1;display:block'], ['.html5-video-player.ytp-autohide .ytp-chrome-controls', 'opacity:0']]
  });
  toggle('nyanBar', 'Rainbow cat progress bar', {
    rules: [
      ['.ytp-play-progress', 'background:linear-gradient(to bottom,#f33 0 16%,#f90 16% 33%,#fe3 33% 50%,#3d3 50% 66%,#39f 66% 83%,#93f 83%);position:relative'],
      ['.ytp-play-progress::after', 'content:"\\1F431";position:absolute;right:-10px;top:-8px;font-size:15px;line-height:1']
    ]
  });

  // ---- Shorts ---------------------------------------------------------------------------------------------------
  toggle('shortsAutoScroll', 'Auto-scroll Shorts', { hint: 'Moves to the next Short when one ends.' });
  toggle('shortsNoLoop', 'Stop Shorts from looping', { hint: 'The Short pauses at the end. Ignored if Auto-scroll is on.' });

  // ---- Hotkeys ------------------------------------------------------------------------------------------------------
  hotkey('hk_like', 'Like');
  hotkey('hk_dislike', 'Dislike');
  hotkey('hk_screenshot', 'Take a screenshot');
  hotkey('hk_pip', 'Toggle picture-in-picture');
  hotkey('hk_mirror', 'Mirror the video');
  hotkey('hk_flip', 'Flip the video upside down');
  hotkey('hk_rotate', 'Rotate the video');
  hotkey('hk_zoomIn', 'Zoom in');
  hotkey('hk_zoomOut', 'Zoom out');
  hotkey('hk_resetView', 'Reset zoom / flip / rotate');
  hotkey('hk_seekFwd', 'Seek forward');
  hotkey('hk_seekBack', 'Seek backward');
  hotkey('hk_undoSeek', 'Undo last seek');
  hotkey('hk_volUp', 'Volume up');
  hotkey('hk_volDown', 'Volume down');
  hotkey('hk_speedUp', 'Speed up');
  hotkey('hk_speedDown', 'Slow down');
  hotkey('hk_qualityUp', 'Higher quality');
  hotkey('hk_qualityDown', 'Lower quality');
  hotkey('hk_loop', 'Toggle loop');
  hotkey('hk_home', 'Go to Home');
  hotkey('hk_subs', 'Go to Subscriptions');
  hotkey('hk_shorts', 'Go to Shorts');
  hotkey('hk_top', 'Scroll to top');
  range('seekStep', 'Seek step', 1, 60, 1, 10, { unit: ' s', hint: 'Used by the seek hotkeys and Shift + wheel.' });

  // ---- Menu placement (the menu only exists in the popup) -----------------------------------------------------
  const put = (id, ...rows) => { const s = RT.SECTIONS.find((x) => x.id === id); if (s) rows.forEach((r) => { if (!s.rows.includes(r)) s.rows.push(r); }); };
  put('home', 'hidePlayables', 'gridHideAvatars', 'gridSmallFont', 'fullTitles', 'fullChannelName', 'hideHomePosts');
  put('search', 'hidePlayables', 'searchChannelRow', 'hideSearchChannelDesc', 'hideSearchDescriptions', 'hidePlaylistsSearch', 'hideIrrelevantSearch', 'searchGrid', 'searchNewTab');
  put('sidebar', 'hidePlayables');
  put('interface', 'animations', 'compactSidebar', 'compactHeader', 'backToTop');
  put('header', 'logoToSubs');
  put('video', 'commentSearch', 'autoExpandDescription', 'commentsInSidebar', 'sidebarChannelLinks', 'redSubscribe', 'videoFocus', 'pinPlayer');
  put('comments', 'autoExpandComments', 'commentsInSidebar');
  put('livechat', 'noAutoLiveChat', 'liveChatDefault');
  put('video', 'perChannelSpeed', 'wheelVolume', 'wheelSpeed', 'wheelSeek', 'volumeBoost', 'monoAudio', 'forceOriginalAudio', 'screenshotButton',
    'pauseOthers', 'noPausedPrompt', 'noPlaylistAutoplay', 'noNumberKeys', 'autoPip', 'remainingTime', 'hideControlsOnPause', 'alwaysProgress', 'nyanBar');
  put('shorts', 'shortsAutoScroll', 'shortsNoLoop');
  put('shortcuts', 'hk_like', 'hk_dislike', 'hk_screenshot', 'hk_pip', 'hk_mirror', 'hk_flip', 'hk_rotate', 'hk_zoomIn', 'hk_zoomOut', 'hk_resetView',
    'hk_seekFwd', 'hk_seekBack', 'hk_undoSeek', 'seekStep', 'hk_volUp', 'hk_volDown', 'hk_speedUp', 'hk_speedDown', 'hk_qualityUp', 'hk_qualityDown',
    'hk_loop', 'hk_home', 'hk_subs', 'hk_shorts', 'hk_top');
  if (RT.CORE) {
    const core = (id, ...r) => { RT.CORE[id] = (RT.CORE[id] || []).concat(r); };
    core('home', 'hidePlayables', 'fullTitles', 'gridHideAvatars');
    core('search', 'hidePlayables', 'searchChannelRow', 'hidePlaylistsSearch', 'hideIrrelevantSearch', 'searchGrid');
    core('video', 'perChannelSpeed', 'volumeBoost');
    core('video', 'autoExpandDescription', 'commentSearch');
  }
  RT.extraCss = (RT.extraCss || []).concat([
    '#rt-chan-wrap{position:relative;order:-3;margin:0 0 16px;padding:0 0 4px}',
    '#rt-chan-row{display:flex;gap:12px;overflow-x:auto;scroll-snap-type:x proximity;scrollbar-width:none;padding:4px 2px}',
    '#rt-chan-row::-webkit-scrollbar{display:none}',
    '#rt-chan-row > *{flex:0 0 190px !important;width:190px !important;max-width:190px !important;scroll-snap-align:start;margin:0 !important;padding:12px 8px !important;box-sizing:border-box;border-radius:12px;background:var(--yt-spec-badge-chip-background,rgba(128,128,128,.12))}',
    '#rt-chan-row ytd-channel-renderer #content-section,#rt-chan-row ytd-channel-renderer{display:flex !important;flex-direction:column !important;align-items:center !important;text-align:center !important}',
    '#rt-chan-row ytd-channel-renderer #avatar-section{width:auto !important;flex:none !important;margin:0 0 8px !important}',
    '#rt-chan-row ytd-channel-renderer #info-section{width:100% !important;flex:none !important;margin:0 !important}',
    '#rt-chan-row ytd-channel-renderer #description,#rt-chan-row ytd-channel-renderer yt-formatted-string#description,#rt-chan-row ytd-channel-renderer #metadata,#rt-chan-row ytd-channel-renderer #subscribers,#rt-chan-row ytd-channel-renderer #video-count,#rt-chan-row ytd-channel-renderer #buttons,#rt-chan-row ytd-channel-renderer #subscribe-button,#rt-chan-row ytd-channel-renderer ytd-subscribe-button-renderer,#rt-chan-row ytd-channel-renderer yt-subscribe-button-view-model,#rt-chan-row ytd-channel-renderer #info-text,#rt-chan-row ytd-channel-renderer #channel-handle,#rt-chan-row ytd-channel-renderer #handle,#rt-chan-row ytd-channel-renderer #inline-views{display:none !important}',
    '#rt-chan-row ytd-channel-renderer #info-section,#rt-chan-row ytd-channel-renderer #main-link,#rt-chan-row ytd-channel-renderer #info{min-width:0 !important;max-width:100% !important;width:100% !important;display:block !important;text-align:center !important}',
    '#rt-chan-row ytd-channel-renderer ytd-channel-name,#rt-chan-row ytd-channel-renderer ytd-channel-name #container{display:flex !important;flex-direction:row !important;align-items:center !important;justify-content:center !important;flex-wrap:wrap !important;gap:4px !important;max-width:100% !important;min-width:0 !important}',
    '#rt-chan-row ytd-channel-renderer ytd-channel-name #text-container{min-width:0 !important;max-width:100% !important;display:block !important}',
    '#rt-chan-row ytd-channel-renderer ytd-badge-supported-renderer{display:inline-flex !important;flex:none !important}',
    '#rt-chan-row ytd-channel-renderer #text,#rt-chan-row ytd-channel-renderer ytd-channel-name yt-formatted-string{white-space:normal !important;overflow:visible !important;overflow-wrap:anywhere !important;text-overflow:clip !important;font-size:1.5rem !important;font-weight:500 !important}',
    '#rt-chan-row ytd-channel-renderer #avatar,#rt-chan-row ytd-channel-renderer #avatar yt-img-shadow{width:88px !important;height:88px !important;min-width:88px !important;margin:0 auto !important;border-radius:50% !important;overflow:hidden !important;display:block !important}',
    '#rt-chan-row ytd-channel-renderer #avatar img{width:100% !important;height:100% !important;max-width:none !important;object-fit:cover !important;border-radius:50% !important;margin:0 !important}',
    '#rt-chan-row ytd-channel-renderer #avatar-section{margin:0 0 8px !important;min-width:0 !important;width:100% !important;display:flex !important;justify-content:center !important}',
    '#rt-chan-row yt-lockup-view-model [class*="MetadataRow"],#rt-chan-row yt-lockup-view-model [class*="ContentMetadata"],#rt-chan-row yt-lockup-view-model button,#rt-chan-row yt-lockup-view-model [class*="ubscribe"]{display:none !important}',
    '#rt-chan-row ytd-channel-renderer #subscribe-button,#rt-chan-row ytd-channel-renderer #buttons{margin:8px 0 0 !important;width:auto !important;flex:none !important}',
    '#rt-chan-row ytd-channel-renderer ytd-channel-name{justify-content:center}',
    '#rt-chan-row yt-lockup-view-model [class*="ytLockupViewModelHorizontal"],#rt-chan-row yt-lockup-view-model [class*="LockupViewModelHost"]{flex-direction:column !important;align-items:center !important;text-align:center !important}',
    '#rt-chan-row yt-lockup-view-model [class*="Description"]{display:none !important}',
    '.rt-chan-arrow{position:absolute;top:50%;transform:translateY(-60%);z-index:3;width:34px;height:34px;border-radius:17px;border:0;background:rgba(40,40,40,.85);color:#fff;font-size:18px;cursor:pointer;opacity:0;transition:opacity .15s}',
    '#rt-chan-wrap:hover .rt-chan-arrow{opacity:1}',
    '#rt-chan-wrap .rt-chan-l{left:-6px}#rt-chan-wrap .rt-chan-r{right:-6px}',
    '@keyframes rtFade{from{opacity:0}to{opacity:1}}',
    'html[data-rt-pinned] ytd-watch-flexy #movie_player{position:fixed !important;right:16px !important;bottom:16px !important;left:auto !important;top:auto !important;width:420px !important;height:236px !important;z-index:2000 !important;box-shadow:0 6px 24px rgba(0,0,0,.55) !important;border-radius:10px !important;overflow:hidden !important}',
    'html[data-rt-vf] #masthead-container,html[data-rt-vf] ytd-watch-flexy #secondary,html[data-rt-vf] ytd-watch-flexy #below,html[data-rt-vf] tp-yt-app-drawer{opacity:.06;transition:opacity .4s}',
    'html[data-rt-vf] #masthead-container:hover,html[data-rt-vf] ytd-watch-flexy #secondary:hover,html[data-rt-vf] ytd-watch-flexy #below:hover,html[data-rt-vf] tp-yt-app-drawer:hover{opacity:1}'
  ]);
})();
