// Clear Watch Later button
//
// Adds a "Clear Watch Later" button to youtube.com/playlist?list=WL. After a
// confirmation, it removes every video by using YouTube's own per-video
// "Remove from Watch later" menu entry, one video at a time (the same clicks
// you'd make by hand). It can be stopped at any point by clicking the button
// again, and the videos removed so far stay removed.

(function () {
  'use strict';

  const BUTTON_ID = 'wls-clear-watch-later';
  const STYLE_ID = 'wls-clear-watch-later-style';
  const enabled = true;
  let running = false;
  let cancelRequested = false;

  function isWatchLaterPage() {
    return (
      location.hostname === 'www.youtube.com' &&
      location.pathname === '/playlist' &&
      new URLSearchParams(location.search).get('list') === 'WL'
    );
  }

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  async function waitFor(fn, timeout = 2500, step = 60) {
    const end = Date.now() + timeout;
    while (Date.now() < end) {
      const v = fn();
      if (v) return v;
      await sleep(step);
    }
    return null;
  }

  function videoRows() {
    return Array.from(document.querySelectorAll('ytd-playlist-video-renderer'));
  }

  function totalVideoCount() {
    const header = document.querySelector('ytd-playlist-header-renderer, yt-page-header-renderer');
    const m = header && header.textContent.match(/([\d,]+)\s*videos?/i);
    if (m) return parseInt(m[1].replace(/,/g, ''), 10);
    return null;
  }

  // --- the actual removal ----------------------------------------------------

  function findRemoveItem() {
    const items = document.querySelectorAll(
      'ytd-menu-popup-renderer ytd-menu-service-item-renderer, ytd-menu-popup-renderer tp-yt-paper-item, yt-list-item-view-model'
    );
    return Array.from(items).find((el) => /remove from/i.test(el.textContent || '')) || null;
  }

  async function removeRow(row) {
    const menuBtn = row.querySelector('ytd-menu-renderer button, #menu button');
    if (!menuBtn) return false;

    menuBtn.click();
    const item = await waitFor(findRemoveItem, 2500);
    if (!item) {
      document.body.click(); // close any open menu
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      return false;
    }
    item.click();
    // success = this row leaves the page
    return !!(await waitFor(() => !row.isConnected, 4000));
  }

  function setPopupsHidden(hidden) {
    let style = document.getElementById(STYLE_ID);
    if (hidden && !style) {
      style = document.createElement('style');
      style.id = STYLE_ID;
      // The menu still works, it just doesn't flash on screen for every video.
      style.textContent = 'ytd-popup-container { opacity: 0 !important; }';
      document.documentElement.appendChild(style);
    } else if (!hidden && style) {
      style.remove();
    }
  }

  async function clearAll(button) {
    const known = totalVideoCount();
    const loaded = videoRows().length;
    if (!loaded) {
      window.alert('No videos found on this page to remove.');
      return;
    }
    const label = known != null ? `all ${known}` : loaded >= 100 ? 'all' : `all ${loaded}`;
    if (!window.confirm(`Remove ${label} videos from Watch Later?\n\nThis can't be undone.`)) return;

    running = true;
    cancelRequested = false;
    setPopupsHidden(true);
    let removed = 0;
    let failures = 0;
    let emptyChecks = 0;

    const render = () => {
      button.textContent = `Removing… ${removed}${known != null ? ' / ' + known : ''} (click to stop)`;
    };
    render();

    try {
      while (!cancelRequested) {
        if (known != null && removed >= known) break;
        const row = videoRows()[0];
        if (!row) {
          // Maybe more are still loading further down: nudge, then re-check.
          if (++emptyChecks > 3) break;
          window.scrollTo(0, document.documentElement.scrollHeight);
          await sleep(1200);
          continue;
        }
        emptyChecks = 0;
        const ok = await removeRow(row);
        if (ok) {
          removed++;
          failures = 0;
          render();
        } else if (++failures >= 3) {
          break;
        }
        await sleep(120);
      }
    } finally {
      running = false;
      setPopupsHidden(false);
    }

    if (!cancelRequested && failures < 3) {
      button.textContent = `Done — removed ${removed} video${removed === 1 ? '' : 's'}`;
      setTimeout(() => refreshButtonLabel(button), 4000);
    } else {
      refreshButtonLabel(button);
    }

    if (failures >= 3) {
      window.alert(
        `Stopped after removing ${removed} video${removed === 1 ? '' : 's'}: YouTube's menu didn't respond the way this extension expects.`
      );
    } else if (cancelRequested) {
      window.alert(`Stopped. Removed ${removed} video${removed === 1 ? '' : 's'}.`);
    }
  }

  // --- button ------------------------------------------------------------------

  function refreshButtonLabel(button) {
    if (!running) button.textContent = 'Clear Watch Later';
  }

  function styleInline(button) {
    button.style.cssText =
      'display:inline-flex;align-items:center;height:36px;padding:0 16px;margin-left:8px;border:none;border-radius:18px;' +
      'cursor:pointer;font:500 14px/36px Roboto,Arial,sans-serif;color:inherit;white-space:nowrap;' +
      'background:color-mix(in srgb, currentColor 10%, transparent);';
  }

  function styleFloating(button) {
    button.style.cssText =
      'position:fixed;right:24px;bottom:24px;z-index:2100;height:40px;padding:0 18px;border:none;border-radius:20px;' +
      'cursor:pointer;font:500 14px/40px Roboto,Arial,sans-serif;color:#fff;background:#cc0000;box-shadow:0 2px 8px rgba(0,0,0,.4);';
  }

  function findActionsContainer() {
    return (
      document.querySelector('ytd-playlist-header-renderer #action-buttons') ||
      document.querySelector('ytd-playlist-header-renderer .play-menu') ||
      document.querySelector('yt-page-header-renderer yt-flexible-actions-view-model') ||
      document.querySelector('yt-flexible-actions-view-model')
    );
  }

  function ensureButton() {
    const existing = document.getElementById(BUTTON_ID);
    if (!enabled || !isWatchLaterPage()) {
      if (existing && !running) existing.remove();
      return;
    }
    if (existing) return;

    const button = document.createElement('button');
    button.id = BUTTON_ID;
    button.type = 'button';
    button.textContent = 'Clear Watch Later';
    button.addEventListener('click', () => {
      if (running) {
        cancelRequested = true;
        return;
      }
      clearAll(button);
    });

    const container = findActionsContainer();
    if (container) {
      styleInline(button);
      container.appendChild(button);
    } else {
      styleFloating(button);
      document.body.appendChild(button);
    }
  }

  // --- lifecycle -----------------------------------------------------------------

  setInterval(ensureButton, 1000);
  document.addEventListener('yt-navigate-finish', ensureButton);

  ensureButton();
})();
