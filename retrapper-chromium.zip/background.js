// ReTrapper — background service worker (Watch Later playlist fetch)
//
// Fetches the signed-in user's "Watch Later" playlist page and extracts
// the embedded ytInitialData JSON to pull out video entries. This runs in
// the background rather than the content script so the request isn't
// subject to the YouTube page's own Content-Security-Policy, and so it can
// use host_permissions to carry the user's existing youtube.com session
// cookies (the same way the browser would if you visited the page
// yourself — no separate sign-in or token handling needed).
//
// Written for Chromium browsers (Brave, Chrome, Edge) as a Manifest V3
// service worker.

const WATCH_LATER_URL = 'https://www.youtube.com/playlist?list=WL';
const MAX_VIDEOS = 18;

function extractJsonAfter(html, marker) {
  const idx = html.indexOf(marker);
  if (idx === -1) return null;
  const start = html.indexOf('{', idx);
  if (start === -1) return null;

  let depth = 0;
  let inString = false;
  let escaped = false;

  for (let i = start; i < html.length; i++) {
    const ch = html[i];

    if (inString) {
      if (escaped) {
        escaped = false;
      } else if (ch === '\\') {
        escaped = true;
      } else if (ch === '"') {
        inString = false;
      }
      continue;
    }

    if (ch === '"') {
      inString = true;
      continue;
    }
    if (ch === '{') depth++;
    else if (ch === '}') {
      depth--;
      if (depth === 0) return html.slice(start, i + 1);
    }
  }
  return null;
}

function lockupToVideoInfo(l) {
  const id = l && l.contentId;
  if (!id || !/^[\w-]{11}$/.test(id)) return null;
  if (l.contentType && !/VIDEO/.test(l.contentType)) return null;
  const md = l.metadata && l.metadata.lockupMetadataViewModel;
  const title = (md && md.title && md.title.content) || 'Untitled video';
  const rows = (md && md.metadata && md.metadata.contentMetadataViewModel && md.metadata.contentMetadataViewModel.metadataRows) || [];
  const part = rows[0] && rows[0].metadataParts && rows[0].metadataParts[0];
  const channel = (part && part.text && part.text.content) || '';
  const cmd = part && part.text && part.text.commandRuns && part.text.commandRuns[0] && part.text.commandRuns[0].onTap && part.text.commandRuns[0].onTap.innertubeCommand;
  const be = cmd && cmd.browseEndpoint;
  const channelUrl = be && be.canonicalBaseUrl ? 'https://www.youtube.com' + be.canonicalBaseUrl : be && be.browseId ? 'https://www.youtube.com/channel/' + be.browseId : '';
  const tv = l.contentImage && (l.contentImage.thumbnailViewModel || (l.contentImage.collectionThumbnailViewModel && l.contentImage.collectionThumbnailViewModel.primaryThumbnail && l.contentImage.collectionThumbnailViewModel.primaryThumbnail.thumbnailViewModel));
  const srcs = (tv && tv.image && tv.image.sources) || [];
  let duration = '';
  const ov = (tv && tv.overlays) || [];
  ov.forEach((o) => {
    const b = o.thumbnailBottomOverlayViewModel && o.thumbnailBottomOverlayViewModel.badges;
    const t = b && b[0] && b[0].thumbnailBadgeViewModel && b[0].thumbnailBadgeViewModel.text;
    if (t && !duration) duration = t;
  });
  return { videoId: id, title, channel, channelUrl, duration, thumbnail: srcs.length ? srcs[srcs.length - 1].url : '', index: null };
}

function findPlaylistVideoRenderers(root) {
  const out = [];
  const seen = new Set();
  const ids = new Set();
  (function walk(obj) {
    if (!obj || typeof obj !== 'object' || seen.has(obj)) return;
    seen.add(obj);
    if (obj.playlistVideoRenderer) { out.push(obj.playlistVideoRenderer); if (obj.playlistVideoRenderer.videoId) ids.add(obj.playlistVideoRenderer.videoId); }
    else if (obj.lockupViewModel) {
      const info = lockupToVideoInfo(obj.lockupViewModel);
      if (info && !ids.has(info.videoId)) { ids.add(info.videoId); out.push({ __info: info }); }
    }
    for (const key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) walk(obj[key]);
    }
  })(root);
  return out;
}

function toVideoInfo(renderer) {
  if (renderer && renderer.__info) return renderer.__info;
  const thumbs = renderer?.thumbnail?.thumbnails || [];
  const thumbnail = thumbs.length ? thumbs[thumbs.length - 1].url : '';
  const title =
    renderer?.title?.runs?.[0]?.text || renderer?.title?.simpleText || 'Untitled video';
  const channelRun = renderer?.shortBylineText?.runs?.[0];
  const channel = channelRun?.text || '';
  const browse = channelRun?.navigationEndpoint?.browseEndpoint;
  const channelUrl = browse?.canonicalBaseUrl
    ? `https://www.youtube.com${browse.canonicalBaseUrl}`
    : browse?.browseId
      ? `https://www.youtube.com/channel/${browse.browseId}`
      : '';
  const duration = renderer?.lengthText?.simpleText || '';
  const idx =
    renderer?.navigationEndpoint?.watchEndpoint?.index ??
    (parseInt(renderer?.index?.simpleText, 10) - 1);
  const index = Number.isFinite(idx) && idx >= 0 ? idx : null;
  const infoRuns = (renderer?.videoInfo?.runs || []).map((r) => r.text || '');
  const published = infoRuns.find((t) => /\bago\b|^(streamed|premiered)/i.test(t)) || '';
  return { videoId: renderer?.videoId, title, channel, channelUrl, duration, thumbnail, index, published };
}


// --- Watch Later sort order -----------------------------------------------------------------------
// The playlist page carries a sort menu ("Date added (newest)", "Most popular", ...). Find it, and (when the viewer has
// picked a different order on the Watch Later page) fetch the playlist in that order from YouTube itself.
const normSort = (t) => String(t || '').toLowerCase().replace(/\s+/g, ' ').trim();
function findSort(root) {
  let found = null, budget = 60000;
  const seen = new Set();
  (function walk(o, d) {
    if (found || !o || typeof o !== 'object' || seen.has(o) || budget-- <= 0 || d > 60) return;
    seen.add(o);
    if (Array.isArray(o.subMenuItems) && o.subMenuItems.length >= 2 && o.subMenuItems.some((x) => x && typeof x.selected === 'boolean' && x.title)) {
      const tokenOf = (x) => { let t = ''; (function w(n, dd) { if (t || !n || typeof n !== 'object' || dd > 12) return; if (n.continuationCommand && n.continuationCommand.token) { t = n.continuationCommand.token; return; } for (const k in n) w(n[k], dd + 1); })(x, 0); return t; };
      const options = o.subMenuItems.filter((x) => x && x.title).map((x) => ({ title: String(x.title), selected: !!x.selected, token: tokenOf(x) }));
      const sel = options.find((x) => x.selected);
      found = { selected: sel ? sel.title : '', options };
      return;
    }
    for (const k in o) walk(o[k], d + 1);
  })(root, 0);
  return found;
}

async function fetchSorted(html, token, limit) {
  const key = (/"INNERTUBE_API_KEY":"([^"]+)"/.exec(html) || [])[1] || '';
  const ctxStr = extractJsonAfter(html, '"INNERTUBE_CONTEXT":');
  if (!ctxStr || !token) return [];
  const context = JSON.parse(ctxStr);
  const cl = context.client || {};
  const res = await fetch('https://www.youtube.com/youtubei/v1/browse?prettyPrint=false' + (key ? '&key=' + encodeURIComponent(key) : ''), {
    method: 'POST', credentials: 'include',
    headers: { 'content-type': 'application/json', 'x-youtube-client-name': '1', 'x-youtube-client-version': cl.clientVersion || '' },
    body: JSON.stringify({ context, continuation: token })
  });
  if (!res.ok) return [];
  const j = await res.json();
  return findPlaylistVideoRenderers(j).slice(0, limit).map(toVideoInfo).filter((v) => v.videoId).map((v, i) => ({ ...v, index: v.index ?? i }));
}

async function fetchWatchLater(limit = MAX_VIDEOS) {
  let res;
  try {
    res = await fetch(WATCH_LATER_URL, { credentials: 'include', cache: 'no-store' });
  } catch (e) {
    console.error('[Watch Later Shelf] fetch failed:', e);
    return { videos: [], signedIn: true, error: `fetch-failed: ${e}` };
  }

  if (!res.ok) {
    console.error('[Watch Later Shelf] fetch returned', res.status);
    return { videos: [], signedIn: true, error: `HTTP ${res.status}` };
  }

  const html = await res.text();

  const markers = ['var ytInitialData = ', 'window["ytInitialData"] = ', 'ytInitialData = '];
  let jsonStr = null;
  for (const marker of markers) {
    jsonStr = extractJsonAfter(html, marker);
    if (jsonStr) break;
  }
  if (!jsonStr) {
    console.error('[Watch Later Shelf] could not locate ytInitialData.');
    return { videos: [], signedIn: true, error: 'no-data-found' };
  }

  let data;
  try {
    data = JSON.parse(jsonStr);
  } catch (e) {
    console.error('[Watch Later Shelf] failed to parse ytInitialData:', e);
    return { videos: [], signedIn: true, error: `parse-failed: ${e}` };
  }

  const renderers = findPlaylistVideoRenderers(data);
  const signedIn = !/Sign in to see videos saved to Watch later/i.test(html);

  let videos = renderers
    .slice(0, limit)
    .map(toVideoInfo)
    .filter((v) => v.videoId)
    .map((v, i) => ({ ...v, index: v.index ?? i }));

  // keep the shelf in the order the viewer uses on the Watch Later page
  let sortInfo = { page: '', used: '', pref: '', options: 0 };
  try {
    const sort = findSort(data);
    let st = null; try { st = (await chrome.storage.local.get('rtWlSort')).rtWlSort || null; } catch (e) { st = null; }
    sortInfo = { page: sort ? sort.selected : '', used: sort ? sort.selected : '', pref: st && st.pref || '', options: sort ? sort.options.length : 0, persisted: !!(st && st.persisted) };
    if (sort && sort.selected && st && st.pref && !st.persisted && normSort(st.pref) !== normSort(sort.selected)) {
      const opt = sort.options.find((o) => normSort(o.title) === normSort(st.pref));
      if (opt && opt.token) {
        const sorted = await fetchSorted(html, opt.token, limit);
        if (sorted.length) { videos = sorted; sortInfo.used = opt.title; } else sortInfo.note = 'sorted-fetch-empty';
      } else sortInfo.note = 'no-token';
    }
  } catch (e) { sortInfo.note = 'sort-error ' + String(e).slice(0, 60); }

  return { videos, signedIn: signedIn || videos.length > 0, error: null, sort: sortInfo };
}


const API = chrome;

// --- channel avatars for the shelf cards ------------------------------------------------------
// The playlist page does not include channel pictures, so read each channel's page just far enough
// to find its og:image, and remember the result.
async function fetchAvatar(channelUrl) {
  try {
    const res = await fetch(channelUrl, { credentials: 'omit' });
    if (!res.ok || !res.body) return '';
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = '';
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      const m = buf.match(/<meta property="og:image" content="([^"]+)"/);
      if (m) { reader.cancel(); return m[1].replace(/=s\d+[^"]*$/, '=s88-c-k-c0x00ffffff-no-rj'); }
      if (buf.length > 1.5e6) { reader.cancel(); break; }
    }
  } catch (e) { /* no avatar */ }
  return '';
}

async function fetchAvatars(urls) {
  const wanted = Array.from(new Set((urls || []).filter((u) => typeof u === 'string' && /^https:\/\/www\.youtube\.com\//.test(u))));
  let cache = {};
  try { cache = (await API.storage.local.get('wlAvatars')).wlAvatars || {}; } catch (e) { /* ignore */ }
  const missing = wanted.filter((u) => !(u in cache));
  for (let i = 0; i < missing.length; i += 4) {
    await Promise.all(missing.slice(i, i + 4).map(async (u) => { cache[u] = await fetchAvatar(u); }));
  }
  if (missing.length) {
    const keys = Object.keys(cache);
    if (keys.length > 400) keys.slice(0, keys.length - 400).forEach((k) => delete cache[k]);
    try { await API.storage.local.set({ wlAvatars: cache }); } catch (e) { /* ignore */ }
  }
  const out = {};
  wanted.forEach((u) => { if (cache[u]) out[u] = cache[u]; });
  return out;
}

// --- DeArrow branding (opt-in) ------------------------------------------------
//
// DeArrow is a community project that crowdsources better titles and
// thumbnails. We ask its public API for the videos on the shelf. Following
// DeArrow's own privacy approach, only a short SHA-256 hash prefix of each
// video ID is sent, never the full ID; the response is filtered locally.

const DEARROW_API = 'https://sponsor.ajay.app/api/branding/';
const DEARROW_THUMB = 'https://dearrow-thumb.ajay.app/api/v1/getThumbnail';

async function hashPrefix(videoId) {
  const bytes = new TextEncoder().encode(videoId);
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(digest))
    .slice(0, 2)
    .map((n) => n.toString(16).padStart(2, '0'))
    .join('');
}

function cleanDearrowTitle(title) {
  // ">" in a DeArrow title marks "don't auto-format the next word".
  return String(title).replace(/(^|\s)>(?=\S)/g, '$1').trim();
}

function pickBranding(videoId, entry) {
  const out = {};
  const usable = (x) => x && (x.locked || x.votes >= 0);

  const title = (entry?.titles || [])[0];
  if (usable(title) && !title.original && title.title) {
    out.title = cleanDearrowTitle(title.title);
  }

  const thumb = (entry?.thumbnails || [])[0];
  if (usable(thumb) && !thumb.original && typeof thumb.timestamp === 'number') {
    out.thumbnail = `${DEARROW_THUMB}?videoID=${encodeURIComponent(videoId)}&time=${thumb.timestamp}`;
  }
  return out;
}

async function fetchDearrow(videoIds) {
  const result = {};
  const byPrefix = new Map();
  for (const id of videoIds) {
    if (!id) continue;
    const prefix = await hashPrefix(id);
    if (!byPrefix.has(prefix)) byPrefix.set(prefix, []);
    byPrefix.get(prefix).push(id);
  }

  await Promise.all(
    Array.from(byPrefix.entries()).map(async ([prefix, ids]) => {
      try {
        const res = await fetch(DEARROW_API + prefix);
        if (!res.ok) return; // 404 = nothing submitted for these
        const data = await res.json();
        ids.forEach((id) => {
          const picked = pickBranding(id, data?.[id]);
          if (picked.title || picked.thumbnail) result[id] = picked;
        });
      } catch (e) {
        console.error('[Watch Later Shelf] DeArrow lookup failed:', e);
      }
    })
  );
  return result;
}

// Chrome-style listener: reply with sendResponse and return true so the
// message channel stays open for the async fetch.
const dislikeCache = new Map();
async function fetchDislikes(videoId) {
  const hit = dislikeCache.get(videoId);
  if (hit && Date.now() - hit.at < 10 * 60 * 1000) return hit.data;
  const res = await fetch('https://returnyoutubedislikeapi.com/votes?videoId=' + encodeURIComponent(videoId));
  if (!res.ok) throw new Error('RYD ' + res.status);
  const j = await res.json();
  const data = { dislikes: j.dislikes, likes: j.likes, rating: j.rating };
  dislikeCache.set(videoId, { at: Date.now(), data });
  if (dislikeCache.size > 200) dislikeCache.delete(dislikeCache.keys().next().value);
  return data;
}

// --- community posts from subscribed channels (for the subscriptions feed) --------------------
// Reads a channel's Community tab just far enough to find its latest posts. Cached per channel.
const postCache = new Map(); // channelKey -> { at, posts }
const POST_TTL = 20 * 60 * 1000;

function textOf(o) {
  if (!o) return '';
  if (typeof o === 'string') return o;
  if (o.simpleText) return o.simpleText;
  if (o.content) return o.content;
  if (Array.isArray(o.runs)) return o.runs.map((r) => r.text || '').join('');
  return '';
}
function firstThumb(o) {
  let url = '';
  (function w(n, d) {
    if (url || !n || typeof n !== 'object' || d > 8) return;
    if (Array.isArray(n.thumbnails) && n.thumbnails.length) { const t = n.thumbnails[n.thumbnails.length - 1]; if (t && t.url) { url = t.url; return; } }
    for (const k in n) w(n[k], d + 1);
  })(o, 0);
  return url;
}
function urlFromEndpoint(o) {
  let u = '';
  (function w(n, d) {
    if (u || !n || typeof n !== 'object' || d > 8) return;
    const m = n.webCommandMetadata; if (m && typeof m.url === 'string') { u = m.url; return; }
    for (const k in n) w(n[k], d + 1);
  })(o, 0);
  return u;
}
// a community-post object anywhere in the data: it carries a postId and some content. Works whether the
// post is wrapped in backstagePostRenderer / sharedPostRenderer or a newer renderer/view-model.
function isPostObj(n) {
  return n && typeof n === 'object' && typeof n.postId === 'string' && n.postId &&
    (n.contentText !== undefined || n.content !== undefined || n.contentRuns !== undefined);
}
function mapPost(p) {
  const id = p.postId || '';
  const timeRun = (p.publishedTimeText && p.publishedTimeText.runs && p.publishedTimeText.runs[0]) || null;
  const link = urlFromEndpoint(timeRun && timeRun.navigationEndpoint) || urlFromEndpoint(p.navigationEndpoint) || (id ? '/post/' + id : '');
  const att = p.backstageAttachment || p.attachment || {};
  return {
    id,
    text: textOf(p.contentText || p.content || p.contentRuns).slice(0, 600),
    time: textOf(p.publishedTimeText || p.publishedTime).trim(),
    author: textOf(p.authorText || p.author).trim(),
    avatar: firstThumb(p.authorThumbnail || p.authorPhoto),
    image: firstThumb(att.backstageImageRenderer || att.postMultiImageRenderer || att.imageRenderer || att.image || null),
    hasVideo: !!(att.videoRenderer || att.reelShelfRenderer || att.videoAttachment),
    url: link
  };
}
function findPosts(root) {
  const out = [];
  const seen = new Set();
  (function walk(n, d) {
    if (!n || typeof n !== 'object' || d > 32 || seen.has(n)) return;
    seen.add(n);
    if (isPostObj(n)) out.push(mapPost(n));
    for (const k in n) walk(n[k], d + 1);
  })(root, 0);
  // newest first (document order ≈ newest first), de-duplicated by id
  const byId = new Map();
  out.forEach((x) => { const k = x.id || (x.author + '|' + x.text.slice(0, 40)); if (k && !byId.has(k)) byId.set(k, x); });
  return [...byId.values()];
}
async function fetchChannelPosts(path, perChannel) {
  const key = String(path || '').toLowerCase();
  const hit = postCache.get(key);
  if (hit && Date.now() - hit.at < POST_TTL) return hit.posts;
  let posts = [];
  try {
    const url = 'https://www.youtube.com' + (path.charAt(0) === '/' ? '' : '/') + path.replace(/\/+$/, '') + '/community';
    const res = await fetch(url, { credentials: 'include', cache: 'no-store' });
    if (res.ok) {
      const html = await res.text();
      let jsonStr = null;
      for (const marker of ['var ytInitialData = ', 'window["ytInitialData"] = ', 'ytInitialData = ']) { jsonStr = extractJsonAfter(html, marker); if (jsonStr) break; }
      if (jsonStr) { const data = JSON.parse(jsonStr); posts = findPosts(data).slice(0, perChannel || 3).map((p) => Object.assign(p, { channelPath: path })); }
    }
  } catch (e) { /* leave posts empty for this channel */ }
  postCache.set(key, { at: Date.now(), posts });
  if (postCache.size > 400) postCache.delete(postCache.keys().next().value);
  return posts;
}
async function fetchSubsPosts(channels, perChannel) {
  const list = (channels || []).filter(Boolean).slice(0, 60);
  const all = [];
  const BATCH = 6; // keep the number of parallel requests modest
  for (let i = 0; i < list.length; i += BATCH) {
    const got = await Promise.all(list.slice(i, i + BATCH).map((p) => fetchChannelPosts(p, perChannel).catch(() => [])));
    got.forEach((arr) => { arr.forEach((p) => all.push(p)); });
  }
  return { posts: all };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'RT_SUBS_POSTS') {
    fetchSubsPosts(message.channels || [], message.perChannel || 3)
      .then(sendResponse)
      .catch((err) => sendResponse({ posts: [], error: String(err) }));
    return true;
  }
  if (message?.type === 'RT_DISLIKES') {
    fetchDislikes(String(message.videoId || ''))
      .then(sendResponse)
      .catch(() => sendResponse(null));
    return true;
  }
  if (message?.type === 'WATCH_LATER_SHELF_DEARROW') {
    fetchDearrow(message.videoIds || [])
      .then(sendResponse)
      .catch(() => sendResponse({}));
    return true;
  }
  if (message?.type === 'WATCH_LATER_SHELF_AVATARS') {
    fetchAvatars(message.urls || [])
      .then(sendResponse)
      .catch(() => sendResponse({}));
    return true;
  }
  if (message?.type === 'WATCH_LATER_SHELF_FETCH_ALL') {
    fetchWatchLater(Infinity)
      .then(sendResponse)
      .catch((err) => sendResponse({ videos: [], signedIn: true, error: String(err) }));
    return true;
  }
  if (message?.type !== 'WATCH_LATER_SHELF_FETCH') return false;
  fetchWatchLater()
    .then(sendResponse)
    .catch((err) => sendResponse({ videos: [], signedIn: true, error: String(err) }));
  return true;
});
