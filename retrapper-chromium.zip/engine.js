// ReTrapper engine: loads settings, turns them into <html data-rt="..."> tokens
// and CSS variables, injects the generated stylesheet, and schedules DOM passes.
(function () {
  'use strict';
  const RT = window.RT;
  if (!RT || RT.engineLoaded) return;
  RT.engineLoaded = true;

  const root = document.documentElement;
  let S = RT.defaults();
  let tokens = new Set();
  let ver = 0;
  const dyn = { vars: {}, tokens: new Set() }; // set by player.js / gate.js
  RT.extraTokens = () => [];
  RT.version = () => ver;
  RT.settings = () => S;
  RT.page = () => RT.pageType(location);
  RT.on = (id) => tokens.has(id);
  RT.isEmbed = () => RT.page() === 'embed';

  RT.dynSet = function (key, vars, token) {
    dyn.vars[key] = vars || null;
    if (token) dyn.tokens.add(token + '@' + key); else for (const t of [...dyn.tokens]) if (t.endsWith('@' + key)) dyn.tokens.delete(t);
    if (RT._applied) apply();
  };
  RT.save = (obj) => chrome.storage.local.set(obj);

  // ---- stylesheet -----------------------------------------------------------
  let baseStyle = null, dynStyle = null;
  function ensureStyles() {
    if (!baseStyle || !baseStyle.isConnected) {
      baseStyle = document.createElement('style');
      baseStyle.id = 'rt-style';
      baseStyle.textContent = RT.buildCss().join('\n');
      (document.head || root).appendChild(baseStyle);
    }
    if (!dynStyle || !dynStyle.isConnected) {
      dynStyle = document.createElement('style');
      dynStyle.id = 'rt-dyn-style';
      (document.head || root).appendChild(dynStyle);
    }
  }
  let lastDyn = '';
  function setDynamicCss() {
    const sels = [].concat(RT.lines(S.customHideSelectors), RT.lines(S.sidebarSelectors), RT.lines(S.headerSelectors), (RT.ruleHides || []));
    const key = sels.join('\n') + '\u0000' + (S.customCss || '');
    if (key === lastDyn) return;
    lastDyn = key;
    dynStyle.textContent = '';
    const sheet = dynStyle.sheet;
    if (sheet) {
      sels.forEach((sel) => { try { sheet.insertRule(`${sel}{display:none !important}`, sheet.cssRules.length); } catch (e) { /* invalid selector */ } });
    }
    if (S.customCss) dynStyle.appendChild(document.createTextNode(S.customCss));
  }

  // ---- tokens + variables -----------------------------------------------------
  const EMBED_OK = /^(embed|rtVideoFilter|rtGray|hidePlayerControls|minimalPlayer|playerControlsHide:|disableAmbient|rtAmbient)/;
  let lastAttr = '', lastVars = '';
  function apply() {
    RT._applied = true;
    ensureStyles();
    const extra = [].concat(RT.extraTokens() || []);
    tokens = RT.tokens(S, extra);
    const vars = {};
    const add = (t) => tokens.add(t);
    const pt = RT.page();
    if (pt !== 'other') add('rt' + pt[0].toUpperCase() + pt.slice(1));

    // Video filter (player + embeds)
    const f = [];
    if (S.vfBrightness !== 100) f.push(`brightness(${S.vfBrightness / 100})`);
    if (S.vfContrast !== 100) f.push(`contrast(${S.vfContrast / 100})`);
    if (S.vfSaturate !== 100) f.push(`saturate(${S.vfSaturate / 100})`);
    if (S.vfSepia > 0) f.push(`sepia(${S.vfSepia / 100})`);
    if (S.grayscaleVideo) f.push('grayscale(1)');
    if (f.length) { add('rtVideoFilter'); vars['--rt-video-filter'] = f.join(' '); }
    // Thumbnails
    const tf = [];
    if (S.blurThumbs) tf.push(`blur(${S.blurAmount}px)`);
    if (S.grayThumbs) tf.push('grayscale(1)');
    if (S.modifyThumbs && window.CSS && CSS.supports('filter', S.modifyThumbs)) tf.push(S.modifyThumbs);
    if (tf.length) { add('rtThumbFilter'); vars['--rt-thumb-filter'] = tf.join(' '); }
    if (S.blurThumbs) add('rtThumbReveal');
    if (S.reduceThumbs) { add('rtThumbOpacity'); vars['--rt-thumb-opacity'] = S.thumbOpacity / 100; }
    if (S.ambientIntensity !== 100) { add('rtAmbient'); vars['--rt-ambient'] = S.ambientIntensity / 100; }
    if (S.grayscaleUI) { add('rtGray'); vars['--rt-gray'] = S.grayscaleAmount / 100; }
    if (/^#[0-9a-f]{3,8}$/i.test(S.customAccent || '')) { add('rtAccent'); vars['--rt-accent'] = S.customAccent; }
    if (S.pageMaxWidth > 0) { add('rtMaxWidth'); vars['--rt-maxw'] = S.pageMaxWidth + 'px'; }
    for (const k in dyn.vars) if (dyn.vars[k]) Object.assign(vars, dyn.vars[k]);
    dyn.tokens.forEach((t) => add(t.split('@')[0]));

    if (pt === 'embed') {
      const keep = [];
      tokens.forEach((t) => { if (EMBED_OK.test(t) || t.indexOf('embed') === 0) keep.push(t); });
      tokens = new Set(keep);
      if (!S.embedPlayerSettings) { tokens.delete('rtVideoFilter'); }
      if (!S.embedVisualSettings) { tokens.delete('rtGray'); }
    }
    const attr = [...tokens].join(' ');
    if (attr !== lastAttr) { root.setAttribute('data-rt', attr); lastAttr = attr; }
    const vs = JSON.stringify(vars);
    if (vs !== lastVars) {
      for (const k of Object.keys(JSON.parse(lastVars || '{}'))) if (!(k in vars)) root.style.removeProperty(k);
      for (const k in vars) root.style.setProperty(k, vars[k]);
      lastVars = vs;
    }
    setDynamicCss();
    try { localStorage.setItem('rtCache', JSON.stringify({ attr, vars })); } catch (e) { /* ignore */ }
    try { localStorage.setItem('rt-adblock', tokens.has('blockVideoAds') ? '1' : '0'); } catch (e) { /* ignore */ }
    RT.state = { S, tokens, page: pt };
    RT.bus.dispatchEvent(new Event('apply'));
    scheduleDom();
  }
  RT.apply = apply;

  // Paint with the last known state immediately (before storage answers).
  try {
    const c = JSON.parse(localStorage.getItem('rtCache') || 'null');
    if (c && c.attr) {
      const pt = RT.page();
      const keep = c.attr.split(' ').filter((t) => !/^rt[A-Z][a-z]+$/.test(t) || /^rt(Video|Thumb|Ambient|Gray|Accent|MaxWidth|PlayerH)/.test(t));
      if (pt !== 'other') keep.push('rt' + pt[0].toUpperCase() + pt.slice(1));
      root.setAttribute('data-rt', keep.join(' '));
      for (const k in c.vars) root.style.setProperty(k, c.vars[k]);
      ensureStyles();
    }
  } catch (e) { /* ignore */ }

  // ---- DOM pass scheduling -------------------------------------------------------
  let timer = 0, observer = null;
  function scheduleDom() {
    if (timer) return;
    timer = setTimeout(() => {
      timer = 0;
      try { if (RT.runDom) RT.runDom(); } catch (e) { console.error('[ReTrapper] dom pass failed', e); }
      RT.bus.dispatchEvent(new Event('dom'));
    }, 120);
  }
  RT.scheduleDom = scheduleDom;
  function observe() {
    if (observer) return;
    observer = new MutationObserver(scheduleDom);
    observer.observe(root, { childList: true, subtree: true });
  }

  // ---- settings ----------------------------------------------------------------------
  function load() {
    chrome.storage.local.get(null, (stored) => {
      S = RT.mergeStored(stored);
      ver++;
      apply();
      observe();
    });
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    let touched = false;
    for (const k in changes) { S[k] = changes[k].newValue === undefined ? RT.defaults()[k] : changes[k].newValue; touched = true; }
    if (touched) { ver++; apply(); }
  });

  let lastHref = location.href;
  function onNav() {
    if (location.href === lastHref && RT._navSeen) return;
    RT._navSeen = true;
    lastHref = location.href;
    ver++;
    apply();
    RT.bus.dispatchEvent(new Event('navigate'));
  }
  document.addEventListener('yt-navigate-finish', onNav);
  document.addEventListener('yt-page-data-updated', scheduleDom);
  window.addEventListener('popstate', onNav);

  // ---- theme detection ---------------------------------------------------------------
  // Works out whether YouTube is currently dark or light from what is actually
  // painted (so other theme extensions are respected), then falls back to
  // YouTube's own flags, the text colour, and finally the system preference.
  const parseColor = (str) => {
    str = String(str || '').trim();
    let m = str.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);
    if (m) {
      let h = m[1];
      if (h.length === 3) h = h.replace(/./g, (c) => c + c);
      return { r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16), a: 1 };
    }
    const n = str.match(/[\d.]+/g);
    if (!n || n.length < 3 || !/^rgb/i.test(str)) return null;
    return { r: +n[0], g: +n[1], b: +n[2], a: n.length >= 4 ? parseFloat(n[3]) : 1 };
  };
  const lum = (c) => 0.2126 * c.r + 0.7152 * c.g + 0.0722 * c.b;
  RT.lum = lum;
  RT.parseColor = parseColor;
  RT.detectTheme = function () {
    const html = document.documentElement;
    const els = [document.querySelector('ytd-app'), document.body, html];
    for (const el of els) {
      if (!el) continue;
      const c = parseColor(getComputedStyle(el).backgroundColor);
      if (c && c.a > 0.5) return { theme: lum(c) < 128 ? 'dark' : 'light', bg: c, source: 'background' };
    }
    const v = parseColor(getComputedStyle(html).getPropertyValue('--yt-spec-base-background'));
    if (v) return { theme: lum(v) < 128 ? 'dark' : 'light', bg: v, source: 'variable' };
    if (html.hasAttribute('dark')) return { theme: 'dark', bg: null, source: 'attribute' };
    const t = parseColor(getComputedStyle(document.querySelector('ytd-app') || document.body || html).color);
    if (t) return { theme: lum(t) > 150 ? 'dark' : 'light', bg: null, source: 'text' };
    const dark = !!(window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
    return { theme: dark ? 'dark' : 'light', bg: null, source: 'system' };
  };
  RT.theme = null;
  let themeTimer = 0;
  const themeObs = new MutationObserver(() => queueTheme());
  function checkTheme() {
    themeTimer = 0;
    [document.body, document.querySelector('ytd-app')].forEach((el) => {
      if (el && !el.__rtThemeObs) { el.__rtThemeObs = true; themeObs.observe(el, { attributes: true, attributeFilter: ['dark', 'class', 'style', 'theme'] }); }
    });
    if (!document.body && !document.querySelector('ytd-app')) return;
    const t = RT.detectTheme();
    t.text = getComputedStyle(document.querySelector('ytd-app') || document.body || root).color;
    const prevT = RT.theme;
    RT.theme = t;
    if (prevT && prevT.theme === t.theme && prevT.text === t.text) return;
    RT.bus.dispatchEvent(new Event('theme'));
    if (!RT.isEmbed() && (!prevT || prevT.theme !== t.theme) && S.ytTheme !== t.theme) chrome.storage.local.set({ ytTheme: t.theme });
  }
  const queueTheme = () => { if (!themeTimer) themeTimer = setTimeout(checkTheme, 200); };
  new MutationObserver(queueTheme).observe(root, { attributes: true, attributeFilter: ['dark', 'class', 'style', 'theme'] });
  if (window.matchMedia) matchMedia('(prefers-color-scheme: dark)').addEventListener('change', queueTheme);
  setInterval(queueTheme, 5000);
  RT.bus.addEventListener('apply', queueTheme);
  RT.bus.addEventListener('navigate', queueTheme);
  document.addEventListener('DOMContentLoaded', queueTheme);
  window.addEventListener('load', queueTheme);

  load();
})();
