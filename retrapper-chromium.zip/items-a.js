// Items: Home page, Shorts, Video page.
(function () {
  'use strict';
  const RT = window.RT;
  const { toggle, number, select, range } = RT._h;
  const { WATCH, HOME, SUBS, CHAN, SRCH } = RT.SEL;
  const SL = 'a[href^="/shorts/"]';

  // ---- Home ----------------------------------------------------------------
  toggle('hideHomeChips', 'Hide Home categories', {
    alts: ['Hide suggestions categories', 'Hide recommendation categories'],
    css: [`${HOME} ytd-feed-filter-chip-bar-renderer`, `${HOME} #chips-wrapper`,
      `${WATCH} yt-related-chip-cloud-renderer`, `${WATCH} ytd-feed-filter-chip-bar-renderer`]
  });
  toggle('hideAllSuggestions', 'Hide all suggestions', {
    css: [`${HOME} ytd-rich-grid-renderer > #contents`, `${HOME} ytd-continuation-item-renderer`]
  });
  toggle('homeFirstRowOnly', 'Hide all suggestions except first row');
  toggle('homeExtraRows', 'Hide extra rows', { hint: 'Keeps only the number of rows set below.' });
  number('homeMaxRows', 'Rows to keep', 2, { min: 1, max: 20, showIf: 'homeExtraRows' });
  toggle('hideShortsHome', 'Hide Shorts row', {
    alts: ['Remove Shorts from Home'],
    css: [`${HOME} ytd-rich-section-renderer:has(ytd-rich-shelf-renderer[is-shorts])`,
      `${HOME} ytd-rich-section-renderer:has(ytd-reel-shelf-renderer)`, `${HOME} ytd-reel-shelf-renderer`,
      `${HOME} ytd-rich-item-renderer:has(${SL})`, `${HOME} ytd-rich-item-renderer:has(ytm-shorts-lockup-view-model)`,
      `${HOME} ytd-rich-item-renderer:has(ytm-shorts-lockup-view-model-v2)`]
  });
  toggle('hideTrendingRow', 'Hide Trending row');
  toggle('hideOtherRows', 'Hide other recommendation rows', {
    alts: ['Hide recommendation rows'], css: [`${HOME} ytd-rich-section-renderer`]
  });
  toggle('noInfiniteScroll', 'Disable infinite scrolling', { def: false });
  toggle('hideWatched', 'Hide watched videos', { def: false, hint: 'On Home, channels and recommendations. Subscriptions and Search have their own options. Not on History or playlists.' });
  range('watchedMinPct', 'Hide when watched at least', 1, 100, 1, 1, { unit: '%', showIf: 'hideWatched' });
  toggle('hideFeaturedHome', 'Hide YouTube featured and event promotions', {
    hint: 'Hides sponsored-looking sections on Home such as "YouTube featured", "Your home for ..." event pages and Sunday Ticket banners.'
  });
  toggle('hideHomeAds', 'Hide ads in first recommendation slot', {
    css: [`${HOME} ytd-rich-item-renderer:has(ytd-ad-slot-renderer)`, `${HOME} ytd-ad-slot-renderer`,
      `${HOME} #masthead-ad`, `${HOME} ytd-display-ad-renderer`, `${HOME} ytd-in-feed-ad-layout-renderer`,
      `${HOME} ytd-banner-promo-renderer`, `${HOME} ytd-primetime-promo-renderer`,
      `${HOME} ytd-video-masthead-ad-v3-renderer`, `${HOME} ytd-brand-video-shelf-renderer`,
      `${HOME} ytd-brand-video-singleton-renderer`, `${HOME} ytd-rich-section-renderer:has(ytd-statement-banner-renderer)`]
  });
  select('homeRedirect', 'Redirect Home page',
    [['off', 'Off'], ['subscriptions', 'Subscriptions'], ['watchlater', 'Watch Later'], ['library', 'Library'], ['custom', 'Custom page']],
    'off', { alts: ['Automatic Home redirection'] });
  RT._h.text('homeRedirectUrl', 'Custom page (e.g. /feed/history)', { showIf: ['homeRedirect', 'custom'], placeholder: '/feed/history' });
  toggle('hideExplore', 'Hide Explore', {
    alts: ['Hide Explore section'],
    css: [`ytd-guide-section-renderer:has(a[href="/feed/trending"])`, `ytd-guide-entry-renderer:has(a[href="/feed/explore"])`,
      `ytd-mini-guide-entry-renderer:has(a[href="/feed/explore"])`]
  });
  toggle('hideTrending', 'Hide trending content', {
    alts: ['Hide Trending results', 'Hide Trending'],
    css: [`ytd-guide-entry-renderer:has(a[href^="/feed/trending"])`, `ytd-mini-guide-entry-renderer:has(a[href^="/feed/trending"])`]
  });
  toggle('hideAllRecs', 'Hide suggested / recommended videos', {
    alts: ['Hide recommended videos', 'Hide suggested videos', 'Hide recommendations'],
    implies: ['hideAllSuggestions', 'hideRelated', 'hideEndscreenSuggestions']
  });
  toggle('hidePersonalized', 'Hide personalized recommendations', {
    alts: ['Hide personalized results'],
    implies: ['hideAllSuggestions', 'hideRelated', 'hideForYou', 'hideHomeChips', 'hideSearchRecs']
  });
  toggle('hideForYou', 'Hide "For You" content', { alts: ['Hide "For You" results'] });

  // ---- Shorts ----------------------------------------------------------------
  // Everything that can hold a Short, on every page. Hides the card, the shelf and the Shorts tabs and chips.
  const SHORT_CARDS = ['ytd-rich-item-renderer', 'ytd-video-renderer', 'ytd-compact-video-renderer', 'ytd-grid-video-renderer', 'yt-lockup-view-model',
    'ytd-playlist-video-renderer', 'ytd-rich-section-renderer', 'grid-shelf-view-model', 'ytd-compact-radio-renderer', 'ytd-playlist-panel-video-renderer'];
  const SHORT_HAS = ['a[href^="/shorts/"]', 'a[href*="youtube.com/shorts/"]', 'ytd-thumbnail-overlay-time-status-renderer[overlay-style="SHORTS"]',
    'ytm-shorts-lockup-view-model', 'ytm-shorts-lockup-view-model-v2', 'ytd-reel-item-renderer'];
  const SHORT_ALL = ['ytd-reel-shelf-renderer', 'ytd-rich-shelf-renderer[is-shorts]', 'ytm-shorts-lockup-view-model', 'ytm-shorts-lockup-view-model-v2',
    'ytd-reel-item-renderer', 'ytd-shorts', 'ytd-reel-video-renderer',
    'ytd-rich-section-renderer:has(ytd-rich-shelf-renderer[is-shorts])', 'ytd-rich-section-renderer:has(ytd-reel-shelf-renderer)',
    'ytd-item-section-renderer:has(> #contents > ytd-reel-shelf-renderer)', 'ytd-shelf-renderer:has(> #dismissible > #contents ytm-shorts-lockup-view-model)',
    'ytd-shelf-renderer:has(ytd-reel-shelf-renderer)', 'ytd-shelf-renderer:has(ytm-shorts-lockup-view-model)', 'ytd-shelf-renderer:has(ytm-shorts-lockup-view-model-v2)',
    'ytd-guide-entry-renderer:has(a[href^="/shorts"])', 'ytd-mini-guide-entry-renderer:has(a[href^="/shorts"])', 'ytd-mini-guide-entry-renderer[aria-label="Shorts"]',
    'ytd-guide-entry-renderer:has(a[title="Shorts"])', 'yt-tab-shape[tab-title="Shorts"]', 'tp-yt-paper-tab:has(a[href$="/shorts"])',
    'yt-chip-cloud-chip-renderer:has(a[href*="/shorts"])', 'yt-chip-cloud-chip-renderer[chip-style*="SHORTS"]', 'ytd-feed-filter-chip-bar-renderer yt-chip-cloud-chip-renderer[aria-label="Shorts"]',
    'yt-chip-cloud-chip-renderer[title="Shorts"]', 'ytd-notification-renderer:has(a[href*="/shorts/"])']
    .concat(SHORT_CARDS.map((c) => c + ':has(' + SHORT_HAS.join(', ') + ')'));
  RT.SHORT_SEL = { cards: SHORT_CARDS, has: SHORT_HAS };
  toggle('hideShortsAll', 'Hide Shorts', {
    hint: 'Aggressive: removes Shorts everywhere (all feeds, search, channels, history, playlists, the sidebar and tabs), and opens any Shorts link in the normal player.',
    css: SHORT_ALL,
    implies: ['hideShortsHome', 'hideShortsSearch', 'hideShortsSubs', 'hideShortsRecs', 'hideShortsSidebar',
      'hideShortsSections', 'hideShortsSuggestions', 'hideShortsRelated']
  });
  toggle('hideShortsSearch', 'Remove Shorts from Search', {
    css: [`${SRCH} ytd-reel-shelf-renderer`, `${SRCH} ytd-video-renderer:has(${SL})`, `${SRCH} grid-shelf-view-model:has(${SL})`,
      `${SRCH} ytd-shelf-renderer:has(ytm-shorts-lockup-view-model)`, `${SRCH} yt-lockup-view-model:has(${SL})`,
      `${SRCH} ytd-shelf-renderer:has(a[href^="/shorts/"])`, `${SRCH} ytd-video-renderer:has(a[href^="/shorts/"])`,
      `${SRCH} ytd-item-section-renderer > #contents > :is(grid-shelf-view-model,ytd-shelf-renderer,ytd-reel-shelf-renderer,ytd-horizontal-card-list-renderer):has(a[href^="/shorts/"])`,
      `${SRCH} ytm-shorts-lockup-view-model-v2`, `${SRCH} ytm-shorts-lockup-view-model`, `${SRCH} yt-lockup-view-model:has(a[href*="/shorts/"])`,
      `${SRCH} ytd-rich-item-renderer:has(a[href^="/shorts/"])`]
  });
  toggle('hideShortsSubs', 'Remove Shorts from Subscriptions', {
    css: [`${SUBS} ytd-rich-item-renderer:has(${SL})`, `${SUBS} ytd-rich-item-renderer:has(ytm-shorts-lockup-view-model)`,
      `${SUBS} ytd-reel-shelf-renderer`, `${SUBS} ytd-rich-section-renderer:has(ytd-rich-shelf-renderer[is-shorts])`,
      `${SUBS} ytd-grid-video-renderer:has(${SL})`, `${SUBS} ytd-item-section-renderer:has(ytd-reel-shelf-renderer)`]
  });
  toggle('hideShortsRecs', 'Remove Shorts from recommendations', {
    css: [`${WATCH} ytd-compact-video-renderer:has(${SL})`, `${WATCH} yt-lockup-view-model:has(${SL})`,
      `${WATCH} ytd-reel-shelf-renderer`, `${WATCH} ytd-item-section-renderer:has(ytd-reel-shelf-renderer)`,
      `${HOME} ytd-rich-item-renderer:has(${SL})`]
  });
  toggle('hideShortsSidebar', 'Remove Shorts from sidebar', {
    alts: ['Hide Shorts navigation button', 'Hide Shorts button'],
    css: [`ytd-guide-entry-renderer:has(a[href^="/shorts"])`, `ytd-mini-guide-entry-renderer:has(a[href^="/shorts"])`,
      `ytd-mini-guide-entry-renderer[aria-label="Shorts"]`, `ytd-guide-entry-renderer:has(a[title="Shorts"])`]
  });
  toggle('redirectShorts', 'Redirect Shorts to normal video player', {});
  toggle('shortsAsVideos', 'Treat Shorts as regular videos', { hint: 'Redirects and rewrites Shorts links to the normal player.' });
  toggle('hideShortsSections', 'Hide Shorts sections', {
    css: ['ytd-reel-shelf-renderer', 'ytd-rich-shelf-renderer[is-shorts]', 'ytd-rich-section-renderer:has(ytd-rich-shelf-renderer[is-shorts])',
      'ytd-shelf-renderer:has(ytm-shorts-lockup-view-model)', 'ytd-item-section-renderer:has(> #contents > ytd-reel-shelf-renderer)']
  });
  toggle('hideShortsSuggestions', 'Hide Shorts suggestions', {
    alts: ['Hide Shorts in sidebar suggestions'],
    css: [`${WATCH} ytd-watch-next-secondary-results-renderer ytd-reel-shelf-renderer`, `${WATCH} #related ytd-reel-shelf-renderer`,
      `${WATCH} ytd-watch-next-secondary-results-renderer yt-lockup-view-model:has(${SL})`,
      `${WATCH} ytd-watch-next-secondary-results-renderer ytd-compact-video-renderer:has(${SL})`]
  });
  toggle('hideShortsRelated', 'Hide Shorts-related content', {
    css: [`${CHAN} yt-tab-shape[tab-title="Shorts"]`, 'yt-chip-cloud-chip-renderer:has(a[href*="/shorts"])',
      `ytd-feed-filter-chip-bar-renderer yt-chip-cloud-chip-renderer[chip-style*="SHORTS"]`]
  });

  // ---- Video page --------------------------------------------------------------
  // Side by side, the sidebar is only made invisible (it keeps its width) so YouTube does not re-center the
  // player and the title area, which would move them away from where DeArrow and other tools expect them.
  // When YouTube stacks it under the player it is removed outright so no blank gap is left.
  toggle('hideWatchSidebar', 'Hide sidebar', {
    hint: 'The video stays where it is instead of moving to the center.',
    rules: [[`${WATCH}[is-two-columns_] #secondary`, 'visibility:hidden'], [`${WATCH}:not([is-two-columns_]) #secondary`, 'display:none']]
  });
  toggle('hideRelated', 'Hide related videos', {
    alts: ['Hide suggested videos', 'Hide video recommendations'],
    css: [`${WATCH} #related`, `${WATCH} ytd-watch-next-secondary-results-renderer`]
  });
  toggle('hideEndscreenSuggestions', 'Hide end-screen suggestions', {
    css: ['.html5-video-player .ytp-endscreen-content', '.ytp-endscreen-previous', '.ytp-endscreen-next', '.ytp-videowall-still', '.html5-endscreen', '.ytp-suggestion-set']
  });
  toggle('hideEndscreenInfo', 'Hide end-screen information', {
    css: ['.ytp-ce-element', '.ytp-ce-covering-overlay', '.ytp-cards-teaser', '.ytp-ce-element-show']
  });
  toggle('hideVideoEndScreen', 'Hide video end screen', { implies: ['hideEndscreenSuggestions', 'hideEndscreenInfo'] });
  toggle('hideLiveChat', 'Hide live chat', {
    css: [`${WATCH} #chat`, `${WATCH} #chat-container`, `${WATCH} ytd-live-chat-frame`]
  });
  toggle('removeLiveChatSection', 'Remove live-chat section', {
    implies: ['hideLiveChat'],
    css: [`${WATCH} #show-hide-button`, 'ytd-live-chat-frame #show-hide-button',
      'ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-live-chat"]']
  });
  toggle('removeLiveChatUI', 'Remove live-chat UI', {
    implies: ['removeLiveChatSection'], css: [`${WATCH} #live-chat-iframe`, `${WATCH} #chat-messages`]
  });
  toggle('hideComments', 'Hide comments', {
    alts: ['Hide comment section'],
    css: [`${WATCH} ytd-comments#comments`, `${WATCH} #comments`, 'ytd-comments',
      'ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-comments-section"]',
      'ytd-comments-entry-point-header-renderer', '#comments-entry-point']
  });
  toggle('hideCommentCount', 'Hide comment count', {
    alts: ['Hide comments count'],
    css: ['ytd-comments-header-renderer #count', 'ytd-comments-header-renderer h2 #count', '#comments #count',
      'ytd-comments-entry-point-header-renderer #comment-count', 'ytd-comments-header-renderer .count-text']
  });
  toggle('hideReplies', 'Hide replies', {
    css: ['ytd-comment-replies-renderer', 'ytd-comment-thread-renderer #replies']
  });
  toggle('hideRepliesCount', 'Hide replies count', {
    rules: [['ytd-comment-replies-renderer #more-replies #text', 'font-size:0'],
      ['ytd-comment-replies-renderer #more-replies #text::after', 'content:"Replies";font-size:14px']]
  });
  toggle('hideDescription', 'Hide video description', {
    css: [`${WATCH} ytd-watch-metadata #description`, `${WATCH} #description-inner`, `${WATCH} ytd-structured-description-content-renderer`]
  });
  toggle('hideTitle', 'Hide video title', {
    css: [`${WATCH} ytd-watch-metadata #title`, `${WATCH} h1.ytd-watch-metadata`, `${WATCH} #above-the-fold #title`]
  });
  toggle('hideChannelInfo', 'Hide channel information', {
    css: [`${WATCH} ytd-watch-metadata #owner`, `${WATCH} ytd-video-owner-renderer`, `${WATCH} ytd-video-secondary-info-renderer #owner`]
  });
  toggle('hideOwnerInfo', 'Hide channel owner information', {
    css: [`${WATCH} #owner #upload-info`, `${WATCH} #owner-sub-count`, `${WATCH} ytd-video-owner-renderer #upload-info`]
  });
  toggle('hideMenuButtons', 'Hide menu buttons', {
    css: [`${WATCH} ytd-watch-metadata #actions`, `${WATCH} #top-level-buttons-computed`, `${WATCH} ytd-menu-renderer.ytd-watch-metadata`]
  });
  toggle('hideLike', 'Hide Like button', {
    css: [`${WATCH} like-button-view-model`, `${WATCH} ytd-segmented-like-dislike-button-renderer #segmented-like-button`]
  });
  toggle('hideDislike', 'Hide Dislike button', {
    css: [`${WATCH} dislike-button-view-model`, `${WATCH} #segmented-dislike-button`]
  });
  toggle('showDislikeCount', 'Show dislike count', {
    hint: 'Adds the estimated dislike number next to the dislike button, from the Return YouTube Dislike community API. The number is an estimate.'
  });
  toggle('hideAiButtons', 'Hide AI buttons and summaries', {
    hint: 'Removes the Ask buttons (search bar, video pages) and AI summaries in search results.',
    css: [
      'ytd-search [class*="ai-summary" i]', 'ytd-search [class*="AiSummary" i]', 'ytd-search [class*="ai-overview" i]', 'ytd-search [class*="AiOverview" i]',
      'ytd-search [class*="ytAi" i]', 'ytd-search ytd-expandable-metadata-renderer', 'ytd-search video-summary-content-view-model', 'ytd-search ai-summary-view-model', 'ytd-search [class*="GenAi" i]',
      'ytd-search ytd-video-renderer [class*="summary" i]:not(.metadata-snippet-container):not(#description-text)',
      'ytd-masthead #center button[aria-label^="Ask" i]', 'ytd-masthead #center yt-button-view-model:has(button[aria-label^="Ask" i])',
      'ytd-masthead #center button-view-model:has(button[aria-label^="Ask" i])', 'ytd-masthead #center ytd-button-renderer:has([aria-label^="Ask" i])',
      'ytd-masthead yt-button-view-model:has(button[aria-label^="Ask" i])', 'ytd-masthead button-view-model:has(button[aria-label^="Ask" i])',
      'ytd-masthead #end yt-button-view-model:has(button[aria-label^="Ask" i])',
      `${WATCH} yt-button-view-model:has(button[aria-label^="Ask" i])`, `${WATCH} button-view-model:has(button[aria-label^="Ask" i])`,
      `${WATCH} ytd-button-renderer:has([aria-label^="Ask" i])`, `${WATCH} ytd-watch-metadata #actions button[aria-label^="Ask" i]`,
      `${WATCH} #flexible-item-buttons yt-button-view-model:has(button[aria-label*="Ask" i])`,
      'ytd-masthead [aria-label="Ask YouTube" i]', `${WATCH} [aria-label="Ask" i]`
    ]
  });
  toggle('hideShare', 'Hide Share button', { css: RT.btn('Share') });
  toggle('hideSave', 'Hide Save button', { css: RT.btn('Save') });
  toggle('hideClip', 'Hide Clip button', { css: RT.btn('Clip') });
  toggle('hideDownload', 'Hide Download button', { css: RT.btn('Download').concat([`${WATCH} ytd-download-button-renderer`]) });
  toggle('hideOtherButtons', 'Hide other video buttons', {
    css: RT.btn('Thanks', 'Ask', 'Remix', 'Shop').concat([`${WATCH} #sponsor-button`, `${WATCH} yt-button-view-model:has(button[aria-label^="Join" i])`])
  });
  toggle('hideVideoMetadata', 'Hide video metadata', {
    css: [`${WATCH} #info-container`, `${WATCH} ytd-watch-info-text`, `${WATCH} #info-strings`]
  });
  toggle('hideLikes', 'Hide likes', {
    alts: ['Hide like counts'],
    css: ['ytd-comment-view-model #vote-count-middle', 'ytd-comment-engagement-bar #vote-count-middle', 'ytd-comment-renderer #vote-count-middle'],
    rules: [[`${WATCH} like-button-view-model .yt-spec-button-shape-next__button-text-content`, 'display:none']]
  });
  toggle('hideViews', 'Hide views on the video page', {
    alts: ['Hide view counts', 'Hide views'],
    css: [`${WATCH} ytd-watch-info-text #view-count`, `${WATCH} ytd-watch-info-text yt-animated-rolling-number`, `${WATCH} ytd-video-view-count-renderer`, `${WATCH} #info-container span.view-count`]
  });
  toggle('hideSubscribers', 'Hide subscriber count', {
    alts: ['Hide subscribers counter'],
    css: [`${WATCH} #owner-sub-count`, 'ytd-video-owner-renderer #owner-sub-count', 'ytd-c4-tabbed-header-renderer #subscriber-count',
      '#channel-header #subscriber-count', 'ytd-channel-renderer #subscribers']
  });
  toggle('hidePubDate', 'Hide publication date', {});
  toggle('hideTimeSince', 'Hide time since publication', { alts: ['Hide time-since-publication'] });
  toggle('hideAds', 'Hide ads', {
    implies: ['hideSidebarAds', 'hideBannerAds', 'hideAdSlots', 'hideVideoAds']
  });
  toggle('hideSidebarAds', 'Hide sidebar ads', {
    css: [`${WATCH} #player-ads`, `${WATCH} ytd-ad-slot-renderer`, `${WATCH} #related ytd-ad-slot-renderer`,
      `${WATCH} ytd-companion-slot-renderer`, `${WATCH} ytd-action-companion-ad-renderer`,
      `${WATCH} ytd-promoted-sparkles-web-renderer`, `${WATCH} ytd-display-ad-renderer`,
      `${WATCH} ytd-in-feed-ad-layout-renderer`, 'ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-ads"]']
  });
  toggle('hideVideoOverlays', 'Hide video overlays', {
    css: ['.ytp-ce-element', '.ytp-cards-teaser', '.ytp-cards-button', '.iv-branding', '.annotation', '.video-annotations',
      '.ytp-paid-content-overlay', '.ytp-suggested-action', '.ytp-pause-overlay', '.ytp-pause-overlay-container', '.ytp-ad-overlay-container']
  });
  toggle('lowercaseTitles', 'Lowercase video titles', {
    rules: [['#video-title', 'text-transform:lowercase'], ['a#video-title-link', 'text-transform:lowercase'],
      [`${WATCH} h1.ytd-watch-metadata`, 'text-transform:lowercase'], ['.yt-lockup-metadata-view-model-wiz__title', 'text-transform:lowercase'],
      ['.ytLockupMetadataViewModelTitle', 'text-transform:lowercase'], ['ytd-compact-video-renderer h3', 'text-transform:lowercase']]
  });
})();
