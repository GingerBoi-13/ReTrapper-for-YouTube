// Popup sections (the dropdown list). Rows are item ids, {header:'text'}, or {hub:[[label, sectionId], ...]}.
(function () {
  'use strict';
  const RT = window.RT;
  const S = RT._h.section;

  S('home', 'Home page', ['hideAllSuggestions', 'hideShortsHome', 'hideWatched', 'watchedMinPct', 'hideHomeChips', 'gridColumns', 'noInfiniteScroll', 'hidePlayables', 'fullTitles', 'gridHideAvatars', { header: 'Rows and recommendations' }, 'homeFirstRowOnly', 'homeExtraRows', 'homeMaxRows', 'hideOtherRows', 'hideTrendingRow', 'hideTrending', 'hideExplore', 'hideAllRecs', 'hidePersonalized', 'hideForYou', 'hideFeaturedHome', 'hideHomeAds', 'hideHomePosts', { header: 'Video grid look' }, 'gridSmallFont', 'fullChannelName', { header: 'Opening page' }, 'homeRedirect', 'homeRedirectUrl']);
  S('shorts', 'Shorts', ['hideShortsAll', 'hideShortsHome', 'hideShortsSubs', 'hideShortsSearch', 'hideShortsRecs', 'redirectShorts', { header: 'Opening Shorts' }, 'shortsAsVideos', { header: 'Other places Shorts appear' }, 'hideShortsSidebar', 'hideShortsSections', 'hideShortsSuggestions', 'hideShortsRelated', { header: 'Watching Shorts' }, 'shortsAutoScroll', 'shortsNoLoop']);
  S('video', 'Video page', ['disableAutoplay', 'defaultSpeed', 'perChannelSpeed', 'defaultQuality', 'neverCaptions', 'autoTheater', 'volumeBoost', 'hideComments',
    'hideRelated', 'hideWatchSidebar', 'hideEndscreenSuggestions', 'hideLiveChat', 'hideAiButtons', 'hideDescription',
    'autoExpandDescription', 'hideAds', 'commentSearch', 'commentSort', 'hideCommentCount', 'hideReplies', 'hideRepliesCount', 'autoExpandComments', 'commentFilters', 'commentKeywords', 'blockCommentAuthors', 'commentRegex', 'hideMenuButtons', 'hideLikeDislike', 'hideShare', 'hideActionButtons', 'hideOtherPlayerButtons', 'customVisibleButtons', 'hideLike', 'hideDislike', 'hideSave', 'hideDownload', 'hideClip', 'hideOtherButtons', { header: 'Related videos and sidebar' }, 'sidebarChannelLinks', 'commentsInSidebar', 'pinPlayer',
     { header: 'Player size and mode' }, 'fullWindowPlayer',
    'fullSizePlayer', 'expandTheatre', 'resizablePlayer', 'autoFullscreen', 'minimalPlayer', { header: 'Player controls and progress bar' },
    'hidePlayerControls', 'playerControlsHide', 'screenshotButton', 'remainingTime', 'hideControlsOnPause', 'alwaysProgress', 'nyanBar',
    { header: 'Sound' }, 'monoAudio', 'forceOriginalAudio', 'wheelVolume', 'wheelSpeed', 'wheelSeek', { header: 'Ambient lighting' },
    'disableAmbient', 'ambientIntensity', { header: 'Looping and playlists' }, 'intelligentLooping', 'loopMaxMinutes', 'loopVideos',
    'playlistNavigation', 'noPlaylistAutoplay', { header: 'Pausing and prompts' }, 'disableMiniplayer', 'pauseOthers', 'noPausedPrompt', 'noNumberKeys', 'autoPip',
    { header: 'Promotions and ads' }, 'autoSkipPromos', 'hideVideoPromos', 'hidePlayerAds', 'hideSidebarAds',
    { header: 'End screen and overlays' }, 'hideEndscreenInfo', 'hideVideoEndScreen', 'hideVideoOverlays', 
    { header: 'Title and channel' }, 'hideTitle', 'hideChannelInfo', 'hideOwnerInfo', 'lowercaseTitles', { header: 'Numbers and dates' },
    'hideVideoMetadata', 'hideViews', 'hideLikes', 'hideSubscribers', 'hidePubDate', 'hideTimeSince', { header: 'Look and feel' },
    'redSubscribe', 'videoFocus', { header: 'Video filters' }, 'vfBrightness', 'vfContrast', 'vfSaturate', 'vfSepia', 'grayscaleVideo', { header: 'Per channel' }, 'autoExpandChannels']);
  S('cards', 'Video Card', [{ header: 'Numbers and dates' }, 'hideCardViews', 'hideTimeSince', 'hidePubDate', 'showFullDates', 'hideBadges',
    { header: 'Title and channel' }, 'fullTitles', 'fullChannelName', 'lowercaseTitles', 'gridHideAvatars', 'gridSmallFont',
    { header: 'Thumbnail' }, 'thumbsHideAll', 'blurThumbs', 'blurAmount', 'grayThumbs', 'reduceThumbs', 'thumbOpacity', 'modifyThumbs', 'cardHideDuration',
    { header: 'Whole card' }, 'blurCards']);
  S('thumbnails', 'Thumbnails', ['thumbsHideAll', 'blurThumbs', 'blurAmount', 'grayThumbs', 'reduceThumbs', 'thumbOpacity', 'modifyThumbs']);
  S('search', 'Search', ['hideShortsSearch', 'hideSearchAds', 'searchHideWatched', 'hidePlayables', 'hideIrrelevantSearch', 'hideSearchChips', 'hideSearchRecs', 'hidePlaylistsSearch', 'searchLayout', 'searchGrid', 'searchChannelRow', { header: 'Remove from results' }, 'hidePromotedVideos', 'hidePromotedSites', 'hideProducts', 'hidePeopleAlso', 'hideForYou', 'hideTrending', 'hidePersonalized', 'hideSearchDescriptions', 'hideSearchChannelDesc', { header: 'Search box' }, 'hideSearchAutocomplete', 'inPageFilter', 'searchNewTab', { header: 'Layout and results' }, 'searchThumbs', 'searchHide']);
  S('subs', 'Subscriptions', ['hideShortsSubs', 'subsHideWatched', 'subsWatchedMinPct', 'hideLiveStreams', 'hidePremieres', 'subsColumns', { header: 'More filters' },
    'hideMembersOnly', 'subsKeywords', 'hideLatest', { header: 'Page clutter' }, 'hideSubsSections', 'hideSubsRecSections', 'subsNavHide']);
  S('channels', 'Channel pages', ['channelNoAutoplay', 'channelSearch', 'channelSearchGrid', 'channelDefaultTab', 'hideChannelSections', 'hideChannelRecs', 'customChannelColumns',
    'channelSearchColumns', { header: 'Channel search options' }, 'channelSearchDeep', 'channelSearchFuzzy', { header: 'Channel page layout' },
    'channelColumns', 'hideChannelHeaderInfo', 'hideChannelBanner', 'hideChannelDistractions', 'channelNavHide', { header: 'Filtering' },
    'channelKeywords']);
  S('sidebar', 'Left navigation / sidebar', ['hideSidebarAll', 'hideShortsSidebar', 'hideNavSubs', 'hideNavHome', 'hideExplore', 'hideMoreFromYT', 'sidebarAutoCollapse', { header: 'Buttons' }, 'hidePlayables', 'hideNavLibrary', 'hideExploreButton', 'hideHelperButtons', { header: 'Sections' }, 'hideLibrarySection', 'hideSubsSection', 'hideGuideFooter', { header: 'Advanced (type names or selectors)' }, 'navSectionNames', 'navButtonNames', 'sidebarSelectors']);
  S('header', 'Top header', ['hideBell', 'hideCreate', 'hideVoice', 'hideLogo', 'hideSearchBar', { header: 'Whole header' }, 'hideHeader', 'headerAutoHide', { header: 'Small changes' }, 'hideSearchBtn', 'disableLogoLink', 'logoToSubs', 'hideHeaderControls', 'hideHeaderNav', { header: 'Advanced' }, 'headerSelectors']);
  S('recs', 'Recommendations', ['hideAllRecs', 'hideRelated', 'hideHomeChips', 'hideTrending', { header: 'More to hide' }, 'hideOtherRows', 'hideForYou', 'hidePersonalized',
    'hideExplore', 'hideSuggestedContent', { header: 'Filter by words and channels' }, 'recKeywords', 'recTopics', 'recBlockedChannels']);
  S('filters', 'Content filtering', ['filtersEnabled', 'blockChannels', 'blockKeywords', 'hideLiveStreams', { header: 'Other block lists' }, 'blockVideos', 'filterChannelIds',
    'filterChannelKeywords', 'filterVideoKeywords', 'blockTopics', 'muteTopics', 'filterRegex', { header: 'Where filters apply' }, 'matchVideos',
    'matchChannels', 'matchComments', 'matchTopics', 'filterFeeds', 'filterRecsOn', { header: 'Video type and length' }, 'hidePremieres',
    'hideMembersOnly', 'hideMixes', 'minDurationMin', 'maxDurationMin', { header: 'Comments' }, 'blockCommentAuthors', 'commentKeywords',
    'commentRegex', { header: 'Parental control' }, 'parentalFilter', 'parentalWords']);
  S('ads', 'Ads & promotions', ['hideVideoAds', 'hideSidebarAds', 'hideBannerAds', 'hideAdSlots', { header: 'Promotions' }, 'autoSkipPromos', 'removePromoUI',
    { header: 'Promoted content' }, 'hidePromotedVideos', 'hidePromotedSites', 'hideProducts']);
  S('livechat', 'Live chat', ['hideLiveChat', 'noAutoLiveChat', 'liveChatDefault', 'removeLiveChatSection', 'removeLiveChatUI']);
  S('metrics', 'Metrics', ['hideViews', 'hideCardViews', 'hideLikes', 'showFullDates', 'hideSubscribers', { header: 'Dates' }, 'hidePubDate', 'hideTimeSince', { header: 'Comments' },
    'hideCommentCount', 'hideRepliesCount', { header: 'Other' }, 'hideOtherMetrics', 'hideBadges']);
  S('interface', 'Interface / visual customization', ['customTheme', 'cinemaMode', 'minimalInterface', { header: 'Look' }, 'customAccent', 'grayscaleUI', 'grayscaleAmount', 'blurCards', 'legacyLayout', 'legacyListViews', { header: 'Clutter' }, 'minimalLayout', 'removeClutter', 'hideVisualElements', { header: 'Video area' }, 'autoTheater', 'expandTheatre', 'disableAmbient', { header: 'Compact and extras' }, 'compactSidebar', 'compactHeader', 'backToTop', 'animations', { header: 'Page width' }, 'pageMaxWidth', { header: 'Advanced (CSS)' }, 'customHideSelectors', 'customCss']);
  S('playback', 'Playback', ['disableAutoplay', 'defaultSpeed', 'perChannelSpeed', 'defaultQuality', 'autoTheater', { header: 'Screen' }, 'autoFullscreen', { header: 'Sound and captions' }, 'neverCaptions', 'autoCaptions', 'defaultVolumeOn', 'defaultVolume', 'volumeBoost', { header: 'Looping' }, 'intelligentLooping', 'loopMaxMinutes', 'loopVideos', { header: 'Playlists' }, 'playlistControls', 'playlistNavigation', { header: 'Skipping' }, 'autoSkipPromos']);
  S('automation', 'Automation', ['disableAutoplay', 'autoSkipPromos', 'homeRedirect', 'homeRedirectUrl', { header: 'Player' }, 'autoFullscreen', 'autoTheater',
    { header: 'Focus and time' }, 'openingDelay', 'autoFocusMode', 'focusSchedule', 'autoDistractionBlock', 'autoDistractAfterMin',
    { header: 'Advanced' }, 'customRules']);
  S('focus', 'Focus / productivity', ['zenMode', 'minimalistMode', 'dailyLimitMin', 'sessionLimitMin', 'timeBadge', { header: 'Focus and blocking' }, 'focusMode',
    'distractionBlocking', 'wTimerFocus', 'wTimerDistract', { header: 'Reminders and delays' }, 'timeReminderMin', 'accessIntent',
    'openingDelay']);
  S('presets', 'Presets', ['wPresets', 'presetAuto', 'presetSchedule']);
  S('shortcuts', 'Keyboard shortcuts', ['hotkeysOn', 'hk_theater', 'hk_focus', 'hk_zen', 'hk_distraction', 'hk_nextPreset', 'customHotkeys']);
  S('transcript', 'Transcript', ['trEnhanced', 'trNavigation', 'trTimestamps', 'trExpand', 'trImproved', 'trAutoGenerated', 'aiLang']);
  // Settings pages (reached from the gear icon, not the section dropdown).
  S('password', 'Password', ['wPassword']);
  S('backup', 'Backup and restore', []);
  S('report', 'Bug report', []);
  S('pageorder', 'Page order', []);
  S('access', 'Access controls', ['wTimerBlock', 'wTimerFocus', 'sessionLimitMin', 'openingDelay', 'accessIntent', 'focusRestrictions']);
  ['password', 'backup', 'access', 'report', 'pageorder'].forEach((id) => { RT.SECTIONS.find((s) => s.id === id).settings = true; });
  S('notifications', 'Notifications', ['hideBell', 'removeNotifications', 'hideNotificationUI', 'hideNotificationRelated']);
  S('pages', 'Page-specific controls', [{ hub: [['Home customization', 'home'], ['Search customization', 'search'], ['Subscription customization', 'subs'],
    ['Video-page customization', 'video'], ['Shorts customization', 'shorts'], ['Channel-page customization', 'channels'], ['Sidebar customization', 'sidebar'],
    ['Header customization', 'header'], ['Embedded-player customization', 'embed']] }]);
  S('embed', 'Embedded YouTube', ['embedPlayerSettings', 'embedVisualSettings', 'embedHideDistractions', 'embedCustom']);
  S('watchlater', 'Watch Later shelf', []);
  RT.SECTIONS.find((s) => s.id === 'watchlater').hiddenFromMenu = true;
  // Default dropdown order: most used first, least used last.
  RT.DEFAULT_ORDER = ['home', 'video', 'shorts', 'subs', 'search', 'channels', 'cards', 'thumbnails', 'sidebar', 'header', 'ads', 'filters', 'recs', 'interface', 'playback', 'focus', 'automation', 'presets', 'metrics', 'livechat', 'notifications', 'shortcuts', 'transcript', 'embed', 'pages'];
  // The pages behind the gear icon, in their own (sortable) order.
  RT.SETTINGS_DEFAULT_ORDER = ['password', 'backup', 'access', 'pageorder', 'report'];
  RT.orderedSettingsIds = function (saved) {
    const ids = RT.SECTIONS.filter((s) => s.settings && !s.hiddenFromMenu).map((s) => s.id);
    const out = [];
    (Array.isArray(saved) ? saved : []).concat(RT.SETTINGS_DEFAULT_ORDER).forEach((id) => { if (ids.indexOf(id) >= 0 && out.indexOf(id) < 0) out.push(id); });
    ids.forEach((id) => { if (out.indexOf(id) < 0) out.push(id); });
    return out;
  };
  RT.orderedIds = function (saved) {
    const ids = RT.SECTIONS.filter((s) => !s.settings && !s.hiddenFromMenu).map((s) => s.id);
    const out = [];
    (Array.isArray(saved) ? saved : []).concat(RT.DEFAULT_ORDER).forEach((id) => { if (ids.indexOf(id) >= 0 && out.indexOf(id) < 0) out.push(id); });
    ids.forEach((id) => { if (out.indexOf(id) < 0) out.push(id); });
    return out;
  };


  // Simple view: these show by default; everything else on the page sits under "More settings".
  RT.CORE = {
    home: ['hideAllSuggestions', 'hideShortsHome', 'hideWatched', 'watchedMinPct', 'hideHomeChips', 'gridColumns', 'noInfiniteScroll', 'hideFeaturedHome'],
    shorts: ['hideShortsAll', 'hideShortsHome', 'hideShortsSubs', 'hideShortsSearch', 'hideShortsRecs', 'redirectShorts'],
    video: ['disableAutoplay', 'defaultSpeed', 'defaultQuality', 'neverCaptions', 'autoTheater', 'hideComments', 'hideRelated', 'hideWatchSidebar', 'hideEndscreenSuggestions', 'hideLiveChat', 'hideAiButtons', 'hideDescription', 'hideAds', 'commentSort', 'hideCommentCount', 'hideReplies', 'hideRepliesCount', 'autoExpandComments', 'commentFilters', 'commentKeywords', 'blockCommentAuthors', 'commentRegex', 'hideMenuButtons', 'hideLikeDislike', 'hideShare', 'hideActionButtons', 'hideOtherPlayerButtons', 'customVisibleButtons', 'hideLike', 'hideDislike', 'hideSave', 'hideDownload', 'hideClip', 'hideOtherButtons'],
    cards: ['hideCardViews', 'hideTimeSince', 'hidePubDate', 'showFullDates', 'hideBadges', 'fullTitles', 'gridHideAvatars', 'thumbsHideAll', 'blurThumbs', 'grayThumbs'],
    thumbnails: ['thumbsHideAll', 'blurThumbs', 'grayThumbs'],
    search: ['hideShortsSearch', 'hideSearchAds', 'searchHideWatched', 'hideSearchChips', 'hideSearchRecs', 'searchLayout'],
    subs: ['hideShortsSubs', 'subsHideWatched', 'subsWatchedMinPct', 'hideLiveStreams', 'hidePremieres', 'subsColumns'],
    channels: ['channelNoAutoplay', 'channelSearch', 'channelSearchGrid', 'channelDefaultTab', 'hideChannelSections', 'hideChannelRecs', 'customChannelColumns', 'channelSearchColumns'],
    sidebar: ['hideSidebarAll', 'hideShortsSidebar', 'hideNavSubs', 'hideNavHome', 'hideExplore', 'hideMoreFromYT'],
    header: ['hideBell', 'hideCreate', 'hideVoice', 'hideLogo', 'hideSearchBar'],
    recs: ['hideAllRecs', 'hideRelated', 'hideHomeChips', 'hideTrending'],
    filters: ['filtersEnabled', 'blockChannels', 'blockKeywords', 'hideLiveStreams'],
    ads: ['hideVideoAds', 'hideSidebarAds', 'hideBannerAds', 'hideAdSlots'],
    metrics: ['hideViews', 'hideCardViews', 'hideLikes', 'showFullDates', 'hideSubscribers'],
    interface: ['customTheme', 'cinemaMode', 'minimalInterface'],
    playback: ['disableAutoplay', 'defaultSpeed', 'defaultQuality', 'neverCaptions', 'autoTheater'],
    automation: ['disableAutoplay', 'autoSkipPromos', 'homeRedirect', 'homeRedirectUrl'],
    focus: ['zenMode', 'minimalistMode', 'dailyLimitMin', 'sessionLimitMin', 'timeBadge']
  };

  RT.sectionById = (id) => RT.SECTIONS.find((s) => s.id === (id === 'player' ? 'video' : id));
})();
