// Community posts in the Subscriptions feed.
// When "subsPosts" is on, this collects the channels that appear in the subscriptions feed, asks the
// background worker for their latest community posts, and slots each post into the feed grid at the
// position matching its age — so posts appear among the videos roughly as they were uploaded.
// Off by default; fetching posts per channel can slow the page, which the option warns about.
(function () {
  'use strict';
  const RT = window.RT;
  if (!RT) return;
  const on = (id) => RT.on(id);

  // "3 days ago" / "Streamed 2 hours ago" -> how long ago, in ms (bigger = older)
  function ageMs(txt) {
    const m = String(txt || '').match(/(\d+)\s*(second|minute|hour|day|week|month|year)s?\s+ago/i);
    if (!m) return null;
    const mult = { second: 1e3, minute: 6e4, hour: 36e5, day: 864e5, week: 6048e5, month: 2592e6, year: 31536e6 }[m[2].toLowerCase()];
    return (+m[1]) * mult;
  }
  function cardAge(el) {
    const box = el.querySelector('yt-content-metadata-view-model, #metadata-line, #metadata') || el;
    let best = null;
    box.querySelectorAll('span, .inline-metadata-item, [role="text"]').forEach((s) => {
      if (best != null) return;
      const a = ageMs(s.textContent || '');
      if (a != null) best = a;
    });
    return best != null ? best : ageMs(el.textContent || '');
  }

  const grid = () => document.querySelector('ytd-browse[page-subtype="subscriptions"] ytd-rich-grid-renderer > #contents');
  // every video card currently in the feed
  const videoItems = () => [].slice.call((grid() || document).querySelectorAll('ytd-rich-item-renderer:not([data-rt-post])'));

  // normalise any channel link (relative or absolute, with or without a tab suffix) to /channel/UC… or /@handle
  function channelPathFrom(href) {
    if (!href) return '';
    let h = href;
    const m = h.match(/^https?:\/\/[^/]*\byoutube\.com(\/.*)/i);
    if (m) h = m[1];
    h = h.split('?')[0].split('#')[0].replace(/\/(videos|featured|community|posts|shorts|streams|playlists|about)$/i, '');
    return (/^\/channel\/UC[\w-]{20,}$/.test(h) || /^\/@[\w.\-]+$/.test(h)) ? h : '';
  }
  // channel paths present in the feed right now (scans every link on each card, so the avatar's absolute URL counts too)
  function feedChannels() {
    const set = new Set();
    videoItems().forEach((card) => {
      [].slice.call(card.querySelectorAll('a[href]')).forEach((a) => { const p = channelPathFrom(a.getAttribute('href')); if (p) set.add(p); });
    });
    return [...set];
  }
  function mark(extra) { try { document.documentElement.setAttribute('data-rt-subsposts', 'on:' + (RT.page() === 'subs' && on('subsPosts')) + ' chans:' + requested.size + ' placed:' + placed.size + (extra ? ' ' + extra : '')); } catch (e) { /* ignore */ } }

  const requested = new Set(); // channel paths we've already asked the background for
  const placed = new Set();    // post ids/keys already inserted
  let style = null;
  function ensureStyle() {
    if (style && style.isConnected) return;
    style = document.createElement('style'); style.id = 'rt-subs-posts-style';
    style.textContent = [
      'ytd-rich-item-renderer[data-rt-post]{display:block}',
      '.rt-post{display:flex;flex-direction:column;gap:8px;height:100%;box-sizing:border-box;padding:14px;border-radius:12px;background:var(--yt-spec-badge-chip-background,rgba(128,128,128,.12));color:inherit;text-decoration:none;font-family:Roboto,Arial,sans-serif}',
      '.rt-post:hover{background:rgba(128,128,128,.2)}',
      '.rt-post .rt-post-head{display:flex;align-items:center;gap:10px}',
      '.rt-post .rt-post-head img{width:36px;height:36px;border-radius:50%;object-fit:cover;flex:none}',
      '.rt-post .rt-post-name{font-size:14px;font-weight:500;line-height:1.2}',
      '.rt-post .rt-post-time{font-size:12px;opacity:.7;margin-top:2px}',
      '.rt-post .rt-post-tag{font-size:11px;font-weight:600;letter-spacing:.3px;text-transform:uppercase;opacity:.6}',
      '.rt-post .rt-post-text{font-size:14px;line-height:1.4;white-space:pre-wrap;overflow:hidden;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:6}',
      '.rt-post .rt-post-img{width:100%;border-radius:10px;object-fit:cover;max-height:280px}'
    ].join('');
    (document.head || document.documentElement).appendChild(style);
  }

  function buildCard(post) {
    const item = document.createElement('ytd-rich-item-renderer');
    item.setAttribute('data-rt-post', post.id || '1');
    const a = document.createElement('a');
    a.className = 'rt-post'; a.href = post.url || '#'; a.title = 'Community post' + (post.author ? ' by ' + post.author : '');
    const head = document.createElement('div'); head.className = 'rt-post-head';
    if (post.avatar) { const im = document.createElement('img'); im.src = post.avatar; im.alt = ''; head.appendChild(im); }
    const who = document.createElement('div');
    const tag = document.createElement('div'); tag.className = 'rt-post-tag'; tag.textContent = 'Post';
    const nm = document.createElement('div'); nm.className = 'rt-post-name'; nm.textContent = post.author || 'Community post';
    const tm = document.createElement('div'); tm.className = 'rt-post-time'; tm.textContent = post.time || '';
    who.appendChild(tag); who.appendChild(nm); who.appendChild(tm); head.appendChild(who);
    a.appendChild(head);
    if (post.text) { const t = document.createElement('div'); t.className = 'rt-post-text'; t.textContent = post.text; a.appendChild(t); }
    if (post.image) { const im = document.createElement('img'); im.className = 'rt-post-img'; im.src = post.image; im.alt = ''; im.loading = 'lazy'; a.appendChild(im); }
    item.appendChild(a);
    return item;
  }

  function insertPost(post) {
    const key = post.id || (post.author + '|' + (post.text || '').slice(0, 40));
    if (!key || placed.has(key)) return;
    const g = grid(); if (!g) return;
    if (post.id && g.querySelector('ytd-rich-item-renderer[data-rt-post="' + CSS.escape(post.id) + '"]')) { placed.add(key); return; }
    const age = ageMs(post.time);
    const card = buildCard(post);
    // slot it before the first feed item that is older than the post; otherwise at the end
    let before = null;
    if (age != null) {
      const items = [].slice.call(g.querySelectorAll(':scope > ytd-rich-item-renderer'));
      for (const it of items) {
        const a = it.hasAttribute('data-rt-post') ? ageMs((it.querySelector('.rt-post-time') || {}).textContent) : cardAge(it);
        if (a != null && a > age) { before = it; break; }
      }
    }
    const cont = g.querySelector(':scope > ytd-continuation-item-renderer');
    if (before) g.insertBefore(card, before);
    else if (cont) g.insertBefore(card, cont);
    else g.appendChild(card);
    placed.add(key);
  }

  let busy = false, lastAsk = 0;
  function tick() {
    if (RT.page() !== 'subs' || !on('subsPosts')) { return; }
    ensureStyle();
    const seen = feedChannels();
    const chans = seen.filter((c) => !requested.has(c));
    mark('seen:' + seen.length + ' items:' + videoItems().length);
    if (!chans.length || busy || Date.now() - lastAsk < 1500) return;
    chans.forEach((c) => requested.add(c));
    busy = true; lastAsk = Date.now();
    try {
      chrome.runtime.sendMessage({ type: 'RT_SUBS_POSTS', channels: chans, perChannel: 3 }, (res) => {
        busy = false;
        if (chrome.runtime.lastError) { mark('err:' + ((chrome.runtime.lastError || {}).message || 'msg')); return; }
        if (!res || !res.posts) { mark('noposts'); return; }
        res.posts.forEach(insertPost);
        mark('got:' + res.posts.length);
      });
    } catch (e) { busy = false; mark('throw'); }
  }

  // when the option is turned off (or we leave the page), take our cards back out
  function cleanupIfOff() {
    if (RT.page() === 'subs' && on('subsPosts')) return;
    document.querySelectorAll('ytd-rich-item-renderer[data-rt-post]').forEach((e) => e.remove());
    placed.clear();
  }

  ['apply', 'navigate', 'dom'].forEach((ev) => RT.bus.addEventListener(ev, () => { cleanupIfOff(); tick(); }));
  setInterval(() => { cleanupIfOff(); tick(); }, 2000);
})();
