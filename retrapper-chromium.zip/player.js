// ReTrapper player automation (watch pages and embeds).
(function () {
  'use strict';
  const RT = window.RT;
  if (!RT) return;
  const S = () => RT.settings();
  const on = (id) => RT.on(id);

  // Ask the page-world bridge to run a player command.
  let seq = 0;
  const waiting = new Map();
  window.addEventListener('rt-cmd-result', (e) => {
    try { const r = JSON.parse(e.detail); const w = waiting.get(r.id); if (w) { waiting.delete(r.id); w(r); } } catch (err) { /* ignore */ }
  });
  RT.cmd = (cmd, arg) => new Promise((resolve) => {
    const id = ++seq;
    waiting.set(id, resolve);
    window.dispatchEvent(new CustomEvent('rt-cmd', { detail: JSON.stringify({ id, cmd, arg }) }));
    setTimeout(() => { if (waiting.delete(id)) resolve({ ok: false, result: 'timeout' }); }, 2500);
  });

  const isEmbed = () => RT.page() === 'embed';
  const settingsOn = () => (isEmbed() ? !!S().embedPlayerSettings : true);
  const videoKey = () => (isEmbed() ? location.pathname : new URLSearchParams(location.search).get('v') || '');
  let cur = { id: '', done: {}, t0: 0 };

  function applyPerVideo(v) {
    const s = S(), rp = (RT.rules && RT.rules.player) || {}, d = cur.done;
    const now = Date.now();
    // speed
    const sp = parseFloat(rp.speed || s.defaultSpeed);
    if (sp > 0 && v.readyState >= 1) {
      if (!d.speed) { v.playbackRate = sp; d.speed = now; }
      else if (d.speed !== true && now - d.speed > 1500) { v.playbackRate = sp; d.speed = true; }
    }
    // loop
    if (on('loopVideos') || rp.loop || on('intelligentLooping')) {
      const want = on('loopVideos') || !!rp.loop ||
        (on('intelligentLooping') && v.duration > 0 && v.duration <= Math.max(1, s.loopMaxMinutes) * 60);
      if (v.loop !== want) v.loop = want;
    }
    if (rp.mute && !d.mute) { v.muted = true; d.mute = true; }
    if (on('defaultVolumeOn') && !d.volume && v.readyState >= 1) {
      d.volume = true;
      v.volume = Math.min(1, Math.max(0, s.defaultVolume / 100));
      RT.cmd('volume', s.defaultVolume);
    }
    if (on('neverCaptions')) {
      // Keep captions off: for the first seconds of each video, switch them off if YouTube turned them on.
      // After that the button is left alone, so captions can still be turned on by hand.
      const b = document.querySelector('.ytp-subtitles-button');
      if (!RT._capWatch) {
        RT._capWatch = true;
        // A real click on the captions button, or the C key, means the user wants them: stop switching them off for this video.
        const mark = () => { cur.done.capUser = true; };
        document.addEventListener('click', (e) => { if (e.isTrusted && e.target && e.target.closest && e.target.closest('.ytp-subtitles-button')) mark(); }, true);
        document.addEventListener('keydown', (e) => { if (e.isTrusted && (e.key === 'c' || e.key === 'C') && !/input|textarea/i.test((e.target && e.target.tagName) || '')) mark(); }, true);
      }
      if (!d.capUser && b && b.getAttribute('aria-pressed') === 'true' && now - cur.t0 < 15000 && (d.capOff || 0) < 3 && now - (d.capAt || 0) > 700) {
        b.click(); d.capOff = (d.capOff || 0) + 1; d.capAt = now;
      }
    } else if ((on('autoCaptions') || rp.captions) && !d.captions) {
      const b = document.querySelector('.ytp-subtitles-button');
      if (b && !b.hasAttribute('disabled') && b.getAttribute('aria-pressed') === 'false') { b.click(); d.captions = true; }
      else if (b) d.captions = true;
    }
    const q = rp.quality || (s.defaultQuality !== 'off' ? s.defaultQuality : '');
    if (q && (d.quality || 0) < 4 && now - (d.qAt || 0) > 1500 && v.readyState >= 2) {
      d.quality = (d.quality || 0) + 1; d.qAt = now;
      RT.cmd('quality', q);
    }
    if (!isEmbed()) {
      if (on('disableAutoplay')) {
        const t = document.querySelector('.ytp-autonav-toggle-button');
        if (t && t.getAttribute('aria-checked') === 'true') t.click();
      }
      // Turn theater mode on and CHECK that it took. The player controls appear a moment
      // after the page loads and YouTube can ignore an early click, so keep trying (about
      // once a second, up to 30 times) until the page really is in theater mode.
      if ((on('autoTheater') || on('fullSizePlayer') || on('fullWindowPlayer') || rp.theater) && !d.theaterOk) {
        const fx = document.querySelector('ytd-watch-flexy, ytd-watch-grid');
        const b = document.querySelector('.ytp-size-button');
        const label = b ? (b.getAttribute('data-title-no-tooltip') || b.getAttribute('aria-label') || b.getAttribute('title') || '') : '';
        let isTheater = !!fx && (fx.hasAttribute('theater') || fx.theater === true);
        // Fallback for page layouts that use another element: the size button says "Default view" while in theater mode.
        if (!isTheater && /default view|exit theat/i.test(label)) isTheater = true;
        const note = (t) => { try { document.documentElement.setAttribute('data-rt-theater', t + ' tries:' + (d.theaterTries || 0) + ' flexy:' + (fx ? fx.localName : 'none') + ' btn:' + (b ? 'yes' : 'no') + ' label:' + label.slice(0, 24)); } catch (e) { /* ignore */ } };
        if (isTheater || (fx && fx.hasAttribute('fullscreen')) || document.fullscreenElement) { d.theaterOk = true; note('on'); }
        else if ((d.theaterTries || 0) < 30 && now - (d.theaterAt || 0) > 900) {
          if (b && !b.disabled) { b.click(); d.theaterTries = (d.theaterTries || 0) + 1; d.theaterAt = now; note('clicked'); }
          else note('waiting for button');
        } else if ((d.theaterTries || 0) >= 30) note('gave up');
      }
    }
    if (on('autoFullscreen') && !d.fullscreen) {
      d.fullscreen = true;
      const go = () => {
        document.removeEventListener('pointerdown', go, true);
        document.removeEventListener('keydown', go, true);
        if (document.fullscreenElement) return;
        const b = document.querySelector('.ytp-fullscreen-button');
        if (b) b.click();
      };
      document.addEventListener('pointerdown', go, true);
      document.addEventListener('keydown', go, true);
    }
  }

  // Promo skip: click the Skip button when YouTube offers it.
  setInterval(() => {
    if (!on('autoSkipPromos')) return;
    const b = document.querySelector('.ytp-skip-ad-button, .ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-ad-skip-button-container button');
    if (b) b.click();
  }, 600);

  // Block video ads (fallback): stripping the player response (page-bridge) stops almost every ad before it
  // loads, but any that still reaches the player — click Skip the moment it appears, otherwise jump the ad to
  // its end and mute it. Guarded by the player's own "ad-showing" state, so the real video is never touched.
  setInterval(() => {
    if (!on('blockVideoAds')) return;
    const b = document.querySelector('.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, .ytp-ad-skip-button-container button');
    if (b) { b.click(); return; }
    const player = document.querySelector('.html5-video-player.ad-showing, .html5-video-player.ad-interrupting');
    if (!player) return;
    const v = player.querySelector('video.html5-main-video') || document.querySelector('.html5-main-video');
    if (v && v.duration && isFinite(v.duration) && v.currentTime < v.duration - 0.2) {
      v.muted = true;
      try { v.currentTime = v.duration; } catch (e) { /* ignore */ }
    }
  }, 400);

  // ---- player height (full-size / full-window / resizable) ---------------------
  let lastH = '';
  function heights() {
    const s = S();
    let px = 0;
    if (RT.page() === 'watch') {
      const m = document.querySelector('#masthead-container') || document.querySelector('ytd-masthead');
      const top = on('fullWindowPlayer') || on('hideHeader') ? 0 : (m ? Math.round(m.getBoundingClientRect().height) : 56);
      if (on('resizablePlayer') && s.playerHeight > 0) px = s.playerHeight;
      else if (on('fullSizePlayer') || on('fullWindowPlayer')) px = Math.max(innerHeight - top, 200);
    }
    const key = String(px);
    if (key === lastH) return;
    lastH = key;
    RT.dynSet('player', px ? { '--rt-player-h': px + 'px' } : null, px ? 'rtPlayerH' : null);
  }
  window.addEventListener('resize', heights);

  let handle = null, dragging = false;
  function resizer() {
    const flexy = document.querySelector('ytd-watch-flexy');
    const box = document.querySelector('#player-theater-container');
    const show = on('resizablePlayer') && RT.page() === 'watch' && flexy && flexy.hasAttribute('theater') && box;
    if (!show) { if (handle) { handle.remove(); handle = null; } return; }
    if (handle && handle.isConnected) return;
    handle = document.createElement('div');
    handle.id = 'rt-resize';
    handle.title = 'Drag to resize (double-click to reset)';
    handle.style.cssText = 'position:absolute;left:0;right:0;bottom:0;height:8px;cursor:ns-resize;background:rgba(128,128,128,.45);z-index:2000;';
    if (getComputedStyle(box).position === 'static') box.style.position = 'relative';
    box.appendChild(handle);
    handle.addEventListener('pointerdown', (e) => { dragging = true; handle.setPointerCapture(e.pointerId); e.preventDefault(); });
    handle.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      const top = box.getBoundingClientRect().top;
      const h = Math.max(200, Math.round(e.clientY - top));
      lastH = String(h);
      RT.dynSet('player', { '--rt-player-h': h + 'px' }, 'rtPlayerH');
    });
    handle.addEventListener('pointerup', () => {
      dragging = false;
      const h = parseInt(lastH, 10);
      if (h) RT.save({ playerHeight: h });
    });
    handle.addEventListener('dblclick', () => RT.save({ playerHeight: 0 }));
  }

  // ---- playlist bar --------------------------------------------------------------------
  let bar = null;
  function playlistBar() {
    const inList = RT.page() === 'watch' && new URLSearchParams(location.search).get('list');
    if (!inList || !on('playlistNavigation')) { if (bar) { bar.remove(); bar = null; } return; }
    const wantControls = on('playlistControls');
    if (bar && bar.isConnected && bar.dataset.c === String(wantControls)) return;
    if (bar) bar.remove();
    bar = document.createElement('div');
    bar.id = 'rt-playlist-bar';
    bar.dataset.c = String(wantControls);
    bar.style.cssText = 'position:fixed;left:16px;bottom:16px;z-index:2147483000;display:flex;gap:6px;background:#202020;border-radius:20px;padding:4px;';
    const mk = (label, title, fn) => {
      const b = document.createElement('button');
      b.textContent = label; b.title = title;
      b.style.cssText = 'border:0;background:transparent;color:#fff;font-size:16px;width:34px;height:30px;border-radius:15px;cursor:pointer;';
      b.addEventListener('click', fn);
      bar.appendChild(b);
    };
    const click = (sel) => { const b = document.querySelector(sel); if (b) b.click(); };
    mk('⏮', 'Previous in playlist', () => click('.ytp-prev-button'));
    mk('⏭', 'Next in playlist', () => click('.ytp-next-button'));
    if (wantControls) {
      mk('🔁', 'Loop playlist', () => click('ytd-playlist-loop-button-renderer button, ytd-playlist-panel-renderer button[aria-label*="oop" i]'));
      mk('🔀', 'Shuffle playlist', () => click('ytd-playlist-panel-renderer button[aria-label*="huffle" i], #playlist-action-menu button[aria-label*="huffle" i]'));
    }
    document.documentElement.appendChild(bar);
  }

  function tick() {
    heights();
    if (!settingsOn() && isEmbed()) return;
    const pt = RT.page();
    if (pt !== 'watch' && pt !== 'embed') { playlistBar(); resizer(); return; }
    const v = document.querySelector('video.html5-main-video') || document.querySelector('video');
    if (!v) return;
    const id = videoKey();
    if (id !== cur.id) cur = { id, done: {}, t0: Date.now() };
    applyPerVideo(v);
    resizer();
    playlistBar();
  }
  RT.bus.addEventListener('dom', tick);
  RT.bus.addEventListener('navigate', tick);
  setInterval(tick, 900);
})();
