// Runs in the page's own JavaScript world.
//
// 1) Receives shelf-click navigation requests from content.js as a JSON
//    string and hands them to YouTube as an in-page navigation (objects
//    passed from the extension's isolated world arrive empty).
// 2) Watches YouTube's own "edit playlist" calls. When the Watch Later
//    playlist is changed (a video added or removed, from any button or menu
//    in this browser), it fires a plain event so the shelf can refresh.
(function () {
  'use strict';

  // ---- Block video ads: strip the ad data out of YouTube's player responses ------------------------------
  // The method ad blockers use for YouTube: the ads (pre-roll, mid-roll, skippable) are listed in the
  // player response the page fetches; remove those fields before the player reads them and no ad video is
  // built. This runs first, in the page's own world at document_start, and is gated by a flag the content
  // script mirrors into localStorage (readable synchronously here, even this early).
  (function () {
    const adblockOn = () => { try { return localStorage.getItem('rt-adblock') === '1'; } catch (e) { return false; } };
    const AD_KEYS = ['adPlacements', 'playerAds', 'adSlots', 'adBreakHeartbeatParams', 'adParams', 'adServerData', 'adBreakServiceParams'];
    // The anti-ad-block nag: YouTube mounts this view-model into a popup and pauses the player when it thinks
    // ads were blocked. Removing it from the response before the UI reads it means the modal never mounts.
    const ENFORCE_KEYS = ['enforcementMessageViewModel', 'ytdEnforcementMessageViewModel', 'enforcementMessageViewModelRenderer', 'playerLegacyDesktopWatchAdsRenderer'];
    // remove the ad fields from a player response, and from any player response nested inside it
    function strip(o, d) {
      if (!o || typeof o !== 'object' || d > 8) return o;
      if (Array.isArray(o)) { if (o.length <= 256) for (let i = 0; i < o.length; i++) strip(o[i], d + 1); return o; }
      for (let i = 0; i < AD_KEYS.length; i++) if (AD_KEYS[i] in o) delete o[AD_KEYS[i]];
      for (let i = 0; i < ENFORCE_KEYS.length; i++) if (ENFORCE_KEYS[i] in o) delete o[ENFORCE_KEYS[i]];
      // A playability block whose text is about ad blocking stops the video entirely; clear it so it plays.
      if (d < 2 && o.playabilityStatus && o.playabilityStatus.status && o.playabilityStatus.status !== 'OK') {
        try {
          if (/ad\s?block|blocker|not allowed on youtube/i.test(JSON.stringify(o.playabilityStatus))) {
            o.playabilityStatus = { status: 'OK', playableInEmbed: o.playabilityStatus.playableInEmbed };
          }
        } catch (e) { /* ignore */ }
      }
      if (o.playerResponse) strip(o.playerResponse, d + 1);
      if (o.playerConfig && o.playerConfig.daiConfig) delete o.playerConfig.daiConfig;
      if (d < 3) for (const k in o) { const v = o[k]; if (v && typeof v === 'object') strip(v, d + 1); }
      return o;
    }
    const looksLikePR = (o) => !!o && typeof o === 'object' && (('adPlacements' in o) || ('playerAds' in o) || ('adSlots' in o) || (o.streamingData && o.videoDetails) || ('playerResponse' in o));

    // 1) the initial player response (a global YouTube sets once on first page load)
    try {
      let ipr;
      Object.defineProperty(window, 'ytInitialPlayerResponse', {
        configurable: true,
        get() { return ipr; },
        set(v) { ipr = (adblockOn() && v) ? strip(v, 0) : v; }
      });
    } catch (e) { /* property locked: the JSON.parse / fetch hooks below still catch it */ }

    // 2) JSON.parse — YouTube parses the player / next responses through it
    const _parse = JSON.parse;
    JSON.parse = function (text, reviver) {
      const r = _parse.call(this, text, reviver);
      if (adblockOn() && looksLikePR(r)) { try { strip(r, 0); } catch (e) { /* ignore */ } }
      return r;
    };

    // 3) fetch — a SPA navigation fetches a fresh player response that may not pass through JSON.parse
    const _fetch = window.fetch;
    if (typeof _fetch === 'function') {
      window.fetch = function (input) {
        const url = (input && typeof input === 'object' && input.url) ? input.url : String(input || '');
        const p = _fetch.apply(this, arguments);
        if (!adblockOn() || !/\/youtubei\/v1\/(player|reel_item_watch)\b/.test(url)) return p;
        return p.then((res) => {
          try {
            return res.clone().text().then((t) => {
              let data; try { data = _parse(t); } catch (e) { return res; }
              strip(data, 0);
              return new Response(JSON.stringify(data), { status: res.status, statusText: res.statusText, headers: res.headers });
            }).catch(() => res);
          } catch (e) { return res; }
        });
      };
    }
  })();

  window.addEventListener('watch-later-shelf-navigate', (e) => {
    try {
      const detail = JSON.parse(e.detail);
      const app = document.querySelector('ytd-app');
      if (!app) return;
      app.dispatchEvent(new CustomEvent('yt-navigate', { detail, bubbles: true, composed: true }));
    } catch (err) {
      /* content.js falls back to a normal navigation */
    }
  });

  // --- playlist edits requested by the shelf ---------------------------------
  //
  // Menu actions on shelf videos (remove, undo, remove all) are sent here as
  // JSON. They are posted to YouTube's own edit-playlist endpoint using the
  // page's existing signed-in session, exactly as YouTube's own buttons do.

  function getCookie(name) {
    const m = document.cookie.match(new RegExp('(?:^|;\\s*)' + name + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : null;
  }

  async function sha1Hex(text) {
    const buf = await crypto.subtle.digest('SHA-1', new TextEncoder().encode(text));
    return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
  }

  async function authHeader() {
    const sid = getCookie('SAPISID') || getCookie('__Secure-3PAPISID');
    if (!sid) return null;
    const ts = Math.floor(Date.now() / 1000);
    return `SAPISIDHASH ${ts}_${await sha1Hex(`${ts} ${sid} ${location.origin}`)}`;
  }

  window.addEventListener('watch-later-shelf-edit', async (e) => {
    let req;
    try {
      req = JSON.parse(e.detail);
    } catch (err) {
      return;
    }
    const reply = (ok, error) =>
      window.dispatchEvent(
        new CustomEvent('watch-later-shelf-edit-result', {
          detail: JSON.stringify({ requestId: req.requestId, ok: !!ok, error: error || null })
        })
      );
    try {
      const cfg = window.ytcfg;
      const get = (k) => (cfg && typeof cfg.get === 'function' ? cfg.get(k) : undefined);
      const context = get('INNERTUBE_CONTEXT');
      if (!context) return reply(false, 'no-context');
      const auth = await authHeader();
      if (!auth) return reply(false, 'not-signed-in');

      const headers = {
        'Content-Type': 'application/json',
        Authorization: auth,
        'X-Goog-AuthUser': String(get('SESSION_INDEX') || 0),
        'X-Origin': location.origin,
        'X-Youtube-Client-Name': String(get('INNERTUBE_CONTEXT_CLIENT_NAME') || 1),
        'X-Youtube-Client-Version': String(get('INNERTUBE_CONTEXT_CLIENT_VERSION') || (context.client && context.client.clientVersion) || '')
      };
      const visitor = get('VISITOR_DATA');
      if (visitor) headers['X-Goog-Visitor-Id'] = visitor;
      const key = get('INNERTUBE_API_KEY');
      const url = '/youtubei/v1/browse/edit_playlist?prettyPrint=false' + (key ? '&key=' + encodeURIComponent(key) : '');

      const res = await window.fetch(url, {
        method: 'POST',
        credentials: 'include',
        headers,
        body: JSON.stringify({ context, playlistId: 'WL', actions: req.actions })
      });
      let json = null;
      try { json = await res.json(); } catch (err) { /* no body */ }
      const ok = res.ok && (!json || !json.status || json.status === 'STATUS_SUCCEEDED');
      reply(ok, ok ? null : `http-${res.status}`);
    } catch (err) {
      reply(false, String(err));
    }
  });

  const EDIT_RE = /\/youtubei\/v1\/browse\/edit_playlist/;

  function touchesWatchLater(bodyText) {
    // Unknown body: assume it might be Watch Later (an extra refresh is harmless).
    if (!bodyText) return true;
    try {
      const body = JSON.parse(bodyText);
      return !!body && body.playlistId === 'WL';
    } catch (e) {
      return /"playlistId"\s*:\s*"WL"/.test(String(bodyText));
    }
  }

  function notify() {
    window.dispatchEvent(new CustomEvent('watch-later-shelf-changed'));
  }

  // Reads the request body however YouTube passed it (string, Blob, bytes or
  // a Request). Must be called before the request is sent.
  async function readBody(input, init) {
    try {
      const b = init && init.body;
      if (typeof b === 'string') return b;
      if (b && typeof b.text === 'function') return await b.text();
      if (b && (b instanceof ArrayBuffer || ArrayBuffer.isView(b))) return new TextDecoder().decode(b);
      if (!b && input && typeof input.clone === 'function') return await input.clone().text();
    } catch (e) { /* unknown body */ }
    return '';
  }

  const originalFetch = window.fetch;
  window.fetch = function (input, init) {
    let bodyPromise = null;
    try {
      const url = typeof input === 'string' ? input : (input && input.url) || '';
      if (EDIT_RE.test(url)) bodyPromise = readBody(input, init);
    } catch (e) { /* never break YouTube's own requests */ }
    const result = originalFetch.apply(this, arguments);
    if (bodyPromise) {
      Promise.all([result, bodyPromise]).then(([res, text]) => {
        if (res && res.ok && touchesWatchLater(text)) notify();
      }).catch(() => {});
    }
    return result;
  };

  // Same watch for edit calls made through XMLHttpRequest.
  const xOpen = XMLHttpRequest.prototype.open;
  const xSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url) {
    try { this.__wlUrl = String(url); } catch (e) { /* ignore */ }
    return xOpen.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function (body) {
    try {
      if (this.__wlUrl && EDIT_RE.test(this.__wlUrl)) {
        const text = typeof body === 'string' ? body : '';
        this.addEventListener('load', () => {
          if (this.status >= 200 && this.status < 300 && touchesWatchLater(text)) notify();
        });
      }
    } catch (e) { /* ignore */ }
    return xSend.apply(this, arguments);
  };

  // Fallback signal: YouTube's own confirmation toast ("Saved to Watch later",
  // "Removed from Watch later"), in case a change goes through some other path.
  let toastTimer = 0;
  const toastWatcher = new MutationObserver((muts) => {
    for (const m of muts) {
      for (const n of m.addedNodes) {
        if (n.nodeType !== 1 || !/TOAST|NOTIFICATION-ACTION|SNACKBAR/.test(n.tagName || '')) continue;
        setTimeout(() => {
          const t = n.textContent || '';
          if (/watch later/i.test(t) && /(added|saved|removed)/i.test(t)) {
            clearTimeout(toastTimer);
            toastTimer = setTimeout(notify, 300);
          }
        }, 150);
      }
    }
  });
  let toastTries = 0;
  const toastFind = setInterval(() => {
    const pc = document.querySelector('ytd-popup-container');
    if (pc) { toastWatcher.observe(pc, { childList: true, subtree: true }); clearInterval(toastFind); }
    else if (++toastTries > 120) clearInterval(toastFind);
  }, 1000);

  // --- exact upload dates for ReTrapper ---------------------------------------
  // Looks a video's full upload timestamp up (the player response already
  // holds it for the video being watched; otherwise ask YouTube's player API).
  (function () {
    const queue = [];
    let busy = false;
    function pick(r) {
      const m = r && r.microformat && r.microformat.playerMicroformatRenderer;
      if (!m) return '';
      const live = m.liveBroadcastDetails || {};
      const c = [live.startTimestamp, m.uploadDate, m.publishDate].filter(Boolean);
      return c.find((x) => /T/.test(x)) || c[0] || '';
    }
    async function lookup(id) {
      try {
        const p = document.getElementById('movie_player');
        const r = p && typeof p.getPlayerResponse === 'function' ? p.getPlayerResponse() : null;
        if (r && r.videoDetails && r.videoDetails.videoId === id) { const d = pick(r); if (d) return d; }
      } catch (e) { /* fall through */ }
      try {
        const ir = window.ytInitialPlayerResponse;
        if (ir && ir.videoDetails && ir.videoDetails.videoId === id) { const d = pick(ir); if (d) return d; }
      } catch (e) { /* fall through */ }
      // 1) YouTube's player API
      try {
        const cfg = window.ytcfg && typeof window.ytcfg.get === 'function' ? window.ytcfg : null;
        const ctx = cfg && cfg.get('INNERTUBE_CONTEXT');
        if (ctx) {
          const key = cfg.get('INNERTUBE_API_KEY');
          const res = await fetch('/youtubei/v1/player?prettyPrint=false' + (key ? '&key=' + encodeURIComponent(key) : ''), {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ context: ctx, videoId: id, contentCheckOk: true, racyCheckOk: true })
          });
          if (res.ok) { const d = pick(await res.json()); if (d) return d; }
        }
      } catch (e) { /* fall through */ }
      // 2) the video's own page
      try {
        const res = await fetch('/watch?v=' + encodeURIComponent(id), { credentials: 'same-origin' });
        if (res.ok) {
          const html = await res.text();
          const all = [...html.matchAll(/"(?:uploadDate|publishDate|startTimestamp)":"([^"]+)"/g)].map((m) => m[1]);
          return all.find((x) => /T/.test(x)) || all[0] || '';
        }
      } catch (e) { /* give up */ }
      return '';
    }
    async function drain() {
      if (busy) return;
      busy = true;
      while (queue.length) {
        const id = queue.shift();
        let date = '';
        try { date = await Promise.race([lookup(id), new Promise((r) => setTimeout(() => r(''), 8000))]); } catch (e) { date = ''; }
        window.dispatchEvent(new CustomEvent('rt-date-res', { detail: JSON.stringify({ id, date }) }));
        await new Promise((r) => setTimeout(r, 150));
      }
      busy = false;
    }
    window.addEventListener('rt-date-req', (e) => {
      let req;
      try { req = JSON.parse(e.detail); } catch (err) { return; }
      if (req && /^[\w-]{11}$/.test(req.id) && !queue.includes(req.id)) { queue.push(req.id); drain(); }
    });
  })();

  // --- channel search support for ReTrapper ------------------------------------
  // Reads video lists (channel playlists, search results) from YouTube's own
  // API and returns them in a small, uniform shape.
  (function () {
    const txt = (x) => (!x ? '' : x.simpleText || x.content || (Array.isArray(x.runs) ? x.runs.map((r) => r.text).join('') : ''));
    const num = (s) => {
      const m = String(s || '').replace(/,/g, '').match(/([\d.]+)\s*([KMB])?/i);
      if (!m) return 0;
      return Math.round(parseFloat(m[1]) * ({ K: 1e3, M: 1e6, B: 1e9 }[(m[2] || '').toUpperCase()] || 1));
    };
    function fromRenderer(v) {
      const info = v.videoInfo ? txt(v.videoInfo).split(/\s*[•·]\s*/) : [];
      const owner = v.ownerText || v.longBylineText || v.shortBylineText;
      const run = owner && owner.runs && owner.runs[0];
      const browse = run && run.navigationEndpoint && run.navigationEndpoint.browseEndpoint;
      const snip = v.descriptionSnippet ? txt(v.descriptionSnippet)
        : (v.detailedMetadataSnippets && v.detailedMetadataSnippets[0] ? txt(v.detailedMetadataSnippets[0].snippetText) : '');
      const badges = JSON.stringify(v.badges || []) + JSON.stringify(v.thumbnailOverlays || []);
      return {
        id: v.videoId, title: txt(v.title), len: txt(v.lengthText) || (info.length > 2 ? '' : ''),
        views: txt(v.viewCountText) || info.find((x) => /view|watching/i.test(x)) || '',
        ago: txt(v.publishedTimeText) || info.find((x) => /ago|stream|premier/i.test(x)) || '',
        ch: run ? run.text : '', chId: (browse && browse.browseId) || '', snip,
        live: /"LIVE"|BADGE_STYLE_TYPE_LIVE_NOW/.test(badges), short: /\/shorts\//.test(JSON.stringify(v.navigationEndpoint || {}))
      };
    }
    function findDuration(o, d) {
      if (!o || typeof o !== 'object' || d > 14) return '';
      if (typeof o.text === 'string' && /^\d+(:\d{2}){1,2}$/.test(o.text.trim())) return o.text.trim();
      for (const k in o) { const r = findDuration(o[k], d + 1); if (r) return r; }
      return '';
    }
    function fromLockup(v) {
      const type = String(v.contentType || '');
      if (type && !/VIDEO|SHORT|STREAM/i.test(type)) return null;
      const m = v.metadata && v.metadata.lockupMetadataViewModel;
      if (!m || !v.contentId) return null;
      const rows = (((m.metadata || {}).contentMetadataViewModel || {}).metadataRows || []);
      const parts = [];
      rows.forEach((r) => (r.metadataParts || []).forEach((p) => { const t = txt(p.text); if (t) parts.push(t); }));
      return {
        id: v.contentId, title: txt(m.title), len: findDuration(v.contentImage, 0),
        views: parts.find((x) => /view|watching/i.test(x)) || '', ago: parts.find((x) => /ago|stream|premier/i.test(x)) || '',
        ch: '', chId: '', snip: '', live: /LIVE/i.test(JSON.stringify(v.contentImage || {}).slice(0, 4000)) && /watching/i.test(parts.join(' ')),
        short: /SHORT/i.test(type)
      };
    }
    function fromShort(v) {
      const id = v.videoId || (v.onTap && v.onTap.innertubeCommand && v.onTap.innertubeCommand.reelWatchEndpoint && v.onTap.innertubeCommand.reelWatchEndpoint.videoId) || '';
      if (!id) return null;
      const t = v.headline ? txt(v.headline) : (v.overlayMetadata && v.overlayMetadata.primaryText ? txt(v.overlayMetadata.primaryText) : '');
      const views = v.viewCountText ? txt(v.viewCountText) : (v.overlayMetadata && v.overlayMetadata.secondaryText ? txt(v.overlayMetadata.secondaryText) : '');
      return { id, title: t, len: '', views, ago: '', ch: '', chId: '', snip: '', live: false, short: true };
    }
    function collect(json) {
      const out = { items: [], cont: '' };
      (function walk(o, d) {
        if (!o || typeof o !== 'object' || d > 40) return;
        if (Array.isArray(o)) { o.forEach((x) => walk(x, d + 1)); return; }
        for (const k in o) {
          const v = o[k];
          if (k === 'videoRenderer' || k === 'playlistVideoRenderer' || k === 'gridVideoRenderer' || k === 'compactVideoRenderer') {
            if (v && v.videoId) out.items.push(fromRenderer(v));
          } else if (k === 'lockupViewModel') {
            const it = fromLockup(v); if (it) out.items.push(it);
          } else if (k === 'reelItemRenderer' || k === 'shortsLockupViewModel') {
            const it = fromShort(v); if (it) out.items.push(it);
          } else {
            if (k === 'continuationCommand' && v && v.token) out.cont = v.token;
            walk(v, d + 1);
          }
        }
      })(json, 0);
      const seen = new Set();
      out.items = out.items.filter((x) => x.id && !seen.has(x.id) && seen.add(x.id));
      out.items.forEach((x) => { x.viewsN = num(x.views); });
      return out;
    }

    window.addEventListener('rt-yt-req', async (e) => {
      let req;
      try { req = JSON.parse(e.detail); } catch (err) { return; }
      const reply = (o) => window.dispatchEvent(new CustomEvent('rt-yt-res', { detail: JSON.stringify(Object.assign({ id: req.id }, o)) }));
      try {
        if (req.kind === 'channel') {
          const b = document.querySelector('ytd-browse');
          const meta = b && b.data && b.data.metadata && b.data.metadata.channelMetadataRenderer;
          return reply({ channelId: (meta && meta.externalId) || '', name: (meta && meta.title) || '' });
        }
        const cfg = window.ytcfg && typeof window.ytcfg.get === 'function' ? window.ytcfg : null;
        const ctx = cfg && cfg.get('INNERTUBE_CONTEXT');
        if (!ctx) return reply({ error: 'no-context' });
        const key = cfg.get('INNERTUBE_API_KEY');
        const res = await fetch('/youtubei/v1/' + req.endpoint + '?prettyPrint=false' + (key ? '&key=' + encodeURIComponent(key) : ''), {
          method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json' },
          body: JSON.stringify(Object.assign({ context: ctx }, req.body))
        });
        if (!res.ok) return reply({ error: 'http ' + res.status });
        const out = collect(await res.json());
        reply({ items: out.items, cont: out.cont });
      } catch (err) { reply({ error: String(err).slice(0, 120) }); }
    });
  })();

  // --- the channels the viewer is subscribed to (for showing only those names on collab videos) ---------------
  window.addEventListener('rt-subs-req', async () => {
    const reply = (o) => window.dispatchEvent(new CustomEvent('rt-subs-res', { detail: JSON.stringify(o) }));
    try {
      const ids = new Set();
      const any = new Set();
      let tok = null, steps = [];
      const walk = (n, d) => {
        if (!n || typeof n !== 'object' || d > 45) return;
        if (Array.isArray(n)) { n.forEach((x) => walk(x, d + 1)); return; }
        const cr = n.channelRenderer;
        if (cr && /^UC[\w-]{20,}$/.test(cr.channelId || '')) ids.add(cr.channelId);
        const lv = n.lockupViewModel;
        if (lv && /CHANNEL/.test(lv.contentType || '') && /^UC[\w-]{20,}$/.test(lv.contentId || '')) ids.add(lv.contentId);
        if (n.browseEndpoint && /^UC[\w-]{20,}$/.test(n.browseEndpoint.browseId || '')) any.add(n.browseEndpoint.browseId);
        const cc = n.continuationCommand;
        if (cc && cc.token && !tok) tok = cc.token;
        for (const k in n) walk(n[k], d + 1);
      };
      // 1) the "All subscriptions" page itself: its first screenful of channels is in the page text
      try {
        const res = await fetch('/feed/channels', { credentials: 'same-origin' });
        const t = res.ok ? await res.text() : '';
        const m = t.indexOf('ytInitialData = ');
        if (m > -1) {
          const st = t.indexOf('{', m), en = t.indexOf(';</script>', st);
          if (st > -1 && en > st) { walk(JSON.parse(t.slice(st, en)), 0); }
        }
        steps.push('html:' + ids.size + '/' + any.size);
      } catch (err) { steps.push('html-err'); }
      // 2) the rest (and everything, if the page text gave nothing) from YouTube's own list request
      const cfg = window.ytcfg && typeof window.ytcfg.get === 'function' ? window.ytcfg : null;
      const ctx = cfg && cfg.get('INNERTUBE_CONTEXT');
      if (ctx) {
        const key = cfg.get('INNERTUBE_API_KEY');
        const auth = {};
        try {
          const ck = /(?:^|; )SAPISID=([^;]+)/.exec(document.cookie) || /(?:^|; )__Secure-3PAPISID=([^;]+)/.exec(document.cookie);
          if (ck && window.crypto && crypto.subtle) {
            const ts = Math.floor(Date.now() / 1000);
            const buf = await crypto.subtle.digest('SHA-1', new TextEncoder().encode(ts + ' ' + ck[1] + ' ' + location.origin));
            auth.authorization = 'SAPISIDHASH ' + ts + '_' + Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
            auth['x-origin'] = location.origin; auth['x-goog-authuser'] = '0';
          }
        } catch (err) { /* without it the cookies alone are used */ }
        let body = (ids.size && tok) ? { continuation: tok } : (ids.size ? null : { browseId: 'FEchannels' });
        let pages = 0;
        while (body && pages++ < 30) {
          tok = null;
          const res = await fetch('/youtubei/v1/browse?prettyPrint=false' + (key ? '&key=' + encodeURIComponent(key) : ''), {
            method: 'POST', credentials: 'same-origin', headers: Object.assign({ 'content-type': 'application/json' }, auth),
            body: JSON.stringify(Object.assign({ context: ctx }, body))
          });
          if (!res.ok) { steps.push('api-' + res.status); break; }
          walk(await res.json(), 0);
          body = tok ? { continuation: tok } : null;
        }
        steps.push('api-pages:' + (pages - 1));
      } else steps.push('no-context');
      const out = Array.from(ids.size ? ids : any);
      reply({ ids: out, exact: !!ids.size, steps: steps.join(' ') });
    } catch (err) { reply({ error: String(err).slice(0, 120) }); }
  });

  // --- the sort order shown on the Watch Later page -----------------------------------------------------------
  window.addEventListener('rt-wlsort-req', () => {
    let out = { selected: '', titles: [] };
    try {
      const b = document.querySelector('ytd-browse:not([hidden])');
      const root = b && b.data;
      let found = null, budget = 40000;
      const seen = new WeakSet();
      (function walk(o, d) {
        if (found || !o || typeof o !== 'object' || seen.has(o) || budget-- <= 0 || d > 60) return;
        seen.add(o);
        if (Array.isArray(o.subMenuItems) && o.subMenuItems.length >= 2 && o.subMenuItems.some((x) => x && typeof x.selected === 'boolean' && x.title)) { found = o.subMenuItems; return; }
        for (const k in o) walk(o[k], d + 1);
      })(root, 0);
      if (found) {
        const sel = found.find((x) => x && x.selected && x.title);
        out = { selected: sel ? String(sel.title) : '', titles: found.filter((x) => x && x.title).map((x) => String(x.title)) };
      }
    } catch (err) { /* nothing found */ }
    window.dispatchEvent(new CustomEvent('rt-wlsort-res', { detail: JSON.stringify(out) }));
  });

  // --- collab videos: the list of channels behind "A and B" -------------------------------------------------
  // YouTube keeps the full list (names and channel links) in the owner data for the "collaborators" popup.
  // This reads it from the page and hands back plain names and links.
  window.addEventListener('rt-collab-req', () => {
    const out = [];
    try {
      const seen = new Set();
      const roots = [];
      const o1 = document.querySelector('ytd-video-owner-renderer');
      const o2 = document.querySelector('ytd-watch-metadata');
      [o1, o2].forEach((el) => { if (el && el.data) roots.push(el.data); });
      const findBrowse = (n, d) => {
        if (!n || typeof n !== 'object' || d > 14) return null;
        if (n.browseEndpoint && /^UC[\w-]{20,}$/.test(n.browseEndpoint.browseId || '')) return n.browseEndpoint;
        for (const k in n) { const r = findBrowse(n[k], d + 1); if (r) return r; }
        return null;
      };
      const findImg = (n, d) => {
        if (!n || typeof n !== 'object' || d > 10) return '';
        if (Array.isArray(n.sources) && n.sources.length && n.sources[0] && typeof n.sources[0].url === 'string') return n.sources[0].url;
        if (Array.isArray(n.thumbnails) && n.thumbnails[0] && typeof n.thumbnails[0].url === 'string') return n.thumbnails[0].url;
        for (const k in n) { const r = findImg(n[k], d + 1); if (r) return r; }
        return '';
      };
      // verified / official-artist badge anywhere inside this channel's entry
      const isVerified = (n, d) => {
        if (!n || d > 10) return false;
        if (typeof n === 'string') return /^(CHECK_CIRCLE_FILLED|OFFICIAL_ARTIST_BADGE|BADGE_STYLE_TYPE_VERIFIED(_ARTIST)?|VERIFIED(_CHECK)?|AUDIO_BADGE)$/.test(n) || /verified/i.test(n);
        if (typeof n !== 'object') return false;
        for (const k in n) { if (k === 'browseEndpoint' || k === 'commandRuns') continue; if (isVerified(n[k], d + 1)) return true; }
        return false;
      };
      const visit = (n, d) => {
        if (!n || typeof n !== 'object' || d > 18) return;
        const t = n.title;
        const name = t && typeof t === 'object' ? (t.content || t.simpleText || (t.runs && t.runs.map((r) => r.text).join(''))) : '';
        if (name && typeof name === 'string') {
          const be = findBrowse(n, 0);
          if (be && !seen.has(be.browseId)) { seen.add(be.browseId); out.push({ name: name.trim(), id: be.browseId, path: be.canonicalBaseUrl || ('/channel/' + be.browseId), img: findImg(n, 0), verified: isVerified(n, 0) }); }
        }
        for (const k in n) visit(n[k], d + 1);
      };
      roots.forEach((r) => visit(r, 0));
    } catch (err) { /* nothing found */ }
    window.dispatchEvent(new CustomEvent('rt-collab-res', { detail: JSON.stringify({ v: new URLSearchParams(location.search).get('v') || '', channels: out }) }));
  });

  // Collab videos in cards (search, home, related, channel pages...): find the channels listed in each card's data
  // and note them on the card so the content script can turn the names into links.
  const ccSeen = new WeakMap();
  window.addEventListener('rt-collab-scan', () => {
    try {
      const UC = /^UC[\w-]{20,}$/;
      const CARD = 'yt-lockup-view-model, ytd-video-renderer, ytd-compact-video-renderer, ytd-grid-video-renderer, ytd-rich-grid-media, ytd-playlist-video-renderer, ytd-playlist-panel-video-renderer, ytd-reel-item-renderer';
      // verified / official-artist badge anywhere inside a channel's entry (same markers as the watch-page path)
      const isVerified = (n, d) => {
        if (!n || d > 10) return false;
        if (typeof n === 'string') return /^(CHECK_CIRCLE_FILLED|OFFICIAL_ARTIST_BADGE|BADGE_STYLE_TYPE_VERIFIED(_ARTIST)?|VERIFIED(_CHECK)?|AUDIO_BADGE)$/.test(n) || /verified/i.test(n);
        if (typeof n !== 'object') return false;
        for (const k in n) { if (k === 'browseEndpoint' || k === 'commandRuns') continue; if (isVerified(n[k], d + 1)) return true; }
        return false;
      };
      const gather = (n, out, d, cx) => {
        if (!n || typeof n !== 'object' || d > 40 || cx.seen.has(n) || ++cx.count > 8000) return;
        cx.seen.add(n);
        const add = (name, be) => {
          if (!name || !be || !UC.test(be.browseId || '') || out.some((c) => c.id === be.browseId && c.name === String(name).trim())) return;
          out.push({ name: String(name).trim(), id: be.browseId, path: be.canonicalBaseUrl || ('/channel/' + be.browseId) });
        };
        const brow = (x) => (x && (x.browseEndpoint || (x.innertubeCommand && x.innertubeCommand.browseEndpoint))) || null;
        // a popup list of channels
        const t = n.title;
        const tn = t && typeof t === 'object' ? (t.content || t.simpleText || (t.runs && t.runs.map((r) => r.text).join(''))) : '';
        if (tn && typeof tn === 'string') {
          // an entry with a title and a channel link somewhere inside it (the content script only uses names found in the byline)
          const find = (m, k) => { if (!m || typeof m !== 'object' || k > 12) return null; if (m.browseEndpoint && UC.test(m.browseEndpoint.browseId || '')) return m.browseEndpoint; for (const key in m) { const r = find(m[key], k + 1); if (r) return r; } return null; };
          const before = out.length;
          add(tn, find(n.rendererContext || n, 0));
          // the picture that sits in the same entry, so the content script can match pictures to names exactly
          if (out.length > before) {
            const pic = (m, k) => { if (!m || typeof m !== 'object' || k > 12) return ''; if (Array.isArray(m.sources) && m.sources[0] && typeof m.sources[0].url === 'string' && /ggpht|googleusercontent|ytimg/.test(m.sources[0].url)) return m.sources[0].url; for (const key in m) { const r = pic(m[key], k + 1); if (r) return r; } return ''; };
            const u = pic(n, 0);
            if (u) out[out.length - 1].img = u;
            // the channel's verification badge sits in the same entry
            if (isVerified(n, 0)) out[out.length - 1].verified = true;
          }
        }
        // runs: [{text, navigationEndpoint}]
        if (Array.isArray(n.runs)) n.runs.forEach((r) => { if (r && r.text && r.navigationEndpoint) add(r.text, brow(r.navigationEndpoint)); });
        // attributed text: {content, commandRuns:[{startIndex,length,onTap}]}
        if (typeof n.content === 'string' && Array.isArray(n.commandRuns)) n.commandRuns.forEach((r) => { if (r && r.onTap && typeof r.startIndex === 'number') add(n.content.substr(r.startIndex, r.length), brow(r.onTap)); });
        for (const k in n) gather(n[k], out, d + 1, cx);
      };
      let budget = 400;
      document.querySelectorAll(CARD).forEach((el) => {
        if (budget-- <= 0) return;
        const data = el.data || (el.__data && el.__data.data) || null;
        if (!data) { if (!el.hasAttribute('data-rt-cn')) el.setAttribute('data-rt-cn', 'nodata'); return; }
        if (ccSeen.get(el) === data) return;
        ccSeen.set(el, data);
        const out = [];
        const diag = [];
        // the card's own data first, then the data of the cards around it (on the home page the video data can sit on the wrapper)
        const sources = [data];
        for (let p = el.parentElement, i = 0; p && i < 3; p = p.parentElement, i++) {
          const pd = p.data || (p.__data && p.__data.data) || null;
          if (pd && typeof pd === 'object' && !sources.includes(pd)) sources.push(pd);
        }
        for (let si = 0; si < sources.length && new Set(out.map((c) => c.id)).size < 2; si++) {
          const src = sources[si];
          gather(src, out, 0, { seen: new WeakSet(), count: 0 });
          let js = '';
          try { js = JSON.stringify(src) || ''; } catch (err) { js = ''; }
          if (new Set(out.map((c) => c.id)).size < 2 && js) {
            // second way in, independent of how deep the list is buried: channel ids straight from the data text
            const re = /"browseId":"(UC[\w-]{20,})"/g;
            let m;
            while ((m = re.exec(js)) && out.length < 24) {
              const back = js.slice(Math.max(0, m.index - 900), m.index);
              const names = back.match(/"(?:content|simpleText|text)":"([^"]{1,80})"/g);
              const nm = names && names.length ? (/:"([^"]*)"$/.exec(names[names.length - 1]) || [])[1] : '';
              const cu = /"canonicalBaseUrl":"([^"]+)"/.exec(js.slice(m.index, m.index + 400));
              if (nm && !out.some((c) => c.id === m[1] && c.name === nm)) out.push({ name: nm.trim(), id: m[1], path: cu ? cu[1] : '/channel/' + m[1] });
            }
          }
          let keys = 0;
          try { keys = Object.keys(src).length; } catch (err) { keys = -1; }
          diag.push(si + ':' + (js.match(/"browseId":"UC[\w-]{20,}"/g) || []).length + '/' + js.length + '/k' + keys);
        }
        el.setAttribute('data-rt-bp', diag.join(' '));
        el.setAttribute('data-rt-cn', String(new Set(out.map((c) => c.id)).size));
        if (new Set(out.map((c) => c.id)).size >= 2) el.setAttribute('data-rt-cc', JSON.stringify(out.slice(0, 24)));
        else el.removeAttribute('data-rt-cc');
      });
    } catch (err) { /* leave cards as they are */ }
  });

  // --- player commands for ReTrapper (quality, volume, caption tracks) ---------
  window.addEventListener('rt-cmd', (e) => {
    let req;
    try { req = JSON.parse(e.detail); } catch (err) { return; }
    const reply = (ok, result) =>
      window.dispatchEvent(new CustomEvent('rt-cmd-result', { detail: JSON.stringify({ id: req.id, ok: !!ok, result: result === undefined ? null : result }) }));
    try {
      const p = document.getElementById('movie_player');
      if (!p) return reply(false, 'no-player');
      if (req.cmd === 'quality') {
        if (typeof p.setPlaybackQualityRange !== 'function') return reply(false, 'no-api');
        p.setPlaybackQualityRange(req.arg, req.arg);
        if (typeof p.setPlaybackQuality === 'function') p.setPlaybackQuality(req.arg);
        return reply(true, typeof p.getPlaybackQuality === 'function' ? p.getPlaybackQuality() : null);
      }
      if (req.cmd === 'getQuality') {
        return reply(true, typeof p.getPlaybackQuality === 'function' ? p.getPlaybackQuality() : null);
      }
      if (req.cmd === 'audioOriginal') {
        if (typeof p.getAvailableAudioTracks !== 'function' || typeof p.setAudioTrack !== 'function') return reply(false, 'no-api');
        const tracks = p.getAvailableAudioTracks() || [];
        const hit = tracks.find((t) => { try { return /original/i.test(JSON.stringify(t)); } catch (err) { return false; } });
        if (hit) { p.setAudioTrack(hit); return reply(true, 'set'); }
        return reply(true, 'none');
      }
      if (req.cmd === 'volume') {
        if (typeof p.setVolume !== 'function') return reply(false, 'no-api');
        p.setVolume(req.arg);
        return reply(true);
      }
      if (req.cmd === 'tracks') {
        const r = typeof p.getPlayerResponse === 'function' ? p.getPlayerResponse() : null;
        const t = r && r.captions && r.captions.playerCaptionsTracklistRenderer;
        const tracks = ((t && t.captionTracks) || []).map((x) => ({
          url: x.baseUrl, lang: x.languageCode, kind: x.kind || '',
          name: x.name && (x.name.simpleText || (x.name.runs && x.name.runs[0] && x.name.runs[0].text)) || ''
        }));
        const d = (r && r.videoDetails) || {};
        return reply(true, { tracks, title: d.title || '', id: d.videoId || '', length: +d.lengthSeconds || 0 });
      }
      reply(false, 'unknown-cmd');
    } catch (err) {
      reply(false, String(err));
    }
  });
})();
