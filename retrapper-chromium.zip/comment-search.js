// Search bar for the comments on a video page. Type words to find a comment, or @name to find
// comments written by that user. It filters the comments that have loaded so far.
(function () {
  'use strict';
  const RT = window.RT;
  if (!RT) return;
  const on = (t) => !!(RT.state && RT.state.tokens.has(t));
  const BOX = 'rt-csearch';
  let query = '';
  let lastVideo = '';

  // Same look as the channel search: a magnifier that opens into an underlined "Search" box.
  const CSS = '#' + BOX + '{display:inline-flex;align-items:center;flex:none;margin-left:8px;height:48px;vertical-align:middle;font-family:Roboto,Arial,sans-serif;color:var(--rtc-fg,inherit)}' +
    '#' + BOX + ' .rtc-ico{display:flex;align-items:center;justify-content:center;width:40px;height:40px;padding:0;border:0;border-radius:50%;background:transparent;color:inherit;cursor:pointer}' +
    '#' + BOX + ' .rtc-ico:hover{background:var(--rtc-chip,rgba(127,127,127,.15))}' +
    '#' + BOX + ' .rtc-ico svg{width:24px;height:24px;fill:currentColor}' +
    '#' + BOX + ' input{width:0;height:32px;padding:0;margin:0;border:0;border-bottom:1px solid transparent;border-radius:0;background:transparent;color:inherit;font:400 14px Roboto,Arial,sans-serif;outline:none;transition:width .2s}' +
    '#' + BOX + '[data-open="1"] input{width:200px;border-bottom-color:var(--rtc-sub,#909090)}' +
    '#' + BOX + ' input::placeholder{color:var(--rtc-sub,#888)}' +
    '#' + BOX + ' .rtc-x{display:none;width:28px;height:28px;padding:0;border:0;border-radius:50%;cursor:pointer;background:transparent;color:inherit;font:400 18px Roboto,Arial,sans-serif}' +
    '#' + BOX + '[data-open="1"][data-has="1"] .rtc-x{display:block}' +
    '#' + BOX + ' .rtc-n{white-space:nowrap;font-size:12px;margin-left:8px;color:var(--rtc-sub,#888)}';

  // Colours follow the page theme (the same palette the channel search uses).
  function pal() {
    const t = (RT.theme && RT.theme.theme) || (RT.detectTheme && RT.detectTheme().theme) || 'light';
    return t === 'dark'
      ? { fg: '#f1f1f1', sub: '#aaaaaa', chip: 'rgba(255,255,255,.1)' }
      : { fg: '#0f0f0f', sub: '#606060', chip: 'rgba(0,0,0,.05)' };
  }
  function paint() {
    const box = document.getElementById(BOX); if (!box) return;
    const p = pal();
    box.style.setProperty('--rtc-fg', p.fg); box.style.setProperty('--rtc-sub', p.sub); box.style.setProperty('--rtc-chip', p.chip);
  }
  RT.bus.addEventListener('theme', paint);
  function ensureStyle() {
    if (document.getElementById(BOX + '-style')) return;
    const st = document.createElement('style'); st.id = BOX + '-style'; st.textContent = CSS;
    (document.head || document.documentElement).appendChild(st);
  }
  const norm = (t) => (t || '').toLowerCase().replace(/\s+/g, ' ').trim();

  function authorsOf(thread) {
    const out = [];
    thread.querySelectorAll('#author-text, a[href^="/@"]').forEach((a) => {
      out.push(norm(a.textContent));
      const h = (a.getAttribute('href') || '').match(/\/(@[^/?#]+)/);
      if (h) out.push(norm(decodeURIComponent(h[1])));
    });
    return out.join(' | ');
  }
  function bodyOf(thread) {
    const out = [];
    thread.querySelectorAll('#content-text, yt-attributed-string#content-text').forEach((c) => out.push(norm(c.textContent)));
    return out.join(' | ');
  }
  function matches(thread, q) {
    if (q[0] === '@') {
      const name = q.slice(1).trim();
      if (!name) return true;
      const a = authorsOf(thread).replace(/@/g, '');
      return name.split(' ').every((w) => a.indexOf(w) >= 0);
    }
    const b = bodyOf(thread);
    return q.split(' ').every((w) => b.indexOf(w) >= 0);
  }

  function run() {
    const threads = document.querySelectorAll('ytd-comments ytd-comment-thread-renderer');
    const q = norm(query);
    let shown = 0;
    threads.forEach((t) => {
      const hide = !!q && !matches(t, q);
      RT.setHide(t, 'csearch', hide);
      if (!hide) shown++;
    });
    const n = document.querySelector('#' + BOX + ' .rtc-n');
    if (n) n.textContent = q ? (shown + ' of ' + threads.length + ' loaded comments' + (shown ? '' : ' match. Scroll down to load more.')) : '';
  }

  function mount() {
    const old = document.getElementById(BOX);
    if (!on('commentSearch') || location.pathname !== '/watch') {
      if (old) old.remove();
      document.querySelectorAll('[data-rt-h~="csearch"]').forEach((e) => RT.setHide(e, 'csearch', false));
      return;
    }
    const v = new URLSearchParams(location.search).get('v') || '';
    if (v !== lastVideo) { lastVideo = v; query = ''; if (old) old.remove(); }
    const header = document.querySelector('ytd-comments ytd-comments-header-renderer');
    if (!header) return;
    // Sits to the right of the "Sort by" button (ours if comment sorting replaced it, otherwise YouTube's).
    const anchor = document.getElementById('rt-comment-sort') || header.querySelector('#sort-menu');
    let box = document.getElementById(BOX);
    if (box && anchor && box.previousElementSibling === anchor) { paint(); run(); return; }
    if (box && !anchor && box.previousElementSibling === header) { run(); return; }
    ensureStyle();
    if (!box) {
      box = document.createElement('div'); box.id = BOX;
      const input = document.createElement('input');
      input.type = 'text'; input.placeholder = 'Search'; input.autocomplete = 'off'; input.spellcheck = false;
      input.title = 'Search the comments. Type words to find a comment, or @name to find comments by that user.';
      input.setAttribute('aria-label', 'Search comments'); input.value = query;
      const ico = document.createElement('button'); ico.type = 'button'; ico.className = 'rtc-ico'; ico.title = 'Search comments'; ico.setAttribute('aria-label', 'Search comments');
      ico.innerHTML = '<svg viewBox="0 0 24 24" focusable="false"><path d="m20.87 20.17-5.59-5.59A6.96 6.96 0 0 0 17 10c0-3.87-3.13-7-7-7s-7 3.13-7 7 3.13 7 7 7c1.66 0 3.18-.58 4.38-1.54l5.59 5.59.9-.88ZM10 16c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6Z"/></svg>';
      const x = document.createElement('button'); x.type = 'button'; x.className = 'rtc-x'; x.textContent = '\u00d7'; x.title = 'Clear search';
      const sync = () => { box.dataset.has = input.value ? '1' : ''; if (input.value) box.dataset.open = '1'; };
      ico.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); box.dataset.open = box.dataset.open === '1' && !input.value ? '' : '1'; if (box.dataset.open) input.focus(); });
      x.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); input.value = ''; query = ''; sync(); run(); input.focus(); });
      input.addEventListener('input', () => { query = input.value; sync(); run(); });
      input.addEventListener('focus', () => { box.dataset.open = '1'; });
      input.addEventListener('blur', () => { if (!input.value) box.dataset.open = ''; });
      input.addEventListener('keydown', (e) => { if (e.key === 'Escape') { input.value = ''; query = ''; sync(); run(); } e.stopPropagation(); }, true);
      ['keyup', 'keypress'].forEach((ev) => input.addEventListener(ev, (e) => e.stopPropagation(), true));
      const n = document.createElement('span'); n.className = 'rtc-n';
      box.append(ico, input, x, n);
      if (query) { box.dataset.open = '1'; box.dataset.has = '1'; }
    }
    if (anchor) anchor.after(box); else header.insertAdjacentElement('afterend', box);
    paint();
    run();
  }
  ['apply', 'dom', 'navigate'].forEach((ev) => RT.bus.addEventListener(ev, mount));
})();
