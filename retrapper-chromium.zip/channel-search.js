// Channel search replacement. Reads a channel's whole upload list once (and
// keeps it up to date), then searches it locally with a proper matcher, so a
// query behaves the way the main search page does: every word has to match,
// quoted phrases, -exclusions, typo tolerance, filters and sorting. It can
// also ask YouTube's own search for matches in descriptions and transcripts.
(function () {
  'use strict';
  const RT = window.RT;
  if (!RT) return;
  const on = (t) => !!(RT.state && RT.state.tokens.has(t));

  // ---- talking to the page bridge -------------------------------------------------------
  let seq = 0;
  const pending = new Map();
  window.addEventListener('rt-yt-res', (e) => {
    let r;
    try { r = JSON.parse(e.detail); } catch (err) { return; }
    const p = pending.get(r.id);
    if (p) { pending.delete(r.id); p(r); }
  });
  function yt(endpoint, body, kind) {
    return new Promise((resolve) => {
      const id = 'cs' + (++seq);
      pending.set(id, resolve);
      setTimeout(() => { if (pending.delete(id)) resolve({ error: 'timeout' }); }, 30000);
      window.dispatchEvent(new CustomEvent('rt-yt-req', { detail: JSON.stringify({ id, endpoint, body, kind }) }));
    });
  }

  // ---- helpers ----------------------------------------------------------------------------
  const UNIT = { s: 1, sec: 1, second: 1, m: 60, min: 60, minute: 60, h: 3600, hr: 3600, hour: 3600, d: 86400, day: 86400, w: 604800, wk: 604800, week: 604800, mo: 2592000, month: 2592000, y: 31536000, yr: 31536000, year: 31536000 };
  function agoSeconds(t) {
    const m = String(t || '').match(/(\d+)\s*(seconds?|secs?|minutes?|mins?|months?|mos?|hours?|hrs?|days?|weeks?|wks?|years?|yrs?|s|m|h|d|w|y)\b/i);
    if (!m) return null;
    const u = m[2].toLowerCase().replace(/s$/, '');
    return +m[1] * (UNIT[u] || UNIT[u.slice(0, 3)] || 0);
  }
  const durSeconds = (t) => String(t || '').split(':').reduce((a, x) => a * 60 + (+x || 0), 0);
  const fmtDur = (s) => {
    if (!s) return '';
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), ss = s % 60;
    return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(ss).padStart(2, '0');
  };
  const fmtViews = (n) => {
    if (!n) return '';
    try { return new Intl.NumberFormat(undefined, { notation: 'compact', maximumFractionDigits: 1 }).format(n) + ' views'; } catch (e) { return n + ' views'; }
  };
  function fmtAgo(ts) {
    if (!ts) return '';
    const s = Math.max(0, (Date.now() - ts) / 1000);
    const steps = [['year', 31536000], ['month', 2592000], ['week', 604800], ['day', 86400], ['hour', 3600], ['minute', 60]];
    for (const [n, v] of steps) if (s >= v) { const k = Math.floor(s / v); return k + ' ' + n + (k > 1 ? 's' : '') + ' ago'; }
    return 'just now';
  }
  const norm = (s) => String(s || '').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/['\u2019]/g, '');
  const words = (s) => norm(s).split(/[^a-z0-9\u0080-\uffff]+/).filter(Boolean);

  function lev(a, b, max) {
    if (Math.abs(a.length - b.length) > max) return max + 1;
    let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
    for (let i = 1; i <= a.length; i++) {
      const cur = [i];
      let min = i;
      for (let j = 1; j <= b.length; j++) {
        const v = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
        cur[j] = v; if (v < min) min = v;
      }
      if (min > max) return max + 1;
      prev = cur;
    }
    return prev[b.length];
  }

  // ---- storage ------------------------------------------------------------------------------
  function db() {
    return new Promise((ok, no) => {
      try {
        const r = indexedDB.open('rtChannelIndex', 1);
        r.onupgradeneeded = () => r.result.createObjectStore('idx', { keyPath: 'ch' });
        r.onsuccess = () => ok(r.result);
        r.onerror = () => no(r.error);
      } catch (e) { no(e); }
    });
  }
  async function dbGet(ch) {
    try { const d = await db(); return await new Promise((ok) => { const q = d.transaction('idx').objectStore('idx').get(ch); q.onsuccess = () => ok(q.result || null); q.onerror = () => ok(null); }); } catch (e) { return null; }
  }
  async function dbPut(rec) {
    try { const d = await db(); d.transaction('idx', 'readwrite').objectStore('idx').put(rec); } catch (e) { /* cache is optional */ }
  }

  // ---- the channel's video index --------------------------------------------------------
  const S = { ch: null, name: '', items: null, loading: false, status: '', token: 0, lastKey: '', lastUrlQuery: '' };

  async function identify() {
    const r = await yt(null, null, 'channel');
    let id = r && r.channelId, name = (r && r.name) || '';
    if (!/^UC[\w-]{22}$/.test(id || '')) {
      const c = document.querySelector('link[rel="canonical"]');
      const m = c && c.href.match(/channel\/(UC[\w-]{22})/);
      id = m ? m[1] : '';
    }
    return id ? { id, name } : null;
  }

  async function pull(playlist, type, known, incremental, progress) {
    const out = [];
    let r = await yt('browse', { browseId: 'VL' + playlist }, 'list');
    let pages = 0;
    while (r && !r.error) {
      const now = Date.now();
      const arr = (r.items || []).map((x, k) => {
        const ago = agoSeconds(x.ago);
        return { i: x.id, t: x.title, d: durSeconds(x.len), v: x.viewsN || 0, s: ago == null ? 0 : now - ago * 1000, y: type, n: out.length + k };
      });
      out.push(...arr);
      progress(arr.length);
      if (incremental && arr.length && arr.every((x) => known.has(x.i))) break;
      if (!r.cont || ++pages > 300) break;
      r = await yt('browse', { continuation: r.cont }, 'list');
    }
    return { out, error: r && r.error };
  }

  async function buildIndex(token) {
    const ch = S.ch;
    const cached = await dbGet(ch.id);
    const age = cached ? Date.now() - cached.ts : Infinity;
    if (cached && age < 10 * 60 * 1000) { S.items = cached.items; return; }
    const full = !cached || age > 14 * 86400 * 1000;
    const known = new Set(full ? [] : cached.items.map((x) => x.i));
    const rest = ch.id.slice(2);
    let count = 0;
    const progress = (n) => { count += n; if (token === S.token) { S.status = 'Indexing this channel\u2026 ' + count.toLocaleString() + ' videos'; render(); } };
    const [a, b, c] = await Promise.all([
      pull('UULF' + rest, 'v', known, !full, progress),
      pull('UUSH' + rest, 's', known, !full, progress),
      pull('UULV' + rest, 'l', known, !full, progress)
    ]);
    if (token !== S.token) return;
    const fresh = [...a.out, ...b.out, ...c.out];
    if (!fresh.length && !cached) { S.items = []; S.error = (a.error || 'no videos found'); return; }
    const map = new Map();
    if (!full) cached.items.forEach((x) => map.set(x.i, x));
    fresh.forEach((x) => map.set(x.i, x));
    const items = [...map.values()].sort((p, q) => (q.s - p.s) || (p.n - q.n));
    S.items = items;
    dbPut({ ch: ch.id, ts: Date.now(), items });
  }

  // ---- matching ---------------------------------------------------------------------------
  function parseQuery(q) {
    const terms = [], phrases = [], not = [];
    q.replace(/-"([^"]+)"|-(\S+)|"([^"]+)"|(\S+)/g, (m, a, b, c, d) => {
      if (a || b) not.push(norm(a || b));
      else if (c) phrases.push(norm(c));
      else if (d) terms.push(norm(d));
      return m;
    });
    return { terms, phrases, not };
  }

  function score(item, pq, fuzzy, any) {
    const title = norm(item.t);
    const ws = item._w || (item._w = words(item.t));
    for (const n of pq.not) if (title.includes(n)) return -1;
    let total = 0, hit = 0;
    for (const p of pq.phrases) { if (!title.includes(p)) return -1; total += 12; }
    for (const t of pq.terms) {
      let best = 0;
      for (const w of ws) {
        if (w === t) { best = 10; break; }
        if (w.startsWith(t)) best = Math.max(best, 7);
        else if (best < 4 && w.includes(t)) best = 4;
        else if (fuzzy && best < 3 && t.length >= 4 && lev(t, w, t.length >= 8 ? 2 : 1) <= (t.length >= 8 ? 2 : 1)) best = 3;
      }
      if (!best && title.includes(t)) best = 4;
      if (best) hit++;
      total += best;
    }
    if (pq.terms.length) {
      if (any ? hit < Math.ceil(pq.terms.length / 2) : hit < pq.terms.length) return -1;
      if (pq.terms.length > 1 && title.includes(pq.terms.join(' '))) total += 10;
      if (title.startsWith(pq.terms[0])) total += 3;
    }
    total += Math.max(0, 2 - ws.length / 12);
    return total;
  }

  const DATE_MS = { day: 86400e3, week: 7 * 86400e3, month: 31 * 86400e3, year: 366 * 86400e3 };
  function passes(x, f) {
    if (f.type !== 'all' && x.y !== f.type) return false;
    if (f.date !== 'any' && x.s && Date.now() - x.s > DATE_MS[f.date]) return false;
    if (f.dur !== 'any' && x.d) {
      if (f.dur === 'short' && x.d >= 240) return false;
      if (f.dur === 'mid' && (x.d < 240 || x.d > 1200)) return false;
      if (f.dur === 'long' && x.d <= 1200) return false;
    }
    return true;
  }

  function search(q, f) {
    const pq = parseQuery(q);
    const fuzzy = on('channelSearchFuzzy');
    const run = (any) => {
      const res = [];
      for (const x of S.items) {
        if (!passes(x, f)) continue;
        const sc = score(x, pq, fuzzy, any);
        if (sc >= 0) res.push({ x, sc });
      }
      return res;
    };
    let res = run(false), partial = false;
    if (!res.length && pq.terms.length > 1) { res = run(true); partial = res.length > 0; }
    return { res, partial, pq };
  }

  function order(list, f) {
    const by = {
      relevance: (a, b) => (b.sc - a.sc) || (b.x.s - a.x.s),
      new: (a, b) => (b.x.s - a.x.s) || (a.x.n - b.x.n),
      old: (a, b) => (a.x.s - b.x.s) || (b.x.n - a.x.n),
      views: (a, b) => b.x.v - a.x.v
    }[f.sort] || ((a, b) => b.sc - a.sc);
    return list.sort(by);
  }

  // Descriptions and transcripts: ask YouTube's own search and keep this channel's hits.
  async function deepSearch(q, token) {
    const hits = new Map();
    let r = await yt('search', { query: q + ' ' + S.name }, 'list');
    for (let p = 0; p < 3 && r && !r.error; p++) {
      (r.items || []).forEach((x, k) => { if (x.chId === S.ch.id && !hits.has(x.id)) hits.set(x.id, { snip: x.snip, rank: hits.size, item: x }); });
      if (!r.cont || token !== S.token) break;
      r = await yt('search', { continuation: r.cont }, 'list');
    }
    return hits;
  }

  // ---- UI ---------------------------------------------------------------------------------------
  const F = { sort: 'relevance', type: 'all', date: 'any', dur: 'any', view: '' };
  try { Object.assign(F, JSON.parse(localStorage.getItem('rtChSearch') || '{}')); } catch (e) { /* defaults */ }
  const view = { q: '', shown: 60, results: [], partial: false, deep: new Map(), deepFor: '', total: 0 };

    function pal() {
    const t = (RT.theme && RT.theme.theme) || (RT.detectTheme && RT.detectTheme().theme) || 'light';
    return t === 'dark'
      ? { fg: '#f1f1f1', sub: '#aaaaaa', bg: '#0f0f0f', chip: 'rgba(255,255,255,.1)', line: 'rgba(255,255,255,.25)', accent: '#3ea6ff' }
      : { fg: '#0f0f0f', sub: '#606060', bg: '#ffffff', chip: 'rgba(0,0,0,.05)', line: 'rgba(0,0,0,.25)', accent: '#065fd4' };
  }
  function paint() {
    if (!hostEl) return;
    const p = pal();
    [hostEl, barEl].forEach((el) => {
      if (!el) return;
      el.style.setProperty('--rtcs-fg', p.fg); el.style.setProperty('--rtcs-sub', p.sub); el.style.setProperty('--rtcs-bg', p.bg);
      el.style.setProperty('--rtcs-chip', p.chip); el.style.setProperty('--rtcs-line', p.line); el.style.setProperty('--rtcs-accent', p.accent);
    });
  }
  RT.bus.addEventListener('theme', paint);

  const CSS = `
#rt-chsearch{box-sizing:border-box;max-width:1284px;margin:12px auto 8px;padding:0 24px;font-family:Roboto,Arial,sans-serif;color:var(--rtcs-fg,#0f0f0f)}
#rt-cs-bar{display:inline-flex;align-items:center;flex:none;margin-left:8px;height:48px;vertical-align:middle;font-family:Roboto,Arial,sans-serif;color:var(--rtcs-fg,inherit)}
#rt-cs-bar .rtcs-ico{display:flex;align-items:center;justify-content:center;width:40px;height:40px;padding:0;border:0;border-radius:50%;background:transparent;color:inherit;cursor:pointer}
#rt-cs-bar .rtcs-ico:hover{background:var(--rtcs-chip,rgba(127,127,127,.15))}
#rt-cs-bar .rtcs-ico svg{width:24px;height:24px;fill:currentColor}
#rt-cs-bar input[type=text]{width:0;height:32px;padding:0;margin:0;border:0;border-bottom:1px solid transparent;border-radius:0;background:transparent;color:var(--rtcs-fg,inherit);font:400 14px Roboto,Arial,sans-serif;outline:none;transition:width .2s}
#rt-cs-bar[data-open="1"] input[type=text]{width:200px;border-bottom-color:var(--rtcs-line,#909090)}
#rt-cs-bar input[type=text]::placeholder{color:var(--rtcs-sub,#888)}
#rt-cs-bar button.rtcs-clear{display:none;width:28px;height:28px;padding:0;border:0;border-radius:50%;cursor:pointer;background:transparent;color:inherit;font:400 18px Roboto,Arial,sans-serif}
#rt-cs-bar[data-open="1"][data-has="1"] button.rtcs-clear{display:block}
#rt-cs-bar[data-block="1"]{display:flex;margin:12px 0 0;width:100%}
#rt-cs-bar[data-block="1"] input[type=text]{flex:1;width:auto}
#rt-chsearch .rtcs-grid{display:grid;gap:16px 16px}
#rt-chsearch .rtcs-grid .rtcs-card{flex-direction:column;gap:8px;margin:0}
#rt-chsearch .rtcs-grid .rtcs-thumb{width:100%}
#rt-chsearch .rtcs-grid .rtcs-title{font-size:15px;line-height:21px;max-height:42px}
#rt-chsearch .rtcs-grid .rtcs-snip{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
#rt-chsearch .rtcs-bar{display:none}
#rt-chsearch input[type=text]{flex:1;min-width:0;height:40px;padding:0 16px;border-radius:20px;border:1px solid var(--rtcs-line,#ccc);background:var(--rtcs-bg,transparent);color:inherit;font:400 16px Roboto,Arial,sans-serif;outline:none}
#rt-chsearch input[type=text]:focus{border-color:var(--rtcs-accent,#065fd4)}
#rt-chsearch button.rtcs-clear{height:40px;padding:0 14px;border-radius:20px;border:0;cursor:pointer;background:var(--rtcs-chip,rgba(127,127,127,.15));color:inherit;font:500 14px Roboto,Arial,sans-serif}
#rt-chsearch .rtcs-filters{display:flex;flex-wrap:wrap;gap:8px;margin:10px 0 4px}
#rt-chsearch select{height:32px;border-radius:16px;border:0;padding:0 10px;background:var(--rtcs-chip,rgba(127,127,127,.15));color:inherit;font:500 13px Roboto,Arial,sans-serif;cursor:pointer}
#rt-chsearch .rtcs-status{margin:8px 4px;font-size:13px;color:var(--rtcs-sub,#606060)}
#rt-chsearch .rtcs-card{display:flex;gap:16px;margin:12px 0;color:inherit;text-decoration:none;cursor:pointer}
#rt-chsearch .rtcs-thumb{position:relative;flex:none;width:246px;aspect-ratio:16/9;border-radius:12px;overflow:hidden;background:var(--yt-spec-10-percent-layer,#333)}
#rt-chsearch .rtcs-thumb img{width:100%;height:100%;object-fit:cover;display:block}
#rt-chsearch .rtcs-dur{position:absolute;right:4px;bottom:4px;padding:1px 4px;border-radius:4px;background:rgba(0,0,0,.8);color:#fff;font:500 12px Roboto,Arial,sans-serif}
#rt-chsearch .rtcs-title{font:400 18px/26px Roboto,Arial,sans-serif;max-height:52px;overflow:hidden}
#rt-chsearch .rtcs-meta{margin-top:4px;font-size:12px;color:var(--rtcs-sub,#606060)}
#rt-chsearch .rtcs-snip{margin-top:8px;font-size:12px;line-height:18px;color:var(--rtcs-sub,#606060)}
#rt-chsearch b{font-weight:700;color:var(--rtcs-fg,inherit)}
#rt-chsearch .rtcs-more{display:block;margin:16px auto;padding:8px 20px;border-radius:18px;border:0;cursor:pointer;background:var(--rtcs-chip,rgba(127,127,127,.15));color:inherit;font:500 14px Roboto,Arial,sans-serif}
ytd-browse.rt-cs-active ytd-two-column-browse-results-renderer{display:none !important}
@media (max-width:700px){#rt-chsearch .rtcs-thumb{width:160px}#rt-chsearch .rtcs-title{font-size:15px;line-height:21px}}
`;

  const viewMode = () => F.view || (on('channelSearchGrid') ? 'grid' : 'list');

  function opt(sel, value, list) {
    list.forEach(([v, l]) => { const o = document.createElement('option'); o.value = v; o.textContent = l; sel.appendChild(o); });
    sel.value = value;
  }

  let barEl = null, hostEl = null, inputEl = null, resultsEl = null, statusEl = null, moreTimer = 0;

  function build() {
    if (!document.getElementById('rt-chsearch-style')) {
      const st = document.createElement('style'); st.id = 'rt-chsearch-style'; st.textContent = CSS;
      (document.head || document.documentElement).appendChild(st);
    }
    hostEl = document.createElement('div');
    hostEl.id = 'rt-chsearch';
    barEl = document.createElement('div');
    barEl.id = 'rt-cs-bar';
    inputEl = document.createElement('input'); inputEl.type = 'text'; inputEl.placeholder = 'Search'; inputEl.title = 'Search this channel. Use "quotes" for an exact phrase and -word to exclude.'; inputEl.autocomplete = 'off'; inputEl.spellcheck = false;
    inputEl.setAttribute('aria-label', 'Search this channel');
    const clear = document.createElement('button'); clear.type = 'button'; clear.className = 'rtcs-clear'; clear.textContent = '\u00d7'; clear.title = 'Clear search';
    const ico = document.createElement('button'); ico.type = 'button'; ico.className = 'rtcs-ico'; ico.title = 'Search'; ico.setAttribute('aria-label', 'Search');
    ico.innerHTML = '<svg viewBox="0 0 24 24" focusable="false"><path d="m20.87 20.17-5.59-5.59A6.96 6.96 0 0 0 17 10c0-3.87-3.13-7-7-7s-7 3.13-7 7 3.13 7 7 7c1.66 0 3.18-.58 4.38-1.54l5.59 5.59.9-.88ZM10 16c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6Z"/></svg>';
    const sync = () => { barEl.dataset.has = inputEl.value ? '1' : ''; if (inputEl.value) barEl.dataset.open = '1'; };
    ico.addEventListener('click', () => { barEl.dataset.open = barEl.dataset.open === '1' && !inputEl.value ? '' : '1'; if (barEl.dataset.open) inputEl.focus(); });
    inputEl.addEventListener('input', sync);
    inputEl.addEventListener('focus', () => { barEl.dataset.open = '1'; });
    inputEl.addEventListener('blur', () => { if (!inputEl.value) barEl.dataset.open = ''; });
    barEl.append(ico, inputEl, clear);
    const filters = document.createElement('div'); filters.className = 'rtcs-filters';
    const mk = (key, list) => { const s = document.createElement('select'); opt(s, key === 'view' ? viewMode() : F[key], list); s.addEventListener('change', () => { F[key] = s.value; try { localStorage.setItem('rtChSearch', JSON.stringify(F)); } catch (e) { /* ignore */ } go(); }); filters.appendChild(s); };
    mk('sort', [['relevance', 'Sort by: Relevance'], ['new', 'Sort by: Upload date (newest)'], ['old', 'Sort by: Upload date (oldest)'], ['views', 'Sort by: View count']]);
    mk('type', [['all', 'Type: All'], ['v', 'Type: Videos'], ['s', 'Type: Shorts'], ['l', 'Type: Live streams']]);
    mk('date', [['any', 'Uploaded: Any time'], ['day', 'Last 24 hours'], ['week', 'This week'], ['month', 'This month'], ['year', 'This year']]);
    mk('view', [['list', 'View: List'], ['grid', 'View: Grid']]);
    mk('dur', [['any', 'Duration: Any'], ['short', 'Under 4 minutes'], ['mid', '4 - 20 minutes'], ['long', 'Over 20 minutes']]);
    statusEl = document.createElement('div'); statusEl.className = 'rtcs-status';
    resultsEl = document.createElement('div'); resultsEl.className = 'rtcs-results';
    hostEl.append(filters, statusEl, resultsEl);
    paint();
    let t = 0;
    inputEl.addEventListener('focus', () => { ensureIndex(); });
    inputEl.addEventListener('input', () => { clearTimeout(t); t = setTimeout(go, 220); });
    inputEl.addEventListener('keydown', (e) => { if (e.key === 'Enter') { clearTimeout(t); go(); } if (e.key === 'Escape') { inputEl.value = ''; sync(); go(); } e.stopPropagation(); }, true);
    ['keyup', 'keypress'].forEach((ev) => inputEl.addEventListener(ev, (e) => e.stopPropagation(), true));
    clear.addEventListener('click', () => { inputEl.value = ''; sync(); go(); inputEl.focus(); });
    resultsEl.addEventListener('click', (e) => {
      const a = e.target.closest('a.rtcs-card');
      if (!a || e.ctrlKey || e.metaKey || e.shiftKey || e.button) return;
      e.preventDefault();
      navigate(a.dataset.id, a.dataset.short === '1');
    });
  }

  function navigate(id, short) {
    const url = (short ? '/shorts/' : '/watch?v=') + id;
    const endpoint = short
      ? { commandMetadata: { webCommandMetadata: { url, webPageType: 'WEB_PAGE_TYPE_SHORTS', rootVe: 37414 } }, reelWatchEndpoint: { videoId: id } }
      : { commandMetadata: { webCommandMetadata: { url, webPageType: 'WEB_PAGE_TYPE_WATCH', rootVe: 3832 } }, watchEndpoint: { videoId: id } };
    window.dispatchEvent(new CustomEvent('watch-later-shelf-navigate', { detail: JSON.stringify({ endpoint }) }));
    setTimeout(() => { if (RT.page() === 'channel') location.assign(url); }, 1500);
  }

  // The row of tabs (Home / Videos / Playlists / Posts ...).
  function findStrip(b) {
    const tab = b.querySelector('yt-tab-shape, tp-yt-paper-tab');
    if (tab && tab.parentElement) return tab.parentElement;
    const a = b.querySelector('a[href$="/videos"], a[href*="/videos?"]');
    const t = a && (a.closest('yt-tab-shape, tp-yt-paper-tab') || a);
    return t && t.parentElement && t.parentElement.tagName !== 'YTD-BROWSE' ? t.parentElement : null;
  }

  // YouTube's own search tab/box is replaced by ours.
  function hideNative(b) {
    b.querySelectorAll('ytd-expandable-tab-renderer, [aria-label="Search" i], #search-icon, yt-tab-shape[tab-title="Search" i]').forEach((e) => {
      if (e.closest('#rt-cs-bar, #rt-chsearch')) return;
      const t = e.closest('yt-tab-shape, tp-yt-paper-tab, ytd-expandable-tab-renderer') || e;
      if (!(t.matches('ytd-expandable-tab-renderer, yt-tab-shape, tp-yt-paper-tab') || e.closest('yt-tab-group-shape, tp-yt-paper-tabs, #tabs-container'))) return;
      if (t.tagName === 'YTD-BROWSE' || t.contains(barEl)) return;
      if (t.style.display !== 'none') { t.style.display = 'none'; t.setAttribute('data-rt-cs-hid', '1'); }
    });
  }

  function place() {
    const b = document.querySelector('ytd-browse[page-subtype="channels"]');
    if (!b) return false;
    if (!hostEl) build();
    const strip = findStrip(b);
    if (strip) {
      if (barEl.parentElement !== strip || strip.lastElementChild !== barEl) strip.appendChild(barEl);
      barEl.removeAttribute('data-block');
      hideNative(b);
    } else {
      barEl.setAttribute('data-block', '1'); barEl.dataset.open = '1';
      if (barEl.parentElement !== hostEl) hostEl.insertBefore(barEl, hostEl.firstChild);
    }
    const active = !!view.q.trim();
    const anchor = b.querySelector('ytd-two-column-browse-results-renderer') || b.querySelector('#contents');
    if (anchor && anchor.parentElement) {
      if (hostEl.nextElementSibling !== anchor || hostEl.parentElement !== anchor.parentElement) anchor.parentElement.insertBefore(hostEl, anchor);
    } else if (hostEl.parentElement !== b) b.appendChild(hostEl);
    // With the box in the tab row, the results panel only shows while searching.
    hostEl.style.display = strip && !active ? 'none' : '';
    b.classList.toggle('rt-cs-active', active);
    return true;
  }

  function remove() {
    if (hostEl && hostEl.parentElement) hostEl.remove();
    if (barEl && barEl.parentElement) barEl.remove();
    document.querySelectorAll('[data-rt-cs-hid]').forEach((e) => { e.style.display = ''; e.removeAttribute('data-rt-cs-hid'); });
    document.querySelectorAll('ytd-browse.rt-cs-active').forEach((b) => b.classList.remove('rt-cs-active'));
  }

  function hl(el, text, pq) {
    const terms = [...pq.terms, ...pq.phrases].filter((t) => t.length > 1);
    if (!terms.length) { el.textContent = text; return; }
    const lower = norm(text);
    const marks = new Array(text.length).fill(false);
    if (lower.length === text.length) terms.forEach((t) => { let i = lower.indexOf(t); while (i >= 0) { for (let k = i; k < i + t.length; k++) marks[k] = true; i = lower.indexOf(t, i + 1); } });
    let cur = '', on_ = false;
    const flush = () => { if (!cur) return; if (on_) { const b = document.createElement('b'); b.textContent = cur; el.appendChild(b); } else el.appendChild(document.createTextNode(cur)); cur = ''; };
    for (let i = 0; i < text.length; i++) { if (marks[i] !== on_) { flush(); on_ = marks[i]; } cur += text[i]; }
    flush();
  }

  // Views, upload date (the exact date when "Show exact upload date" is on, like everywhere else), live badge.
  function metaText(x) {
    const exact = RT.dateOf ? RT.dateOf(x.i) : '';
    return [fmtViews(x.v), exact || fmtAgo(x.s), x.y === 'l' ? 'Live stream' : ''].filter(Boolean).join(' \u2022 ');
  }
  window.addEventListener('rt-dates-changed', () => {
    if (!resultsEl) return;
    resultsEl.querySelectorAll('.rtcs-meta[data-id]').forEach((m) => {
      const x = (S.items || []).find((i) => i.i === m.dataset.id);
      if (x) { const t = metaText(x); if (m.textContent !== t) m.textContent = t; }
    });
  });

  function card(r, pq) {
    const x = r.x;
    const a = document.createElement('a');
    a.className = 'rtcs-card';
    a.href = (x.y === 's' ? '/shorts/' : '/watch?v=') + x.i;
    a.dataset.id = x.i; a.dataset.short = x.y === 's' ? '1' : '0';
    const th = document.createElement('div'); th.className = 'rtcs-thumb';
    const img = document.createElement('img'); img.loading = 'lazy'; img.alt = ''; img.src = 'https://i.ytimg.com/vi/' + x.i + '/mqdefault.jpg';
    th.appendChild(img);
    if (x.y === 's' || x.d) { const d = document.createElement('span'); d.className = 'rtcs-dur'; d.textContent = x.y === 's' && !x.d ? 'SHORTS' : fmtDur(x.d); th.appendChild(d); }
    const info = document.createElement('div'); info.className = 'rtcs-info';
    const t = document.createElement('div'); t.className = 'rtcs-title'; hl(t, x.t, pq);
    const m = document.createElement('div'); m.className = 'rtcs-meta';
    m.dataset.id = x.i;
    m.textContent = metaText(x);
    info.append(t, m);
    // Video descriptions follow the "Hide video descriptions in search results" option.
    if (r.snip && !(RT.on && RT.on('hideSearchDescriptions'))) { const s = document.createElement('div'); s.className = 'rtcs-snip'; hl(s, r.snip, pq); info.appendChild(s); }
    a.append(th, info);
    return a;
  }

  function render() {
    if (!hostEl || !resultsEl) return;
    const q = view.q.trim();
    resultsEl.textContent = '';
    const grid = viewMode() === 'grid';
    resultsEl.className = 'rtcs-results' + (grid ? ' rtcs-grid' : '');
    const SS = (RT.state && RT.state.S) || {};
    const cols = Math.max(1, Math.min(7, +SS.channelSearchColumns || 4));
    resultsEl.style.gridTemplateColumns = grid ? (cols ? 'repeat(' + cols + ',minmax(0,1fr))' : 'repeat(auto-fill,minmax(240px,1fr))') : '';
    if (!q) { statusEl.textContent = S.loading ? S.status : ''; return; }
    if (S.error && !(S.items && S.items.length)) { statusEl.textContent = 'Could not read this channel\'s videos (' + S.error + ').'; return; }
    if (!S.items) { statusEl.textContent = S.status || 'Indexing this channel\u2026'; return; }
    const pq = parseQuery(q);
    const list = view.results.slice(0, view.shown);
    list.forEach((r) => resultsEl.appendChild(card(r, pq)));
    const total = view.results.length;
    statusEl.textContent = (total ? total.toLocaleString() + (view.partial ? ' partial matches' : ' results') : 'No results') + ' for \u201c' + q + '\u201d in ' + S.items.length.toLocaleString() + ' videos' + (S.loading ? ' \u00b7 ' + S.status : '') + (view.deepPending ? ' \u00b7 checking descriptions\u2026' : '');
    if (total > view.shown) {
      const more = document.createElement('button'); more.type = 'button'; more.className = 'rtcs-more'; more.textContent = 'Show more';
      more.addEventListener('click', () => { view.shown += 60; render(); });
      resultsEl.appendChild(more);
    }
  }

  function compute() {
    const q = view.q.trim();
    if (!q || !S.items) { view.results = []; return; }
    const { res, partial, pq } = search(q, F);
    const pq0 = pq;
    view.partial = partial;
    const byId = new Map(res.map((r) => [r.x.i, r]));
    if (view.deepFor === q && view.deep.size) {
      view.deep.forEach((h, id) => {
        let r = byId.get(id);
        if (r) { r.sc += 6 + Math.max(0, 6 - h.rank / 2); r.snip = h.snip; return; }
        const local = S.items.find((x) => x.i === id);
        if (!local && pq0.not.some((n) => norm(h.item.title).includes(n))) return;
        const x = local || { i: id, t: h.item.title, d: durSeconds(h.item.len), v: h.item.viewsN || 0, s: agoSeconds(h.item.ago) == null ? 0 : Date.now() - agoSeconds(h.item.ago) * 1000, y: h.item.short ? 's' : (h.item.live ? 'l' : 'v'), n: 1e9 };
        if (!passes(x, F)) return;
        r = { x, sc: 5 + Math.max(0, 6 - h.rank / 2), snip: h.snip };
        res.push(r); byId.set(id, r);
      });
    }
    view.results = order(res, F);
  }

  async function ensureIndex() {
    if (S.items || S.loading || !S.ch) return;
    S.loading = true; S.error = '';
    const token = S.token;
    S.status = 'Indexing this channel\u2026';
    try { await buildIndex(token); } catch (e) { S.error = String(e).slice(0, 80); }
    if (token !== S.token) return;
    S.loading = false; S.status = '';
    document.documentElement.dataset.rtChSearch = S.error ? 'error ' + S.error : 'ready ' + (S.items ? S.items.length : 0);
    go(true);
  }

  async function go(fromIndex) {
    view.q = inputEl ? inputEl.value : '';
    view.shown = 60;
    place();
    const q = view.q.trim();
    if (!q) { view.results = []; render(); return; }
    if (!S.items) { render(); ensureIndex(); return; }
    compute(); render();
    if (on('channelSearchDeep') && view.deepFor !== q && q.length > 1) {
      view.deepFor = q; view.deep = new Map(); view.deepPending = true;
      const token = S.token;
      const mine = q;
      setTimeout(async () => {
        if (view.q.trim() !== mine) return;
        const hits = await deepSearch(mine, token);
        if (token !== S.token || view.q.trim() !== mine) return;
        view.deep = hits; view.deepPending = false; compute(); render();
      }, 500);
    }
  }

  // ---- page integration ----------------------------------------------------------------------
  let identifying = false;
  async function tick() {
    if (!on('channelSearch') || RT.page() !== 'channel') { if (hostEl) { remove(); } return; }
    if (!place()) return;
    if (!S.ch && !identifying) {
      identifying = true;
      const ch = await identify();
      identifying = false;
      if (ch) { S.ch = ch; S.name = ch.name; if (view.q.trim() && !S.items) ensureIndex(); }
    }
    // A different channel than the one indexed: start over.
    const key = (location.pathname.match(/^\/(@[^/]+|(?:channel|c|user)\/[^/]+)/) || [''])[0];
    if (S.lastKey && S.lastKey !== key) {
      S.token++; S.items = null; S.ch = null; S.loading = false; S.error = '';
      view.q = ''; view.results = []; view.deepFor = ''; if (inputEl) inputEl.value = '';
      render(); place();
    }
    S.lastKey = key;
    // Switching to another channel tab leaves the search: clear it so the tab's own content shows.
    if (S.lastPath !== undefined && S.lastPath !== location.pathname && view.q.trim() && !/\/search$/.test(location.pathname)) clearSearch();
    S.lastPath = location.pathname;
    // /@channel/search?query=... (YouTube's own in-channel search page)
    const qp = new URLSearchParams(location.search).get('query');
    if (/\/search$/.test(location.pathname) && qp && qp !== S.lastUrlQuery && inputEl) {
      S.lastUrlQuery = qp; inputEl.value = qp; go();
    }
  }

  function clearSearch() {
    view.q = ''; view.results = []; view.deepFor = ''; view.deepPending = false;
    if (inputEl) inputEl.value = '';
    if (barEl && !barEl.hasAttribute('data-block')) { barEl.dataset.has = ''; barEl.dataset.open = ''; }
    try { render(); place(); } catch (e) {}
  }

  document.addEventListener('click', (e) => {
    if (on('channelSearch') && RT.page() === 'channel' && e.target.closest && view.q.trim()) {
      const tab = e.target.closest('ytd-browse yt-tab-shape, ytd-browse tp-yt-paper-tab');
      if (tab && !tab.closest('#rt-cs-bar, #rt-chsearch') && !tab.matches('[tab-title="Search" i], ytd-expandable-tab-renderer')) clearSearch();
    }
    if (!on('channelSearch') || RT.page() !== 'channel' || !e.target.closest) return;
    const t = e.target.closest('ytd-browse [aria-label="Search" i], ytd-browse #search-icon, ytd-browse yt-tab-shape[tab-title="Search" i], ytd-browse ytd-expandable-tab-renderer');
    if (t && !t.closest('#rt-chsearch') && inputEl) { e.preventDefault(); e.stopPropagation(); inputEl.focus(); inputEl.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
  }, true);

  ['apply', 'dom', 'navigate'].forEach((ev) => RT.bus.addEventListener(ev, () => { tick(); }));
  RT.bus.addEventListener('apply', () => { try { render(); } catch (e) {} });
  document.addEventListener('yt-navigate-finish', () => setTimeout(tick, 400));
  setInterval(tick, 2000);
})();
