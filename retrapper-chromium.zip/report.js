// ReTrapper Bug Report: builds a diagnostic report about the current YouTube page and the
// ReTrapper features on it. The report is shown to the user first and only leaves the browser
// if they copy it or save it themselves. Nothing is uploaded.
(function () {
  'use strict';
  const TOOL_VERSION = 'built into ReTrapper 3.41.48';

  // ---- capture page errors from the moment the page starts --------------------------------
  const errors = window.__rtBugReportErrors || [];
  const addErr = (kind, msg, src) => { if (errors.length < 25) errors.push({ kind, msg: String(msg).slice(0, 300), src: String(src || '').replace(/^chrome-extension:\/\/[a-p]{32}\//, 'ext:/').slice(0, 120), t: Math.round(performance.now()) }); };
  if (!window.__rtBugReportErrors) {
  window.__rtBugReportErrors = errors;
  window.addEventListener('error', (e) => { if (!e.message) return; addErr('error', e.message, e.filename + ':' + e.lineno); }, true);
  window.addEventListener('unhandledrejection', (e) => addErr('promise', (e.reason && (e.reason.stack || e.reason.message)) || e.reason, ''));
  const ce = console.error;
  console.error = function () { try { addErr('console', [].map.call(arguments, (a) => (a && a.message) || String(a)).join(' '), ''); } catch (e) { /* ignore */ } return ce.apply(this, arguments); };
  }

  // ---- anonymising helpers ------------------------------------------------------------------
  // Dates, view counts, durations and "x ago" text are what we debug, so they stay readable.
  const KEEP_TEXT = /^[\d\s.,:\/\-+%KMB\u2022\u00b7]+$|\b(ago|views?|watching|waiting|subscribers?|likes?|comments?|replies|reply|Streamed|Premiered|Premieres|Live|Shorts?|Today|Yesterday)\b|\b(19|20)\d{2}\b|^\d{1,2}:\d{2}/i;
  const mask = (t) => t.replace(/[A-Za-z\u00c0-\uffe0]/g, 'x').replace(/\d/g, '9');
  const anonText = (t, on) => (!on || KEEP_TEXT.test(t.trim()) ? t : mask(t));
  const anonHref = (h) => h
    .replace(/([?&]v=)[\w-]{6,}/g, '$1<id>').replace(/([?&](?:list|lc|pp|si|t)=)[^&#]*/g, '$1<x>')
    .replace(/\/@[^/?#]+/g, '/@<handle>').replace(/\/(channel|c|user)\/[^/?#]+/g, '/$1/<id>')
    .replace(/\/(shorts|live|embed)\/[\w-]+/g, '/$1/<id>').replace(/([?&](?:search_query|query)=)[^&#]*/g, '$1<q>');
  const safe = (fn, d) => { try { return fn(); } catch (e) { return d === undefined ? 'failed: ' + e : d; } };
  const KEEP_ATTR = new Set(['class', 'id', 'href', 'role', 'is-active', 'page-subtype', 'aria-label', 'hidden', 'data-rt-orig', 'data-rt-cols', 'data-rt-short', 'data-rt-h', 'data-rt-m', 'data-rt-quiet']);

  // Markup snapshot built by walking the live DOM (no HTML parsing or cloning: YouTube enforces
  // Trusted Types and its custom elements can throw when cloned).
  const SKIP = new Set(['SVG', 'IMG', 'YT-IMG-SHADOW', 'STYLE', 'SCRIPT', 'YTD-THUMBNAIL', 'YT-THUMBNAIL-VIEW-MODEL', 'YT-ICON', 'BUTTON-VIEW-MODEL', 'YTD-MENU-RENDERER', 'YTD-THUMBNAIL-OVERLAY-TIME-STATUS-RENDERER', 'CANVAS', 'VIDEO', 'NOSCRIPT']);
  function markup(el, max, anon) {
    if (!el) return null;
    return safe(() => {
      let out = '';
      const walk = (n, depth) => {
        if (out.length > max || depth > 14) return;
        if (n.nodeType === 3) { const t = n.nodeValue.replace(/\s+/g, ' ').trim(); if (t) out += anonText(t, anon); return; }
        if (n.nodeType !== 1 || SKIP.has(n.tagName.toUpperCase())) return;
        const tag = n.tagName.toLowerCase();
        let attrs = '';
        for (const a of n.attributes) {
          if (!KEEP_ATTR.has(a.name)) continue;
          let v = a.value;
          if (a.name === 'href') v = anonHref(v).slice(0, 60);
          else if (a.name === 'aria-label') v = anonText(v, anon).slice(0, 80);
          else if (a.name === 'class') v = v.slice(0, 160);
          attrs += ' ' + a.name + '="' + v.replace(/"/g, "'") + '"';
        }
        out += '<' + tag + attrs + '>';
        for (let c = n.firstChild; c; c = c.nextSibling) walk(c, depth + 1);
        out += '</' + tag + '>';
      };
      walk(el, 0);
      return out.slice(0, max);
    });
  }

  const D = () => document.documentElement;
  const q = (s, r) => (r || document).querySelector(s);
  const qa = (s, r) => [...(r || document).querySelectorAll(s)];
  const vis = (e) => { const r = e.getBoundingClientRect(); return r.width > 4 && r.height > 4 && getComputedStyle(e).visibility !== 'hidden'; };
  const desc = (e) => e ? e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') : null;

  function pageKind() {
    const p = location.pathname;
    if (p === '/') return 'home';
    if (p.startsWith('/watch')) return 'watch';
    if (p.startsWith('/shorts')) return 'shorts';
    if (p.startsWith('/results')) return 'search';
    if (p.startsWith('/feed/subscriptions')) return 'subscriptions';
    if (p.startsWith('/playlist')) return 'playlist';
    if (/^\/(@|channel\/|c\/|user\/)/.test(p)) return 'channel';
    return 'other:' + p.split('/')[1];
  }

  // ---- sections -------------------------------------------------------------------------------
  function environment() {
    return {
      reportTool: TOOL_VERSION,
      time: new Date().toISOString(), tzOffsetMin: new Date().getTimezoneOffset(),
      page: pageKind(), browseSubtype: (q('ytd-browse') || {}).getAttribute ? q('ytd-browse:not([hidden])') && q('ytd-browse:not([hidden])').getAttribute('page-subtype') : null,
      path: anonHref(location.pathname + location.search).slice(0, 80),
      userAgent: navigator.userAgent, language: navigator.language,
      viewport: innerWidth + 'x' + innerHeight, dpr: devicePixelRatio, zoomApprox: Math.round((outerWidth / innerWidth) * 100) / 100,
      ytDarkTheme: D().hasAttribute('dark'), signedIn: !!q('#avatar-btn, ytd-topbar-menu-button-renderer #avatar-btn, button#avatar-btn')
    };
  }
  function retrapper() {
    const attrs = {};
    [...D().attributes].filter((a) => /^data-rt/.test(a.name)).forEach((a) => { attrs[a.name] = a.value.slice(0, 1500); });
    return {
      detected: !!D().dataset.rtVersion, version: D().dataset.rtVersion || null,
      htmlAttributes: attrs,
      injected: ['rt-style', 'rt-dyn-style', 'rt-comment-sort', 'rt-cs-bar', 'rt-chsearch', 'rt-short-date', 'rt-gate', 'rt-time-badge', 'rt-page-filter', 'watch-later-shelf-section'].filter((id) => document.getElementById(id)),
      datesReplaced: qa('[data-rt-orig]').length
    };
  }
  const histogram = (els) => { const h = {}; els.forEach((e) => { const k = typeof e === 'string' ? e : e && e.tagName ? e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') : 'null'; h[k] = (h[k] || 0) + 1; }); return h; };
  function grid(opt) {
    const g = q('ytd-browse:not([hidden]) ytd-rich-grid-renderer') || q('ytd-rich-grid-renderer');
    if (!g) return { present: false };
    const c = q('#contents', g);
    const items = qa('ytd-rich-item-renderer', g);
    const shown = items.filter(vis);
    const rows = {};
    shown.forEach((e) => { const r = e.getBoundingClientRect(); const k = Math.round(r.top / 8); (rows[k] = rows[k] || []).push(Math.round(r.left)); });
    const perRow = Object.keys(rows).sort((a, b) => a - b).map((k) => rows[k].length);
    const xs = new Set(Object.values(rows).flat().map((x) => Math.round(x / 6)));
    return {
      present: true, itemsPerRowVar: getComputedStyle(g).getPropertyValue('--ytd-rich-grid-items-per-row').trim(),
      customCols: g.hasAttribute('data-rt-cols'), contentsDisplay: c && getComputedStyle(c).display, gridColumns: c && getComputedStyle(c).gridTemplateColumns,
      items: items.length, visible: shown.length, hiddenItems: items.length - shown.length, perRow: perRow.slice(0, 12), distinctColumnStarts: xs.size,
      even: perRow.length > 1 ? perRow.slice(0, -1).every((n) => n === perRow[0]) : null,
      rowElements: qa('ytd-rich-grid-row', g).length,
      contentsChildren: c ? histogram([...c.children]) : null,
      firstChildChildren: c && c.children[0] ? { tag: c.children[0].tagName.toLowerCase(), kids: histogram([...c.children[0].children]), display: getComputedStyle(c.children[0]).display } : null,
      itemParents: histogram(items.map((e) => e.parentElement)),
      itemWidths: shown.slice(0, 6).map((e) => Math.round(e.getBoundingClientRect().width)),
      hiddenDetail: items.filter((e) => !vis(e)).slice(0, 60).map((e) => {
        const a = e.querySelector('a[href^="/@"], a[href^="/channel/"]');
        const t = e.querySelector('#video-title, .ytLockupMetadataViewModelTitle, h3');
        const txt = (e.textContent || '').toLowerCase();
        return {
          reasons: e.getAttribute('data-rt-h') || (getComputedStyle(e).display === 'none' ? 'display:none, no ReTrapper reason (hidden by YouTube or another extension)' : 'zero-size'),
          why: e.getAttribute('data-rt-why') || null, watchedPct: e.getAttribute('data-rt-wp') || null,
          channel: a ? anonText(a.textContent.trim(), opt.mask) : null, title: t ? anonText(t.textContent.trim(), opt.mask) : null,
          textHas: ['members only', 'premieres', 'scheduled for', 'upcoming', 'live'].filter((w) => new RegExp('\\b' + w + '\\b').test(txt)),
          liveBadge: !!e.querySelector('[overlay-style="LIVE"], .badge-style-type-live-now'),
          dataRtAttrOnCard: [...e.attributes].filter((x) => /^data-rt/.test(x.name)).map((x) => x.name + '=' + x.value).join(' ')
        };
      }),
      sections: c ? [...c.children].filter((e) => e.tagName === 'YTD-RICH-SECTION-RENDERER').slice(0, 8).map((e) => {
        const h = e.querySelector('#title-text, #title, h2'), cs = getComputedStyle(e);
        return { display: cs.display, height: Math.round(e.getBoundingClientRect().height), title: h ? anonText(h.textContent.trim(), opt.mask) : null,
          videoLinks: e.querySelectorAll('a[href*="/watch?v="]').length, rtAttrs: [...e.attributes].filter((x) => /^data-rt/.test(x.name)).map((x) => x.name + '=' + x.value).join(' '),
          attrs: [...e.attributes].filter((x) => !/^data-rt|^class$|^style$/.test(x.name)).map((x) => x.name).join(' ') };
      }) : null,
      hiddenBy: histogram(items.filter((e) => !vis(e)).map((e) => getComputedStyle(e).display === 'none' ? 'display:none' : 'zero-size')),
      contentsMarkup: markup(c && c.children[0], 1800, true),
      zeroSize: items.filter((e) => !vis(e) && getComputedStyle(e).display !== 'none').slice(0, 4).map((e) => { const r = e.getBoundingClientRect(), cs = getComputedStyle(e); return { display: cs.display, visibility: cs.visibility, position: cs.position, rect: [Math.round(r.width), Math.round(r.height)], gridColumn: cs.gridColumnStart, attrs: [...e.attributes].map((a) => a.name).join(' ').slice(0, 120), inner: markup(e, 500, true) }; })
    };
  }
  function shelf() {
    const s = document.getElementById('watch-later-shelf-section');
    if (!s) return { present: false, onHomePage: pageKind() === 'home' };
    const h = q('[role=heading]', s), r = s.getBoundingClientRect(), hr = h && h.getBoundingClientRect();
    return {
      present: true, parent: desc(s.parentElement), rect: [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)],
      heading: h ? { text: anonText(h.textContent, false), rect: hr && [Math.round(hr.left), Math.round(hr.top), Math.round(hr.width), Math.round(hr.height)], color: getComputedStyle(q('a', h) || h).color, zIndex: getComputedStyle(h).zIndex } : null,
      status: q('p', s) ? q('p', s).textContent.slice(0, 80) : null, cards: qa('.wls-card', s).length, textOnlyCards: qa('.wls-card', s).filter((c) => !q('img', c)).length,
      layout: qa('.wls-card', s).length ? (getComputedStyle(q('.wls-card', s).parentElement).flexWrap === 'wrap' ? 'grid' : 'scroll') : null,
      pageBackground: getComputedStyle(document.body).backgroundColor
    };
  }
  function dates() {
    const cards = qa('ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer, ytd-compact-video-renderer, yt-lockup-view-model').filter((c) => q('a[href*="/watch?v="]', c));
    const FULL = /(?<!\d)\d{2}\/\d{2}\/\d{4}(?!\d)/;
    const withFull = cards.filter((c) => FULL.test(c.textContent));
    const withTime = cards.filter((c) => /(?<!\d)\d{2}\/\d{2}\/\d{4} \d{2}:\d{2}/.test(c.textContent));
    const missing = cards.filter((c) => !FULL.test(c.textContent)).slice(0, 2);
    return {
      cards: cards.length, withFullDate: withFull.length, withTime: withTime.length, missing: cards.length - withFull.length,
      cache: safe(() => Object.keys(JSON.parse(localStorage.getItem('rtDates') || '{}')).length, null),
      info: D().dataset.rtDatesInfo || null, state: D().dataset.rtDates || null,
      missingSamples: missing.map((c) => ({ tag: c.tagName.toLowerCase(), html: markup(c, 2500, true) }))
    };
  }
  function comments() {
    const root = q('ytd-comments');
    if (!root) return { present: false };
    const threads = qa('ytd-comment-thread-renderer', root);
    const chip = document.getElementById('rt-comment-sort');
    return {
      present: true, threads: threads.length, sortChip: !!chip, sortChipText: chip && chip.textContent.trim().slice(0, 40),
      nativeSortMenuHidden: (() => { const m = q('#sort-menu', root); return m ? getComputedStyle(m).display === 'none' : null; })(),
      pinned: threads.filter((t) => q('ytd-pinned-comment-badge-renderer, #pinned-comment-badge', t) && vis(q('ytd-pinned-comment-badge-renderer, #pinned-comment-badge', t))).length,
      orderValues: threads.slice(0, 6).map((t) => getComputedStyle(t).order)
    };
  }
  function searchPage(anon) {
    if (!location.pathname.startsWith('/results')) return { applicable: false };
    const sl = q('ytd-search ytd-section-list-renderer > #contents');
    const secs = sl ? [...sl.children].slice(0, 12).map((c) => ({
      tag: c.tagName.toLowerCase(), order: getComputedStyle(c).order,
      kids: [...((c.querySelector('#contents') || c).children)].slice(0, 6).map((k) => k.tagName.toLowerCase() + ':' + getComputedStyle(k).order)
    })) : [];
    const chans = qa('ytd-search ytd-channel-renderer, ytd-search yt-lockup-view-model:has(a[href^="/@"])').slice(0, 3).map((e) => markup(e, 700, anon));
    const ai = qa('ytd-search *').filter((e) => /\bai\b|ai-|aisummary|genai|overview|summary/i.test((e.className && e.className.baseVal === undefined ? e.className : '') + ' ' + e.tagName)).slice(0, 8)
      .map((e) => ({ tag: e.tagName.toLowerCase(), cls: String(e.className).slice(0, 80), shown: e.getBoundingClientRect().height > 0, html: markup(e, 600, anon) }));
    const prog = qa('ytd-search [class*="rogress" i], ytd-search [class*="atched" i], ytd-search ytd-thumbnail-overlay-resume-playback-renderer').slice(0, 6)
      .map((e) => ({ tag: e.tagName.toLowerCase(), cls: String(e.className).slice(0, 100), style: (e.getAttribute('style') || '').slice(0, 60), text: (e.textContent || '').trim().slice(0, 20), html: markup(e, 400, anon) }));
    const cards = qa('ytd-search yt-lockup-view-model, ytd-search ytd-video-renderer');
    const hidden = cards.filter((c) => c.hasAttribute('data-rt-h')).length;
    const vcard = q('ytd-search ytd-video-renderer');
    const ccard = q('#rt-chan-row > *') || q('ytd-search ytd-channel-renderer');
    return { applicable: true, videoCardMarkup: markup(vcard, 3500, anon), channelCardMarkup: markup(ccard, 3500, anon), channelCardRect: ccard ? (({ width, height }) => [Math.round(width), Math.round(height)])(ccard.getBoundingClientRect()) : null, cardCount: cards.length, hiddenByRetrapper: hidden, progressElements: prog, sections: secs, channelMarkup: chans, aiCandidates: ai };
  }
  function channelSearch() {
    const bar = document.getElementById('rt-cs-bar'), host = document.getElementById('rt-chsearch');
    if (pageKind() !== 'channel') return { applicable: false };
    const strip = q('yt-tab-group-shape, tp-yt-paper-tabs');
    return {
      applicable: true, flag: D().dataset.rtChSearch || null, bar: !!bar, barParent: bar && desc(bar.parentElement), barOpen: bar && bar.dataset.open || null,
      host: !!host, hostDisplay: host && getComputedStyle(host).display, results: host ? qa('.rtcs-card', host).length : 0,
      tabStrip: desc(strip), tabs: qa('yt-tab-shape').length, nativeSearchTabHidden: qa('[data-rt-cs-hid]').length,
      tabStripMarkup: markup(strip, 1800, true)
    };
  }
  function thumbs() {
    const t = qa('ytd-thumbnail, yt-thumbnail-view-model').filter((e) => e.getBoundingClientRect().width > 20);
    return { visibleThumbnails: t.length, thumbsHideTokenOn: /\bthumbsHideAll\b/.test(D().getAttribute('data-rt') || '') };
  }
  function autoplay() {
    const out = [];
    qa('video').forEach((v) => {
      if (v.paused) return;
      const inPlayer = !!v.closest('#movie_player, ytd-player, ytd-reel-video-renderer, ytd-shorts');
      if (!inPlayer) out.push({ muted: v.muted, parent: desc(v.parentElement), within: desc(v.closest('ytd-rich-item-renderer, ytd-thumbnail, ytd-video-preview, yt-thumbnail-view-model, ytd-rich-grid-renderer')) });
    });
    return { playingOutsidePlayer: out.length, details: out.slice(0, 4) };
  }
  function collabInfo(anon) {
    const CARD = 'yt-lockup-view-model, ytd-video-renderer, ytd-compact-video-renderer, ytd-grid-video-renderer, ytd-rich-grid-media, ytd-playlist-video-renderer';
    const found = qa('[data-rt-cc]');
    const by = (c) => qa('#attributed-channel-name', c).find((e) => !e.closest('[hidden]')) || q('#attributed-channel-name', c) || q('yt-content-metadata-view-model', c) || q('ytd-channel-name:not([hidden]), #byline-container, #metadata', c) || c;
    // cards whose byline looks like a list of channels but that were not recognised
    const looks = qa(CARD).filter((c) => !c.hasAttribute('data-rt-cc') && !q('a[data-rt-collab]', c)).filter((c) => { const t = (by(c).textContent || '').replace(/\s+/g, ' '); return /\d+\s+more\b/i.test(t) || /\S\s+and\s+\S/.test((q('ytd-channel-name, #channel-name, .ytContentMetadataViewModelMetadataText', c) || {}).textContent || ''); });
    return {
      scriptCards: qa(CARD).length, subs: document.documentElement.getAttribute('data-rt-subs'),
      recognised: found.length,
      linked: found.filter((c) => q('a[data-rt-collab]', c)).length,
      recognisedSample: found.slice(0, 2).map((c) => ({ channels: (c.getAttribute('data-rt-cc') || '').length, markup: markup(by(c), 2000, anon) })),
      // every visible card: its byline and what the page data held, so a collab that was missed can be seen
      visibleCards: qa(CARD).filter((c) => { const b = c.getBoundingClientRect(); return b.width > 0 && b.height > 0 && !c.closest('ytd-ad-slot-renderer'); }).slice(0, 24).map((c) => {
        const t = ((q('#video-title, h3, .ytLockupMetadataViewModelTitle', c) || {}).textContent || '').replace(/\s+/g, ' ').trim().slice(0, 70);
        const bl = (by(c).textContent || '').replace(/\s+/g, ' ').trim().slice(0, 120);
        const row = { tag: c.localName, channelsInData: c.getAttribute('data-rt-cn'), idsInDataText: c.getAttribute('data-rt-bp'), linked: !!q('a[data-rt-collab]', c), bylineShown: qa('#attributed-channel-name', c).filter((e) => !e.closest('[hidden]')).length };
        const st = q('yt-avatar-stack-view-model', c);
        if (st) { row.stack = { imgs: qa('img', st).length, withSrc: qa('img', st).filter((i) => i.src).length, hidden: st.style.display === 'none', pictures: qa('img[data-rt-collab-img]', c).length, done: c.hasAttribute('data-rt-cpic'), how: c.getAttribute('data-rt-pichow'), cc: (c.getAttribute('data-rt-cc') || '').replace(/https?:\/\/[^"]{0,200}/g, (u) => u.slice(0, 60)).slice(0, 700) }; row.label = (() => { const l = q('.cloned-channel-name', c.closest('ytd-rich-item-renderer, ytd-video-renderer') || c); return l ? { html: l.outerHTML.slice(0, 400), sub: l.getAttribute('data-rt-subnames') } : null; })(); row.outside = qa('*', c.closest('ytd-rich-item-renderer, ytd-video-renderer') || c).filter((e) => !e.children.length && !e.closest('yt-content-metadata-view-model, h3, yt-avatar-stack-view-model') && /\d+K|ago|\d{2}\/\d{2}\/\d{4}/.test(e.textContent || '')).slice(0, 4).map((e) => e.tagName.toLowerCase() + '.' + String(e.className || '').slice(0, 40) + ' hid=' + e.hasAttribute('data-rt-nolabel') + ' ' + (e.textContent || '').trim().slice(0, 50)); if (row.linked) row.stackMarkup = markup(st, 1200, anon); }
        if (!anon) { row.title = t; row.byline = bl; }
        if (/\band\b|\bmore\b|,|&/i.test(bl)) row.markup = markup(by(c), 1800, anon);
        return row;
      }),
      notRecognised: looks.length,
      notRecognisedSample: looks.slice(0, 2).map((c) => markup(by(c), 2000, anon))
    };
  }
  function watchInfo(anon) {
    const info = q('ytd-watch-metadata');
    if (!info) return null;
    const DATE = /\bago\b|\b(19|20)\d{2}\b|^(streamed|premiered)/i;
    return {
      expanded: !!q('ytd-text-inline-expander[is-expanded], ytd-text-inline-expander[expanded]', info),
      infoLine: markup(q('ytd-watch-info-text', info), 2500, anon),
      owner: markup(q('ytd-watch-metadata ytd-video-owner-renderer') || q('ytd-video-owner-renderer'), 3500, anon),
      dateLikeText: qa('*', info).filter((e) => !e.children.length && e.textContent.trim().length < 60 && DATE.test(e.textContent.trim())).slice(0, 6).map((e) => e.textContent.trim()),
      likeButtons: qa('like-button-view-model button, dislike-button-view-model button, #segmented-like-button button, #segmented-dislike-button button').slice(0, 3).map((b) => (b.getAttribute('aria-label') || '').replace(/[A-Za-z]+(?=\s*$)/, (w) => w).slice(0, 60)),
      votes: (function () {
        const mk = (sel) => qa(sel).slice(0, 2).map((b) => markup(b, 1500, anon));
        return {
          status: document.documentElement.getAttribute('data-rt-votes'),
          ownLike: qa('.rt-like-count').map((e) => e.textContent),
          ownDislike: qa('.rt-dislike-count').map((e) => e.textContent),
          likeMarkup: mk('ytd-watch-flexy like-button-view-model, ytd-watch-flexy #segmented-like-button'),
          dislikeMarkup: mk('ytd-watch-flexy dislike-button-view-model, ytd-watch-flexy #segmented-dislike-button')
        };
      })(),
      dislikeEl: qa('[class*="dislike" i]').filter((e) => /\d/.test(e.textContent) && e.textContent.length < 12).length,
      player: (() => { const f = document.querySelector('ytd-watch-flexy'), b = document.querySelector('.ytp-size-button'); return { flexy: !!f, theater: !!f && (f.hasAttribute('theater') || f.theater === true), fullscreen: !!f && f.hasAttribute('fullscreen'), sizeButton: !!b, sizeButtonVisible: !!b && b.offsetParent !== null, sizeButtonTitle: b ? (b.getAttribute('data-title-no-tooltip') || b.getAttribute('aria-label') || b.title || '').slice(0, 40) : '' }; })()
    };
  }
  async function wlProbe() {
    try {
      const res = await fetch('/playlist?list=WL', { credentials: 'same-origin', cache: 'no-store' });
      const t = await res.text();
      const count = (re) => (t.match(re) || []).length;
      return {
        status: res.status, bytes: t.length, hasInitialData: /ytInitialData/.test(t),
        playlistVideoRenderer: count(/"playlistVideoRenderer"/g), lockupViewModel: count(/"lockupViewModel"/g),
        lockupVideoContent: count(/"contentType":"LOCKUP_CONTENT_TYPE_VIDEO"/g), playlistVideoListRenderer: count(/"playlistVideoListRenderer"/g),
        signInPrompt: /Sign in to see videos saved to Watch later/i.test(t), emptyMessage: /No videos|Your Watch Later playlist is empty/i.test(t)
      };
    } catch (e) { return { error: String(e).slice(0, 120) }; }
  }
  async function lookup() {
    const id = new URLSearchParams(location.search).get('v');
    if (!id) return null;
    const r = {};
    try {
      const cfg = window.ytcfg && window.ytcfg.get ? window.ytcfg : null;
      const ctx = cfg && cfg.get('INNERTUBE_CONTEXT'), key = cfg && cfg.get('INNERTUBE_API_KEY');
      r.ytcfg = !!cfg; r.hasContext = !!ctx;
      if (ctx) {
        const res = await fetch('/youtubei/v1/player?prettyPrint=false' + (key ? '&key=' + encodeURIComponent(key) : ''), { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ context: ctx, videoId: id, contentCheckOk: true, racyCheckOk: true }) });
        r.playerApiStatus = res.status;
        if (res.ok) { const j = await res.json(); const m = j.microformat && j.microformat.playerMicroformatRenderer; r.playability = j.playabilityStatus && j.playabilityStatus.status; r.hasMicroformat = !!m; r.uploadDate = m && m.uploadDate; r.publishDate = m && m.publishDate; }
      }
    } catch (e) { r.playerApiError = String(e).slice(0, 120); }
    return r;
  }

  // YouTube Playables (games): where they appear and whether ReTrapper's "Hide YouTube Playables" took effect.
  function playables(anon) {
    const CONT = 'ytd-rich-section-renderer, ytd-rich-shelf-renderer, ytd-rich-item-renderer, ytd-shelf-renderer, ytd-item-section-renderer, ytd-video-renderer, yt-lockup-view-model, ytd-reel-shelf-renderer, ytd-guide-entry-renderer, ytd-mini-guide-entry-renderer';
    const tokens = (D().getAttribute('data-rt') || '').split(/\s+/);
    const links = qa('a[href*="/playables"]');
    const path = (el) => { const p = []; for (let e = el.parentElement; e && p.length < 6; e = e.parentElement) p.push(e.localName + (e.id ? '#' + e.id : '')); return p.join(' < '); };
    const rows = links.slice(0, 12).map((a) => {
      const c = a.closest(CONT), r = a.getBoundingClientRect();
      return { container: c ? c.localName : null, containerDisplay: c ? getComputedStyle(c).display : null, linkShown: r.width > 0 && r.height > 0, path: path(a) };
    });
    const firstShown = links.find((a) => { const r = a.getBoundingClientRect(); return r.width > 0 && r.height > 0; });
    const c = firstShown && (firstShown.closest(CONT) || firstShown.parentElement);
    return {
      optionOn: tokens.includes('hidePlayables'),
      links: links.length,
      stillVisible: rows.filter((x) => x.linkShown).length,
      gameCards: qa('ytd-game-card-renderer, [is-playables]').length,
      rows,
      visibleSample: c ? markup(c, 2000, anon) : null
    };
  }

  async function build(opt) {
    const wl = pageKind() === 'home' ? await wlProbe() : null;
    const rep = { _about: 'ReTrapper bug report. Contains no account info; text is masked when "mask titles and names" was on.', note: opt.note || '', environment: safe(environment), retrapper: safe(retrapper), errors: errors.slice(), grid: safe(() => grid(opt)), watchLaterShelf: Object.assign(safe(shelf), { lastFetch: D().dataset.rtWl || null, playlistProbe: wl }), dates: safe(dates), thumbnails: safe(thumbs), autoplay: safe(autoplay), comments: safe(comments), channelSearch: safe(channelSearch), searchPage: safe(() => searchPage(opt.mask)), playables: safe(() => playables(opt.mask)), collab: safe(() => collabInfo(opt.mask)) };
    if (pageKind() === 'watch') { rep.watchPage = safe(() => watchInfo(opt.mask)); if (opt.lookups) rep.lookup = await lookup(); }
    if (opt.markup) {
      rep.markup = {
        firstCard: safe(() => markup(qa('ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer, yt-lockup-view-model').find((c) => q('a[href*="/watch?v="]', c)), 3500, opt.mask)),
        shelf: safe(() => markup(document.getElementById('watch-later-shelf-section'), 3000, opt.mask)),
        gridRow: safe(() => markup(q('ytd-rich-grid-row'), 1500, opt.mask))
      };
    }
    return JSON.stringify(rep, null, 1);
  }

  // The toolbar popup calls this (via chrome.scripting, in this same page context).
  window.__rtBugReportBuild = build;
})();
