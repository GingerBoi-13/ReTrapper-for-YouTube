// ReTrapper
//
// Home page cleanups (youtube.com/ only), each individually toggleable
// from the toolbar popup:
//
// 1. No infinite scroll — hides the invisible
//    <ytd-continuation-item-renderer> marker YouTube uses to detect when to
//    fetch the next batch of videos, so the feed stops after the first load.
//
// 2. No watched videos — hides any video card whose thumbnail shows a
//    "resume playback" progress bar, meaning you've already watched some
//    or all of it.
//
// 3. No view counts — hides the view-count element, matched via its
//    aria-label (the visible text is often just a bare number like "6.5M",
//    with the word "views" only present in the aria-label).
//
// 4. No hype/trending badges — hides metadata badges (e.g. "#70 hyped",
//    "Trending") regardless of their label or rank.
//
// 5. From Your Watch Later — injects a horizontal shelf of videos from
//    your Watch Later playlist above the regular recommendation grid.
//    Fetched via the background service worker (see background.js).
//
// Plus, on watch pages (youtube.com/watch):
//
// 6. Full-height theatre mode — when YouTube's built-in theatre mode is
//    active, expands the player to use all of the available vertical
//    space below the header, instead of just the default fixed height.
//
// 7. Sort comments by most liked — reorders top-level comment threads by
//    their like count (highest first), regardless of what sort order
//    YouTube's own "Top comments"/"Newest first" menu is set to.
//
// Every hide/resize is reversible (tracked with a data-attribute marker)
// so flipping a toggle off in the popup restores normal behavior
// immediately, without needing to reload the page.

(function () {
  'use strict';

  const DEFAULTS = {
    noInfiniteScroll: true,
    hideWatched: true,
    hideViews: true,
    hideCardViews: true,
    hideBadges: true,
    expandTheatre: true,
    sortCommentsByLikes: false
  };

  let settings = { ...DEFAULTS };
  // Effective state comes from the ReTrapper engine (so bundles like Focus mode
  // can switch these on too); falls back to stored values until it is ready.
  const flag = (k) => (window.RT && window.RT.state ? window.RT.state.tokens.has(k) : settings[k]);
  let observer = null;
  let resizeHandler = null;

  const SEPARATOR_RE = /^[•·|]$/;
  const THEATRE_SELECTORS = [
    '#player-theater-container',
    '#player-container-outer',
    '#full-bleed-container',
    '#movie_player'
  ];

  function isHomePage() {
    return location.hostname === 'www.youtube.com' && location.pathname === '/';
  }

  function isWatchPage() {
    return location.hostname === 'www.youtube.com' && location.pathname === '/watch';
  }

  // --- 1. No infinite scroll -----------------------------------------------

  function applyContinuation() {
    document.querySelectorAll('ytd-continuation-item-renderer').forEach((el) => {
      if (flag('noInfiniteScroll')) {
        el.style.display = 'none';
        el.dataset.retrapHidden = 'true';
      } else if (el.dataset.retrapHidden) {
        el.style.display = '';
        delete el.dataset.retrapHidden;
      }
    });
  }

  // --- 2. No watched videos --------------------------------------------------

  // Watched-video hiding now lives in dom.js (it covers every feed and the newer card markup).
  // This only undoes what an older version hid.
  function applyWatched() {
    document.querySelectorAll('[data-retrap-hidden-watched]').forEach((card) => {
      card.style.display = '';
      delete card.dataset.retrapHiddenWatched;
    });
  }

  // --- 3. No view counts / 4. No hype badges --------------------------------

  function toggleSeparator(el, hide) {
    [el.nextElementSibling, el.previousElementSibling].forEach((sib) => {
      if (!sib || !SEPARATOR_RE.test(sib.textContent.trim())) return;
      if (hide) {
        sib.style.display = 'none';
        sib.dataset.retrapHiddenSep = 'true';
      } else if (sib.dataset.retrapHiddenSep) {
        sib.style.display = '';
        delete sib.dataset.retrapHiddenSep;
      }
    });
  }

  function applyViewCounts(card) {
    card.querySelectorAll('[aria-label]').forEach((el) => {
      const label = el.getAttribute('aria-label') || '';
      if (!/\bviews?\b/i.test(label)) return;

      if (flag('hideCardViews')) {
        if (el.dataset.retrapHiddenViews) return;
        el.style.display = 'none';
        el.dataset.retrapHiddenViews = 'true';
        toggleSeparator(el, true);
      } else if (el.dataset.retrapHiddenViews) {
        el.style.display = '';
        delete el.dataset.retrapHiddenViews;
        toggleSeparator(el, false);
      }
    });
  }

  function applyBadges(card) {
    card.querySelectorAll('.ytContentMetadataViewModelBadge').forEach((badge) => {
      const row = badge.closest('.ytContentMetadataViewModelMetadataRow') || badge;
      if (flag('hideBadges')) {
        row.style.display = 'none';
        row.dataset.retrapHiddenBadge = 'true';
      } else if (row.dataset.retrapHiddenBadge) {
        row.style.display = '';
        delete row.dataset.retrapHiddenBadge;
      }
    });
  }

  function applyMetadataBits() {
    document.querySelectorAll('ytd-rich-item-renderer').forEach((card) => {
      applyViewCounts(card);
      applyBadges(card);
    });
  }

  function cleanUpHome() {
    applyContinuation();
    applyWatched();
    applyMetadataBits();
  }

  // --- 5. Full-height theatre mode ------------------------------------------

  function isTheatreActive() {
    const flexy = document.querySelector('ytd-watch-flexy');
    return !!(flexy && (flexy.hasAttribute('theater') || flexy.theater === true));
  }

  function restoreTheatreHeights() {
    THEATRE_SELECTORS.forEach((sel) => {
      const el = document.querySelector(sel);
      if (!el || !('retrapTheatreApplied' in el.dataset)) return;
      el.style.removeProperty('height');
      el.style.removeProperty('max-height');
      delete el.dataset.retrapTheatreApplied;
    });
  }

  function applyTheatreHeights() {
    if (!flag('expandTheatre') || !isTheatreActive()) {
      restoreTheatreHeights();
      return;
    }

    const masthead = document.querySelector('#masthead-container') || document.querySelector('ytd-masthead');
    const topOffset = masthead ? Math.round(masthead.getBoundingClientRect().height) : 56;
    const targetHeight = Math.max(window.innerHeight - topOffset, 200);

    THEATRE_SELECTORS.forEach((sel) => {
      const el = document.querySelector(sel);
      if (!el) return;
      el.style.setProperty('height', targetHeight + 'px', 'important');
      el.style.setProperty('max-height', 'none', 'important');
      el.dataset.retrapTheatreApplied = 'true';
    });
  }

  // --- 6. Sort comments by most liked ---------------------------------------
  //
  // Reads each top-level comment thread's like count (parsed from its like
  // button's aria-label/text, handling "1.2K"/"3.4M" shorthand) and reorders
  // the threads — by moving the existing DOM nodes, not recreating them — so
  // the most-liked comment shows first. Re-runs on every DOM change, but
  // only actually writes to the DOM when the order has genuinely changed
  // (e.g. a newly-loaded comment outranks existing ones), so it's a no-op
  // most of the time.

  function parseShorthandCount(text) {
    if (!text) return 0;
    const match = text.replace(/,/g, '').match(/([\d.]+)\s*([KkMmBb]?)/);
    if (!match) return 0;
    let num = parseFloat(match[1]);
    if (isNaN(num)) return 0;
    const suffix = match[2].toUpperCase();
    if (suffix === 'K') num *= 1e3;
    else if (suffix === 'M') num *= 1e6;
    else if (suffix === 'B') num *= 1e9;
    return num;
  }

  function getCommentLikeCount(thread) {
    const likeEl = thread.querySelector(
      '[aria-label*="like" i]:not([aria-label*="dislike" i]), #vote-count-middle, #vote-count-left'
    );
    if (!likeEl) return 0;
    const label = likeEl.getAttribute('aria-label') || likeEl.textContent || '';
    return parseShorthandCount(label);
  }

  function sortCommentsByLikes() {
    return; // superseded by comment-sort.js

    const threads = Array.from(document.querySelectorAll('ytd-comments ytd-comment-thread-renderer'));
    if (threads.length < 2) return;

    const parent = threads[0].parentElement;
    if (!parent) return;

    const topLevel = threads.filter((t) => t.parentElement === parent);
    if (topLevel.length < 2) return;

    const sorted = topLevel
      .map((el) => ({ el, likes: getCommentLikeCount(el) }))
      .sort((a, b) => b.likes - a.likes)
      .map((entry) => entry.el);

    const needsReorder = sorted.some((el, i) => el !== topLevel[i]);
    if (needsReorder) {
      sorted.forEach((el) => parent.appendChild(el)); // appendChild on an existing node moves it
    }
  }

  function cleanUp() {
    if (isHomePage()) {
      cleanUpHome();
    }
    if (isWatchPage()) {
      applyTheatreHeights();
      sortCommentsByLikes();
    } else {
      restoreTheatreHeights();
    }
  }

  function teardown() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    if (resizeHandler) {
      window.removeEventListener('resize', resizeHandler);
      resizeHandler = null;
    }
  }

  function setup() {
    teardown();
    if (!isHomePage() && !isWatchPage()) return;

    cleanUp();

    observer = new MutationObserver(() => cleanUp());
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['theater']
    });

    resizeHandler = () => applyTheatreHeights();
    window.addEventListener('resize', resizeHandler);
  }

  function loadSettingsAndInit() {
    chrome.storage.local.get(DEFAULTS, (stored) => {
      settings = { ...DEFAULTS, ...stored };
      setup();
    });
  }

  // Live-update when a toggle changes in the popup, no reload needed.
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    let changed = false;
    Object.keys(DEFAULTS).forEach((key) => {
      if (changes[key]) {
        settings[key] = changes[key].newValue;
        changed = true;
      }
    });
    if (changed) cleanUp();
  });

  // YouTube is a single-page app; it fires this event on client-side
  // navigation (e.g. going from the home page to a watch page).
  document.addEventListener('yt-navigate-finish', setup);
  window.addEventListener('load', loadSettingsAndInit);
  loadSettingsAndInit();
  if (window.RT && window.RT.bus) {
    window.RT.bus.addEventListener('apply', () => { if (isHomePage() || isWatchPage()) { setup(); } });
  }
})();
