// Items: Player, Thumbnails, Search, Subscriptions, Channel pages.
(function () {
  'use strict';
  const RT = window.RT;
  const { toggle, number, select, range, text, area, multi } = RT._h;
  const { WATCH, HOME, SUBS, CHAN, SRCH } = RT.SEL;
  const THEATER = ['#player-theater-container', '#player-container-outer', '#full-bleed-container', '#movie_player'];

  toggle('channelSearch', 'Better channel search (searches every video on the channel)', {
    def: false,
    hint: 'Adds a search bar to channel pages that reads the channel\'s whole upload list and matches every word, quoted phrases, -exclusions and typos, with sort / type / date / duration filters.'
  });
  toggle('channelSearchDeep', 'Channel search: also match descriptions and transcripts (uses YouTube search)', { def: true });
  toggle('channelSearchFuzzy', 'Channel search: tolerate typos', { def: true });
  toggle('channelSearchGrid', 'Channel search as grid', { def: false });
  toggle('customChannelColumns', 'Custom videos per row on channels', { def: false, hint: 'Applies the slider below to channel pages (Home, Videos, Live) as well as channel search results.' });
  range('channelSearchColumns', 'Channel videos per row', 1, 7, 1, 4);

  // Derived-state CSS (variables are set by the scripts).
  RT.extraCss = [
    // Search: channels first. Their relative order (YouTube's own relevance ranking) is kept.
    'ytd-search ytd-section-list-renderer > #contents{display:flex !important;flex-direction:column !important}',
    'ytd-search ytd-section-list-renderer > #contents > ytd-item-section-renderer:has(ytd-channel-renderer,yt-lockup-view-model a.ytLockupMetadataViewModelTitle[href^="/@"],yt-lockup-view-model a.ytLockupMetadataViewModelTitle[href^="/channel/"]){order:-2 !important}',
    'ytd-search ytd-section-list-renderer > #contents > ytd-continuation-item-renderer{order:99 !important}',
    'ytd-search ytd-item-section-renderer > #contents{display:flex !important;flex-direction:column !important}',
    'ytd-search ytd-item-section-renderer > #contents > ytd-channel-renderer,ytd-search ytd-item-section-renderer > #contents > yt-lockup-view-model:has(a.ytLockupMetadataViewModelTitle[href^="/@"],a.ytLockupMetadataViewModelTitle[href^="/channel/"]){order:-1 !important}',
    'ytd-watch-flexy button[data-rt-likes] .yt-spec-button-shape-next__button-text-content:not(.rt-like-count){display:none !important}',
    'ytd-feed-nudge-renderer,ytd-rich-section-renderer:has(> #content > ytd-feed-nudge-renderer),ytd-rich-section-renderer:has(ytd-feed-nudge-renderer){display:none !important}',
    'ytd-rich-item-renderer[data-rt-empty],ytd-rich-section-renderer[data-rt-empty]{display:none !important}',
    // Even grids on Home and Subscriptions: flatten YouTube's rows so hidden items never leave gaps.
    'ytd-browse[page-subtype="home"] ytd-rich-grid-renderer > #contents,ytd-browse[page-subtype="subscriptions"] ytd-rich-grid-renderer > #contents{display:grid !important;grid-template-columns:repeat(var(--ytd-rich-grid-items-per-row,4),minmax(0,1fr)) !important;gap:24px 16px !important;grid-auto-flow:row dense !important;align-items:start !important;padding:0 24px !important;box-sizing:border-box !important}',
    'ytd-browse[page-subtype="home"] ytd-rich-grid-renderer ytd-rich-grid-row,ytd-browse[page-subtype="home"] ytd-rich-grid-renderer ytd-rich-grid-row > #contents,ytd-browse[page-subtype="subscriptions"] ytd-rich-grid-renderer ytd-rich-grid-row,ytd-browse[page-subtype="subscriptions"] ytd-rich-grid-renderer ytd-rich-grid-row > #contents{display:contents !important}',
    'ytd-browse[page-subtype="home"] ytd-rich-grid-renderer > #contents > :not(ytd-rich-item-renderer):not(ytd-rich-grid-row),ytd-browse[page-subtype="subscriptions"] ytd-rich-grid-renderer > #contents > :not(ytd-rich-item-renderer):not(ytd-rich-grid-row){grid-column:1/-1 !important}',
    'ytd-browse[page-subtype="home"] ytd-rich-grid-renderer ytd-rich-item-renderer,ytd-browse[page-subtype="subscriptions"] ytd-rich-grid-renderer ytd-rich-item-renderer{width:auto !important;max-width:none !important;margin:0 !important;min-width:0 !important}',
    // Same flattening for any other wrapper YouTube puts around a row of items.
    'ytd-browse[page-subtype="home"] ytd-rich-grid-renderer > #contents > :has(> ytd-rich-item-renderer),ytd-browse[page-subtype="home"] ytd-rich-grid-renderer > #contents > :has(> #contents > ytd-rich-item-renderer),ytd-browse[page-subtype="home"] ytd-rich-grid-renderer > #contents > :has(> #contents > ytd-rich-item-renderer) > #contents,ytd-browse[page-subtype="subscriptions"] ytd-rich-grid-renderer > #contents > :has(> ytd-rich-item-renderer),ytd-browse[page-subtype="subscriptions"] ytd-rich-grid-renderer > #contents > :has(> #contents > ytd-rich-item-renderer),ytd-browse[page-subtype="subscriptions"] ytd-rich-grid-renderer > #contents > :has(> #contents > ytd-rich-item-renderer) > #contents{display:contents !important}',
    // Subscriptions: keep the Shorts shelf a tidy single horizontal row of short-sized cards. The grid rules
    // above flatten the feed and set video cards to the column width; without this the Shorts get stretched to
    // that width and stack into a tall block. The section stays full width; its Shorts scroll sideways.
    'ytd-browse[page-subtype="subscriptions"] ytd-rich-grid-renderer > #contents > ytd-rich-section-renderer:has(ytm-shorts-lockup-view-model,ytm-shorts-lockup-view-model-v2,ytd-rich-shelf-renderer[is-shorts],ytd-reel-shelf-renderer,a[href^="/shorts/"]){grid-column:1/-1 !important;display:block !important}',
    'ytd-browse[page-subtype="subscriptions"] :is(ytd-rich-shelf-renderer[is-shorts],ytd-reel-shelf-renderer) :is(#contents,#scroll-container,#items){display:flex !important;flex-flow:row nowrap !important;overflow-x:auto !important;overflow-y:hidden !important;gap:8px !important;align-items:flex-start !important;scrollbar-width:thin}',
    'ytd-browse[page-subtype="subscriptions"] :is(ytd-rich-shelf-renderer[is-shorts],ytd-reel-shelf-renderer) :is(ytd-rich-item-renderer,ytd-reel-item-renderer,ytm-shorts-lockup-view-model,ytm-shorts-lockup-view-model-v2),ytd-browse[page-subtype="subscriptions"] ytd-rich-item-renderer:has(ytm-shorts-lockup-view-model,ytm-shorts-lockup-view-model-v2,a[href^="/shorts/"]){flex:0 0 auto !important;width:160px !important;min-width:160px !important;max-width:160px !important;margin:0 !important}',
    // Let dates and channel names wrap instead of ending in "...".
    'ytd-rich-item-renderer yt-content-metadata-view-model [class*="MetadataRow"]{flex-wrap:wrap !important;height:auto !important;white-space:normal !important}',
    'ytd-rich-item-renderer yt-content-metadata-view-model [class*="MetadataText"],ytd-rich-item-renderer yt-content-metadata-view-model span{overflow:visible !important;text-overflow:clip !important;white-space:normal !important;max-width:none !important}',
    // Muted autoplay / hover previews are always off (no setting).
    'ytd-video-preview,#video-preview,ytd-moving-thumbnail-renderer,#mouseover-overlay,ytd-thumbnail #inline-preview-player,ytd-thumbnail ytd-video-preview,yt-thumbnail-view-model video,ytd-rich-item-renderer ytd-video-preview{display:none !important}',
    // A little breathing room between the search bar and the first result.
    'ytd-search ytd-two-column-search-results-renderer ytd-section-list-renderer > #contents{padding-top:28px !important;box-sizing:border-box}',
    // One grid for the whole results list, so a short last row never leaves a gap before the next batch of results.
    'html[data-rt-sgrid] ytd-search ytd-two-column-search-results-renderer ytd-section-list-renderer > #contents{display:grid !important;grid-template-columns:repeat(var(--rt-search-cols),minmax(0,1fr)) !important;gap:44px 24px !important;align-items:start !important}',
    // YouTube gives the first card of each batch no top margin and the rest 16px, which made the top-left card sit higher.
    'html[data-rt-sgrid] ytd-search ytd-item-section-renderer ytd-video-renderer,html[data-rt-sgrid] ytd-search ytd-item-section-renderer > #contents > yt-lockup-view-model{margin:0 !important}',
    'html[data-rt-sgrid] ytd-search ytd-section-list-renderer > #contents > ytd-item-section-renderer,html[data-rt-sgrid] ytd-search ytd-item-section-renderer > #contents{display:contents !important}',
    'html[data-rt-sgrid] ytd-search ytd-section-list-renderer > #contents > :not(ytd-item-section-renderer),html[data-rt-sgrid] ytd-search ytd-item-section-renderer > :not(#contents),html[data-rt-sgrid] ytd-search ytd-item-section-renderer > #contents > :not(ytd-video-renderer):not(yt-lockup-view-model){grid-column:1/-1 !important}',
    'html[data-rt-sgrid] ytd-search [data-rt-empty]{position:absolute !important;grid-column:auto !important;width:0 !important;height:0 !important;overflow:hidden !important}',
    // More room: a wider results area and full titles instead of "..." after a few lines.
    'html[data-rt-sgrid] ytd-search ytd-two-column-search-results-renderer{max-width:min(1760px,calc(100vw - 140px)) !important;width:100% !important;margin-left:auto !important;margin-right:auto !important}',
    'html[data-rt-sgrid] ytd-search ytd-two-column-search-results-renderer #primary{max-width:none !important;width:100% !important}',
    'html[data-rt-sgrid] ytd-search ytd-video-renderer #video-title,html[data-rt-sgrid] ytd-search ytd-video-renderer a#video-title yt-formatted-string{-webkit-line-clamp:unset !important;max-height:none !important}',
    'html[data-rt-sgrid] ytd-search ytd-video-renderer #dismissible{flex-direction:column !important}',
    'html[data-rt-sgrid] ytd-search ytd-video-renderer,html[data-rt-sgrid] ytd-search ytd-video-renderer #dismissible,html[data-rt-sgrid] ytd-search ytd-video-renderer .text-wrapper,html[data-rt-sgrid] ytd-search ytd-video-renderer #meta{min-width:0 !important;max-width:100% !important;box-sizing:border-box !important}',
    'html[data-rt-sgrid] ytd-search ytd-video-renderer .text-wrapper{flex:0 0 auto !important;height:auto !important}',
    'html[data-rt-sgrid] ytd-search ytd-video-renderer #video-title,html[data-rt-sgrid] ytd-search ytd-video-renderer h3{white-space:normal !important;overflow-wrap:anywhere !important}',
    'html[data-rt-sgrid] ytd-search ytd-video-renderer [class*="snippet" i]{white-space:normal !important;max-width:100% !important}',
    'html[data-rt-sgrid] ytd-search ytd-video-renderer ytd-thumbnail,html[data-rt-sgrid] ytd-search ytd-video-renderer #dismissible > ytd-thumbnail{width:100% !important;max-width:none !important;margin:0 0 8px !important}',
    'html[data-rt-sgrid] ytd-search yt-lockup-view-model [class*="ytLockupViewModelHorizontal"]{flex-direction:column !important}',
    'html[data-rt-sgrid] ytd-search yt-lockup-view-model [class*="ytLockupViewModelContentImage"]{width:100% !important;max-width:none !important}',
    'html[data-rt~="thumbsHideAll"] #rt-chsearch .rtcs-thumb{display:none !important}',
    'html[data-rt~="rtVideoFilter"] video.html5-main-video{filter:var(--rt-video-filter) !important}',
    'html[data-rt~="rtAmbient"] #cinematics,html[data-rt~="rtAmbient"] #cinematics-container{opacity:var(--rt-ambient) !important}',
    'html[data-rt~="rtGray"]{filter:grayscale(var(--rt-gray)) !important}',
    'html[data-rt~="rtAccent"]{--yt-spec-call-to-action:var(--rt-accent) !important;--yt-spec-themed-blue:var(--rt-accent) !important}',
    'html[data-rt~="rtAccent"] .ytp-play-progress,html[data-rt~="rtAccent"] .ytp-swatch-background-color{background:var(--rt-accent) !important}',
    'html[data-rt~="rtMaxWidth"] ytd-page-manager{max-width:var(--rt-maxw) !important;margin-left:auto !important;margin-right:auto !important}',
    'html[data-rt~="rtHeaderAway"] ytd-masthead{transform:translateY(-100%) !important}',
    'html[data-rt~="headerAutoHide"] ytd-masthead{transition:transform .15s ease !important}'
  ].concat(THEATER.map((s) =>
    `html[data-rt~="rtPlayerH"] ytd-watch-flexy[theater] ${s}{height:var(--rt-player-h) !important;max-height:none !important}`
  )).concat(RT.THUMBS.flatMap((t) => [
    `html[data-rt~="rtThumbFilter"] ${t}{filter:var(--rt-thumb-filter) !important}`,
    `html[data-rt~="rtThumbFilter"][data-rt~="rtThumbReveal"] ${t}:hover{filter:none !important}`,
    `html[data-rt~="rtThumbOpacity"] ${t}{opacity:var(--rt-thumb-opacity) !important}`
  ]));

  // ---- Player ---------------------------------------------------------------
  toggle('fullWindowPlayer', 'Full-window player', {
    hint: 'Theater mode, full viewport height, header hidden.',
    rules: [['ytd-masthead', 'display:none', ['rtWatch']], ['ytd-page-manager', 'margin-top:0', ['rtWatch']],
      ['ytd-app', '--ytd-masthead-height:0px', ['rtWatch']]]
  });
  toggle('fullSizePlayer', 'Full-size player', { hint: 'Turns on theater mode and fills the height under the header.' });
  toggle('resizablePlayer', 'Resizable player', { hint: 'Drag the bar under the player (theater mode) to set its height.' });
  toggle('autoTheater', 'Auto theater mode', { hint: 'Opens every video in theater mode as soon as the page loads. You can still switch back with the normal theater button.', alts: ['Automatically enable theater mode', 'Auto-enable theater mode', 'Automatic theater mode', 'Theater mode'] });
  toggle('expandTheatre', 'Full-size theater mode', { alts: ['Full-height theatre mode'], def: false });
  toggle('autoFullscreen', 'Automatically enable fullscreen', {
    alts: ['Auto-enable fullscreen', 'Automatic fullscreen'],
    hint: 'Browsers only allow fullscreen after a click or key press, so it starts on your first interaction.'
  });
  toggle('minimalPlayer', 'Minimal player', {
    css: ['.ytp-chrome-top', '.ytp-gradient-top', '.ytp-watermark', '.ytp-pause-overlay', '.ytp-ce-element', '.ytp-cards-teaser', '.ytp-endscreen-content']
  });
  toggle('hidePlayerControls', 'Hide player controls', { css: ['.html5-video-player .ytp-chrome-bottom', '.ytp-gradient-bottom'] });
  multi('playerControlsHide', 'Customize player controls', [
    { v: 'next', l: 'Next button', css: ['.ytp-next-button'] },
    { v: 'prev', l: 'Previous button', css: ['.ytp-prev-button'] },
    { v: 'volume', l: 'Volume', css: ['.ytp-volume-area'] },
    { v: 'time', l: 'Time', css: ['.ytp-time-display'] },
    { v: 'chapter', l: 'Chapter title', css: ['.ytp-chapter-container'] },
    { v: 'subs', l: 'Subtitles', css: ['.ytp-subtitles-button'] },
    { v: 'settings', l: 'Settings', css: ['.ytp-settings-button'] },
    { v: 'mini', l: 'Miniplayer', css: ['.ytp-miniplayer-button'] },
    { v: 'size', l: 'Theater button', css: ['.ytp-size-button'] },
    { v: 'fs', l: 'Fullscreen', css: ['.ytp-fullscreen-button'] },
    { v: 'cast', l: 'Cast', css: ['.ytp-remote-button'] },
    { v: 'autonav', l: 'Autoplay toggle', css: ['.ytp-autonav-toggle-button-container'] }
  ]);
  range('vfBrightness', 'Brightness adjustment', 50, 200, 5, 100, { unit: '%' });
  range('vfContrast', 'Contrast', 50, 200, 5, 100, { unit: '%' });
  range('vfSaturate', 'Saturation', 0, 300, 5, 100, { unit: '%' });
  range('vfSepia', 'Sepia', 0, 100, 5, 0, { unit: '%' });
  toggle('grayscaleVideo', 'Grayscale video');
  range('ambientIntensity', 'Ambient lighting intensity', 0, 100, 5, 100, { unit: '%', alts: ['Ambient lighting'] });
  toggle('disableAmbient', 'Disable ambient lighting', {
    css: ['#cinematics', '#cinematics-container', '#cinematics-full-bleed-container']
  });
  select('defaultQuality', 'Default video quality', [['off', 'YouTube default'], ['tiny', '144p'], ['small', '240p'], ['medium', '360p'],
    ['large', '480p'], ['hd720', '720p'], ['hd1080', '1080p'], ['hd1440', '1440p'], ['hd2160', '2160p (4K)'], ['highres', 'Highest available (Auto HD / 4K / 8K)']], 'off');
  select('defaultSpeed', 'Default playback speed', [['0', 'YouTube default'], ['0.5', '0.5×'], ['0.75', '0.75×'], ['1', '1×'],
    ['1.25', '1.25×'], ['1.5', '1.5×'], ['1.75', '1.75×'], ['2', '2×'], ['2.5', '2.5×'], ['3', '3×']], '0');
  toggle('disableAutoplay', 'Disable autoplay', { hint: 'Turns off "play next video" automatically.' });
  toggle('intelligentLooping', 'Intelligent looping', { hint: 'Loops only videos shorter than the limit below.' });
  number('loopMaxMinutes', 'Loop videos shorter than (min)', 5, { min: 1, max: 120, showIf: 'intelligentLooping' });
  toggle('loopVideos', 'Loop videos', { alts: ['Video looping'] });
  toggle('playlistNavigation', 'Playlist navigation', { hint: 'Previous/next bar when watching a playlist.' });
  toggle('playlistControls', 'Playlist controls', { hint: 'Adds loop and shuffle to the playlist bar.', implies: ['playlistNavigation'] });
  toggle('autoSkipPromos', 'Auto-skip video promotions', { alts: ['Auto-skip promotions'], hint: 'Clicks Skip when YouTube offers it. Does not block ads.' });
  toggle('hideVideoPromos', 'Hide video promotions', {
    css: ['.ytp-paid-content-overlay', 'ytd-compact-promoted-video-renderer', 'ytd-compact-promoted-item-renderer', 'ytd-promoted-video-renderer']
  });
  toggle('hidePlayerAds', 'Hide player advertisements', {
    css: ['.ytp-ad-overlay-container', '.ytp-ad-text-overlay', '.ytp-ad-image-overlay', '.ytp-ad-overlay-slot']
  });
  toggle('autoCaptions', 'Turn on captions by default');
  toggle('neverCaptions', 'Keep captions off', { alts: ['Never show captions', 'Turn captions off by default'], hint: 'Switches captions off when a video starts, even if YouTube turns them on. You can still turn them on yourself.' });
  toggle('defaultVolumeOn', 'Set default volume');
  range('defaultVolume', 'Default volume', 0, 100, 5, 50, { unit: '%', showIf: 'defaultVolumeOn' });

  // ---- Thumbnails -------------------------------------------------------------
  toggle('thumbsHideAll', 'Hide thumbnails', {
    hint: 'One switch for the whole site: Home, Subscriptions, Search, channels, playlists, history, recommendations, end screens, the Watch Later shelf and channel search results.',
    rules: RT.onThumbs(['ytd-app'], 'display:none').concat([
      ['ytd-app yt-collection-thumbnail-view-model', 'display:none'], ['ytd-app ytd-playlist-video-thumbnail-renderer', 'display:none'],
      ['ytd-app .ytp-videowall-still-image', 'display:none'], ['ytd-app .ytp-ce-covering-image', 'display:none']
    ])
  });
  toggle('blurThumbs', 'Blur thumbnails', { hint: 'Hover a thumbnail to reveal it.' });
  range('blurAmount', 'Blur strength', 2, 30, 1, 10, { unit: 'px', showIf: 'blurThumbs' });
  toggle('grayThumbs', 'Grayscale thumbnails');
  text('modifyThumbs', 'Modify thumbnails (CSS filter)', { placeholder: 'brightness(.7) saturate(.5)' });
  toggle('reduceThumbs', 'Reduce thumbnail visibility');
  range('thumbOpacity', 'Thumbnail opacity', 10, 100, 5, 40, { unit: '%', showIf: 'reduceThumbs' });

  // ---- Search -------------------------------------------------------------------
  toggle('hidePeopleAlso', 'Hide "People also search for"', { css: [`${SRCH} ytd-horizontal-card-list-renderer`, `${SRCH} ytd-secondary-search-container-renderer`] });
  toggle('hidePromotedSites', 'Hide promoted websites', {
    css: ['ytd-promoted-sparkles-web-renderer', `${SRCH} ytd-search-pyv-renderer`]
  });
  toggle('hidePromotedVideos', 'Hide promoted videos', {
    css: ['ytd-promoted-video-renderer', 'ytd-search-pyv-renderer', 'ytd-in-feed-ad-layout-renderer']
  });
  toggle('hideProducts', 'Hide suggested products', {
    css: ['ytd-product-item-renderer', 'ytd-merch-shelf-renderer', '#merch-shelf', `${SRCH} ytd-shelf-renderer:has(ytd-product-item-renderer)`]
  });
  toggle('hideSearchAds', 'Hide search advertisements', {
    implies: ['hideAdSlots', 'hidePromotedSites', 'hidePromotedVideos', 'hideProducts'],
    css: [`${SRCH} ytd-ad-slot-renderer`, `${SRCH} #masthead-ad`]
  });
  toggle('hideSearchRecs', 'Hide search recommendations', {
    hint: 'Hides recommendation shelves in results such as "For you" or "People also watched".',
    css: [`${SRCH} ytd-secondary-search-container-renderer`]
  });
  toggle('hideSearchAutocomplete', 'Hide search suggestions dropdown', {
    css: ['.sbdd_a', '.sbsb_a', '.ytSearchboxComponentSuggestionsContainer']
  });
  toggle('hideSearchChips', 'Hide search categories', {
    css: [`${SRCH} ytd-feed-filter-chip-bar-renderer`, `${SRCH} yt-chip-cloud-renderer`, `${SRCH} #chips-wrapper`]
  });
  select('searchLayout', 'Customize Search layout', [['default', 'Default'], ['compact', 'Compact'], ['narrow', 'Narrow column'], ['wide', 'Wide']], 'default', {
    cssBy: {
      compact: { rules: [[`${SRCH} ytd-video-renderer`, 'margin-bottom:6px'], [`${SRCH} ytd-video-renderer ytd-thumbnail`, 'max-width:210px;min-width:210px']] },
      narrow: { rules: [[`${SRCH} ytd-two-column-search-results-renderer`, 'max-width:820px;margin:0 auto']] },
      wide: { rules: [[`${SRCH} ytd-two-column-search-results-renderer`, 'max-width:none;padding:0 5%']] }
    }
  });
  toggle('inPageFilter', 'Improve in-page search', { hint: 'Adds a "Filter this page" box that live-filters video cards and comments.' });
  multi('searchHide', 'Customize Search results', [
    { v: 'channels', l: 'Channels', css: [`${SRCH} ytd-channel-renderer`] },
    { v: 'playlists', l: 'Playlists', css: [`${SRCH} ytd-playlist-renderer`, `${SRCH} yt-lockup-view-model:has(a[href*="list="]:not([href*="watch"]))`] },
    { v: 'mixes', l: 'Mixes', css: [`${SRCH} ytd-radio-renderer`] },
    { v: 'movies', l: 'Movies', css: [`${SRCH} ytd-movie-renderer`] },
    { v: 'posts', l: 'Posts', css: [`${SRCH} ytd-post-renderer`, `${SRCH} ytd-backstage-post-thread-renderer`] },
    { v: 'shelves', l: 'Shelves', css: [`${SRCH} ytd-shelf-renderer`] }
  ]);
  select('searchThumbs', 'Control Search thumbnails', [['normal', 'Normal'], ['small', 'Small'], ['blur', 'Blurred'], ['gray', 'Grayscale'], ['hidden', 'Hidden']], 'normal', {
    cssBy: {
      small: { rules: [[`${SRCH} ytd-video-renderer ytd-thumbnail`, 'max-width:168px;min-width:168px']] },
      blur: { rules: RT.onThumbs([SRCH], 'filter:blur(10px)') },
      gray: { rules: RT.onThumbs([SRCH], 'filter:grayscale(1)') },
      hidden: { rules: RT.onThumbs([SRCH], 'display:none') }
    }
  });

  // ---- Subscriptions ------------------------------------------------------------
  toggle('hideSubsSections', 'Hide unwanted sections', {
    css: [`${SUBS} ytd-rich-section-renderer`, `${SUBS} ytd-shelf-renderer`, `${SUBS} ytd-post-renderer`, `${SUBS} ytd-backstage-post-thread-renderer`]
  });
  toggle('hideSubsRecSections', 'Hide recommendation sections');
  toggle('hideSubsMostRelevant', 'Hide the "Most relevant" shelf', {
    alts: ['Hide Most relevant on Subscriptions'],
    hint: 'Removes the grouped "Most relevant" shelf at the top of the Subscriptions feed, leaving just the newest uploads.',
    css: [`${SUBS} ytd-rich-section-renderer.yt-most-relevant-section`]
  });
  select('subsColumns', 'Customize layout (videos per row)', [['0', 'Default'], ['1', '1'], ['2', '2'], ['3', '3'], ['4', '4'], ['5', '5'], ['6', '6'], ['7', '7'], ['8', '8']], '0');
  toggle('subsListView', 'List view (one video per row)', {
    alts: ['Turn the Subscriptions page into a list', 'Compact list layout'],
    hint: 'Lays the Subscriptions feed out as a single column with each video on its own row — thumbnail on the left, title and details on the right. Overrides "videos per row" while it is on.',
    rules: [
      [`${SUBS} ytd-rich-grid-renderer > #contents`, 'grid-template-columns:1fr'],
      [`${SUBS} ytd-rich-item-renderer .ytLockupViewModelHost`, 'display:flex;flex-direction:row;align-items:flex-start;gap:16px'],
      [`${SUBS} ytd-rich-item-renderer .ytLockupViewModelContentImage`, 'flex:0 0 360px;width:360px;max-width:360px;aspect-ratio:16/9;height:auto'],
      [`${SUBS} ytd-rich-item-renderer .ytLockupViewModelMetadata`, 'flex:1 1 auto;min-width:0'],
      // With thumbnails hidden the sized thumbnail box would otherwise reserve its height and leave a tall
      // empty gap on every row, so collapse it entirely and close the row up when "Hide thumbnails" is on.
      [`${SUBS} ytd-rich-item-renderer .ytLockupViewModelContentImage`, 'display:none', ['thumbsHideAll']],
      [`${SUBS} ytd-rich-item-renderer .ytLockupViewModelHost`, 'gap:0', ['thumbsHideAll']]
    ]
  });
  toggle('subsHideWatched', 'Hide watched videos in feed', { hint: 'Only affects the Subscriptions page. Separate from the Home page option.' });
  range('subsWatchedMinPct', 'Hide when watched at least', 1, 100, 1, 1, { unit: '%', showIf: 'subsHideWatched' });
  toggle('searchHideWatched', 'Hide watched videos in search results', { hint: 'Uses the "Hide when watched at least" percentage from the Home page.' });
  toggle('hideLiveStreams', 'Hide live streams');
  toggle('hidePremieres', 'Hide upcoming premieres');
  toggle('hideMembersOnly', 'Hide memberships and members-only content', {
    hint: 'Aggressive: hides members-only videos, Members tabs and shelves, Join buttons, membership offers and perks, and membership messages in live chat, everywhere.',
    css: ['#sponsor-button', 'ytd-sponsorships-tier-renderer', 'ytd-sponsorships-offer-renderer', 'ytd-sponsorships-expandable-perks-renderer', 'ytd-sponsorships-perk-renderer',
      'ytd-sponsorships-header-renderer', 'ytd-membership-offer-renderer', 'ytd-promoted-sparkles-text-search-renderer:has([href*="sponsor"])',
      'yt-tab-shape[tab-title="Members"]', 'yt-tab-shape[tab-title="Membership"]', 'tp-yt-paper-tab:has(a[href$="/membership"])', 'tp-yt-paper-tab:has(a[href$="/members"])',
      'ytd-watch-metadata yt-button-view-model:has(button[aria-label^="Join" i])', 'ytd-watch-metadata button-view-model:has(button[aria-label^="Join" i])',
      'ytd-watch-metadata ytd-button-renderer:has(button[aria-label^="Join" i])', 'ytd-video-owner-renderer ytd-button-renderer:has(button[aria-label^="Join" i])',
      'yt-flexible-actions-view-model :is(button-view-model,yt-button-view-model):has(button[aria-label^="Join" i])',
      'ytd-c4-tabbed-header-renderer #sponsor-button', 'ytd-channel-renderer #sponsor-button', 'ytd-engagement-panel-section-list-renderer[target-id*="sponsor" i]',
      'yt-live-chat-membership-item-renderer', 'yt-live-chat-sponsorships-gift-purchase-announcement-renderer', 'yt-live-chat-sponsorships-gift-redemption-announcement-renderer',
      '.badge-style-type-members-only', 'ytd-badge-supported-renderer:has(.badge-style-type-members-only)',
      ':is(ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer, ytd-compact-video-renderer, yt-lockup-view-model, ytd-playlist-video-renderer):has(.badge-style-type-members-only, [aria-label*="Members only" i], [aria-label*="Members first" i])']
  });
  area('subsKeywords', 'Filter subscription content (keywords, one per line)', { placeholder: 'reaction\nunboxing' });
  toggle('hideLatest', 'Hide "Latest" content', { hint: 'Hides sections titled "Latest …".' });
  multi('subsNavHide', 'Customize subscription navigation', [
    { v: 'chips', l: 'Filter chips', css: [`${SUBS} ytd-feed-filter-chip-bar-renderer`] },
    { v: 'manage', l: 'Manage link', css: [`${SUBS} ytd-button-renderer:has(a[href="/feed/channels"])`, `${SUBS} a[href="/feed/channels"]`] },
    { v: 'sidebar', l: 'Sidebar channel list', css: ['ytd-guide-section-renderer:has(a[href^="/@"])', 'ytd-guide-section-renderer:has(a[href^="/channel/"])'] }
  ]);

  // ---- Channel pages --------------------------------------------------------------
  toggle('hideChannelSections', 'Hide channel sections', {
    css: [`${CHAN} ytd-shelf-renderer`, `${CHAN} ytd-reel-shelf-renderer`, `${CHAN} ytd-channel-featured-content-renderer`,
      `${CHAN} ytd-channel-video-player-renderer`, `${CHAN} ytd-horizontal-card-list-renderer`]
  });
  toggle('hideChannelRecs', 'Hide channel recommendations');
  toggle('hideChannelHeaderInfo', 'Hide channel information', {
    css: [`${CHAN} yt-description-preview-view-model`, `${CHAN} #channel-tagline`, `${CHAN} #page-header yt-content-metadata-view-model`,
      `${CHAN} ytd-c4-tabbed-header-renderer #meta`, `${CHAN} #channel-header-links`]
  });
  toggle('hideChannelBanner', 'Hide channel banners', {
    css: [`${CHAN} #page-header-banner`, `${CHAN} yt-image-banner-view-model`, `${CHAN} ytd-c4-tabbed-header-renderer #banner`, `${CHAN} .page-header-banner`]
  });
  select('channelColumns', 'Customize channel layout (videos per row)', [['0', 'Default'], ['2', '2'], ['3', '3'], ['4', '4'], ['5', '5'], ['6', '6'], ['7', '7'], ['8', '8']], '0');
  toggle('channelNoAutoplay', 'Stop the channel welcome video from autoplaying', { def: false, alts: ['Block channel trailer autoplay', 'Channel featured video autoplay'], hint: 'On a channel\'s Home tab the featured video shows its thumbnail and a play button instead of starting by itself.' });
  select('channelDefaultTab', 'Open channels on tab', [['default', 'Home (default)'], ['videos', 'Videos'], ['shorts', 'Shorts'], ['streams', 'Live'], ['playlists', 'Playlists']], 'default');
  area('channelKeywords', 'Filter channel content (keywords, one per line)');
  toggle('hideChannelDistractions', 'Hide distracting elements', {
    css: [`${CHAN} ytd-merch-shelf-renderer`, `${CHAN} ytd-backstage-post-thread-renderer`, `${CHAN} ytd-post-renderer`, `${CHAN} #sponsor-button`,
      `${CHAN} ytd-recognition-shelf-renderer`, `${CHAN} yt-tab-shape[tab-title="Store"]`, `${CHAN} yt-tab-shape[tab-title="Community"]`,
      `${CHAN} yt-tab-shape[tab-title="Posts"]`]
  });
  multi('channelNavHide', 'Customize channel navigation',
    ['Home', 'Videos', 'Shorts', 'Live', 'Playlists', 'Community', 'Posts', 'Store', 'About', 'Search'].map((n) => ({
      v: n.toLowerCase(), l: n, css: [`${CHAN} yt-tab-shape[tab-title="${n}"]`]
    })));
})();
