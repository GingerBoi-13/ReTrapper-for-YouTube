// ReTrapper navigation behaviours: redirects, custom rules, hotkeys, small UI helpers.
(function () {
  'use strict';
  const RT = window.RT;
  if (!RT) return;
  const S = () => RT.settings();
  const on = (id) => RT.on(id);

  // ---- redirects ---------------------------------------------------------------
  function go(url) {
    try {
      const key = 'rtRedirect';
      const last = JSON.parse(sessionStorage.getItem(key) || 'null');
      if (last && last.url === url && Date.now() - last.t < 4000) return; // loop guard
      sessionStorage.setItem(key, JSON.stringify({ url, t: Date.now() }));
    } catch (e) { /* ignore */ }
    location.replace(url);
  }
  RT.go = go;
  const HOME_TARGET = { subscriptions: '/feed/subscriptions', watchlater: '/playlist?list=WL', library: '/feed/library' };
  function homeTarget() {
    const s = S();
    if (s.homeRedirect === 'custom') {
      const u = String(s.homeRedirectUrl || '').trim();
      if (/^\/(?!\/)/.test(u) && u !== '/') return u;
      if (/^https:\/\/www\.youtube\.com\/./.test(u)) return u;
      return null;
    }
    return HOME_TARGET[s.homeRedirect] || null;
  }
  let prevChannel = '';
  function redirects() {
    if (!RT.state) return;
    const page = RT.page(), path = location.pathname;
    if (page === 'home' && !location.search) {
      const t = homeTarget();
      if (t) return go(t);
    }
    if (on('hideShortsAll')) {
      if (path === '/shorts' || path === '/feed/shorts') return go('/');
      const tab = path.match(/^\/(@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)\/shorts\/?$/);
      if (tab) return go('/' + tab[1] + '/videos');
    }
    if (page === 'shorts' && (on('redirectShorts') || on('shortsAsVideos') || on('hideShortsAll'))) {
      const m = path.match(/^\/shorts\/([\w-]{11})/);
      if (m) return go('/watch?v=' + m[1]);
    }
    if (page === 'channel') {
      const m = path.match(/^\/(@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)\/?(featured)?$/);
      const base = (path.match(/^\/(@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)/) || [])[0] || '';
      const tab = S().channelDefaultTab;
      const same = prevChannel === base;
      prevChannel = base;
      if (m && tab && tab !== 'default' && !same) return go('/' + m[1] + '/' + tab);
    } else prevChannel = '';
  }
  RT.bus.addEventListener('apply', redirects);
  RT.bus.addEventListener('navigate', redirects);

  // ---- custom automation rules ------------------------------------------------------
  function ruleMatch(p) {
    const page = RT.page(), url = location.pathname + location.search;
    const m = p.match(/^\/(.+)\/([gimsuy]*)$/);
    if (m) { try { return new RegExp(m[1], m[2]).test(url); } catch (e) { return false; } }
    if (/^(home|watch|search|subs|channel|shorts|playlist|embed)$/i.test(p)) return p.toLowerCase() === page;
    return url.toLowerCase().indexOf(p.toLowerCase()) >= 0;
  }
  RT.rules = { player: {}, block: false };
  RT.ruleHides = [];
  function evalRules() {
    const out = { player: {}, block: false, tokens: [], hides: [], redirect: null };
    RT.lines(S().customRules).forEach((line) => {
      const i = line.indexOf('=>');
      if (i < 0) return;
      const p = line.slice(0, i).trim(), a = line.slice(i + 2).trim();
      if (!p || !a || !ruleMatch(p)) return;
      const c = a.indexOf(':');
      const name = (c < 0 ? a : a.slice(0, c)).trim().toLowerCase(), arg = c < 0 ? '' : a.slice(c + 1).trim();
      if (name === 'redirect' && arg) out.redirect = arg;
      else if (name === 'hide' && arg) out.hides.push(arg);
      else if (name === 'focus') out.tokens.push('focusMode');
      else if (name === 'zen') out.tokens.push('zenMode');
      else if (name === 'distraction') out.tokens.push('distractionBlocking');
      else if (name === 'block') out.block = true;
      else if (['speed', 'quality', 'theater', 'loop', 'mute', 'captions'].includes(name)) out.player[name] = arg || true;
    });
    RT.rules = out;
    RT.ruleHides = out.hides;
    return out;
  }
  const prevTokens = RT.extraTokens;
  RT.extraTokens = () => prevTokens().concat(evalRules().tokens);
  RT.bus.addEventListener('apply', () => {
    const r = RT.rules && RT.rules.redirect;
    if (r && /^\/(?!\/)|^https:\/\/www\.youtube\.com\//.test(r)) go(r);
  });

  // ---- hotkeys ----------------------------------------------------------------------------
  RT.comboFromEvent = (e) => {
    const k = e.key;
    if (['Control', 'Alt', 'Shift', 'Meta'].includes(k)) return '';
    const parts = [];
    if (e.ctrlKey) parts.push('Ctrl');
    if (e.altKey) parts.push('Alt');
    if (e.shiftKey) parts.push('Shift');
    if (e.metaKey) parts.push('Meta');
    let key = k.length === 1 ? k.toUpperCase() : k;
    if (e.altKey && /^Key[A-Z]$/.test(e.code)) key = e.code.slice(3);
    if (e.altKey && /^Digit\d$/.test(e.code)) key = e.code.slice(5);
    parts.push(key);
    return parts.join('+');
  };
  const norm = (c) => String(c).split('+').map((x) => x.trim().toLowerCase()).filter(Boolean).sort().join('+');
  function hotkeyMap() {
    const s = S(), map = new Map();
    const add = (combo, action) => { if (combo && action) map.set(norm(combo), action); };
    add(s.hk_focus, 'toggle:focusMode'); add(s.hk_zen, 'toggle:zenMode'); add(s.hk_distraction, 'toggle:distractionBlocking');
    add(s.hk_nextPreset, 'nextPreset'); add(s.hk_theater, 'theater');
    RT.lines(s.customHotkeys).forEach((l) => { const i = l.indexOf('='); if (i > 0) add(l.slice(0, i), l.slice(i + 1).trim()); });
    return map;
  }
  function video() { return document.querySelector('video.html5-main-video, video'); }
  RT.runAction = function (spec) {
    const [name, ...rest] = String(spec).split(':');
    const arg = rest.join(':');
    const s = S(), v = video();
    switch (name.trim()) {
      case 'toggle': if (RT.ITEMS[arg] && RT.ITEMS[arg].type === 'toggle') RT.save({ [arg]: !s[arg] }); break;
      case 'preset': RT.applyPreset(arg); break;
      case 'nextPreset': {
        chrome.storage.local.get(['rtPresets', 'activePreset'], (st) => {
          const names = RT.presetNames(st.rtPresets);
          RT.applyPreset(names[(names.indexOf(st.activePreset) + 1) % names.length]);
        });
        break;
      }
      case 'goto': if (/^\/(?!\/)/.test(arg)) location.assign(arg); break;
      case 'speed': if (v) { const n = parseFloat(arg); v.playbackRate = /^[+-]/.test(arg) ? Math.min(4, Math.max(0.25, v.playbackRate + n)) : n || 1; } break;
      case 'loop': if (v) v.loop = !v.loop; break;
      case 'theater': { const b = document.querySelector('.ytp-size-button'); if (b) b.click(); break; }
      case 'fullscreen': { const b = document.querySelector('.ytp-fullscreen-button'); if (b) b.click(); break; }
      case 'transcript': RT.bus.dispatchEvent(new Event('rt-transcript')); break;
      default: break;
    }
  };
  let hk = null;
  document.addEventListener('keydown', (e) => {
    if (!on('hotkeysOn') || e.repeat) return;
    const t = e.target;
    if (t && (/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName) || t.isContentEditable)) return;
    const combo = RT.comboFromEvent(e);
    if (!combo) return;
    if (!hk || hk.ver !== RT.version()) hk = { ver: RT.version(), map: hotkeyMap() };
    const action = hk.map.get(norm(combo));
    if (action) { e.preventDefault(); e.stopPropagation(); RT.runAction(action); }
  }, true);

  // ---- small helpers ----------------------------------------------------------------------------
  // Thumbnail hover previews: stop YouTube from starting them.
  ['mouseenter', 'mouseover', 'pointerenter'].forEach((type) =>
    document.addEventListener(type, (e) => {
      const t = e.target;
      if (t && t.closest && t.closest('ytd-thumbnail, yt-thumbnail-view-model')) e.stopImmediatePropagation();
    }, true));

  // Silent autoplay on feeds (inline previews, featured video): pause anything playing outside the real player.
  const stopSilent = () => {
    document.querySelectorAll('ytd-video-preview video, ytd-thumbnail video, yt-thumbnail-view-model video, ytd-rich-item-renderer video, ytd-rich-grid-renderer video').forEach((v) => {
      if (v.closest('#movie_player, ytd-player, ytd-reel-video-renderer, ytd-shorts')) return;
      if (!v.paused) { try { v.pause(); } catch (e) { /* ignore */ } }
    });
  };
  RT.bus.addEventListener('dom', stopSilent);
  setInterval(() => { try { stopSilent(); } catch (e) { /* ignore */ } }, 1500);

  // Header slides away; reveal at the top edge.
  let away = false;
  document.addEventListener('mousemove', (e) => {
    if (!on('headerAutoHide')) { if (away) { away = false; RT.dynSet('headerAway', null, null); } return; }
    const searching = document.activeElement && /^(INPUT|TEXTAREA)$/.test(document.activeElement.tagName);
    const want = e.clientY > 70 && !searching;
    if (want !== away) { away = want; RT.dynSet('headerAway', null, want ? 'rtHeaderAway' : null); }
  }, { passive: true });

  // "Filter this page" box.
  let pf = null;
  function pageFilter() {
    if (!on('inPageFilter')) { if (pf) { pf.remove(); pf = null; filter(''); } return; }
    if (pf && pf.isConnected) return;
    pf = document.createElement('input');
    pf.id = 'rt-page-filter';
    pf.placeholder = 'Filter this page…';
    pf.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483000;width:200px;padding:8px 12px;border-radius:18px;border:1px solid #888;background:#202020;color:#fff;font:14px Roboto,Arial,sans-serif;';
    pf.addEventListener('input', () => filter(pf.value));
    document.documentElement.appendChild(pf);
  }
  function filter(q) {
    q = q.trim().toLowerCase();
    document.querySelectorAll(RT.CARD_SEL + ', ytd-comment-thread-renderer').forEach((el) => {
      if (el.parentElement && el.parentElement.closest(RT.CARD_SEL)) return;
      RT.setHide(el, 'pf', !!q && (el.textContent || '').toLowerCase().indexOf(q) < 0);
    });
  }
  RT.bus.addEventListener('dom', () => { pageFilter(); if (pf && pf.value) filter(pf.value); });
})();
