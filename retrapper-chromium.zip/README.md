# ReTrapper

Cleans up and customizes YouTube. The toolbar popup shows **one section at a
time**; click the section name at the top to open a dropdown of all of them.

## Sections

Home page, Shorts, Video page, Player, Thumbnails, Search, Subscriptions,
Channel pages, Left navigation / sidebar, Top header, Recommendations,
Content filtering, Ads & promotions, Comments, Live chat, Metrics,
Interface / visual customization, Playback, Automation, Focus / productivity,
Presets, Keyboard shortcuts, Transcript, Access controls,
Notifications, Buttons, Page-specific controls, Embedded YouTube, and the
Watch Later shelf. The same option can appear in more than one section (it is
one setting); options that do the same thing share one switch and list the
other names under "Also:".

Defaults match the earlier version: no infinite scroll, hide watched videos,
hide view counts, hide badges, full-height theatre and comment sorting are on;
everything new is off.

## Things worth knowing

- **Automatic theme detection.** The extension works out whether YouTube is dark or light from what is actually painted (so other theme extensions are respected), then YouTube's own dark flag, text colour and your system setting, and follows changes live. The shelf and its menus use it by default, and the popup follows the theme YouTube was last seen in. The sun/moon and Light/Dark buttons are only overrides; tap the active one to go back to Auto.

- **Selectors can drift.** Hiding is done with CSS against YouTube's element
  names (and English button labels such as "Share"). If YouTube renames
  something, that switch stops working; "Customize individual UI elements"
  lets you add your own selectors. Nothing here was verified on live YouTube.
- **Ads:** "Hide ads" removes ad slots, banners and overlays, and also turns on
  **"Block video ads"**. That option strips the ad data out of YouTube's player
  response in the page's own context before the player reads it — the same
  method standalone ad blockers use — so pre-roll, mid-roll and skippable ads
  are not built and do not play. Anything that still slips through (for example
  an ad YouTube stitches into the stream server-side) is skipped and muted from
  the player. It needs no extra permissions and makes no new network requests.
  YouTube changes its player data often, so this can need updating; "Block
  video ads" can also be turned on or off on its own in the Ads section.
- **Anti-adblock pop-up:** when YouTube shows "Ad blockers are not allowed on
  YouTube" and pauses the video, "Block video ads" removes that dialog and
  resumes playback. This is done only in the page (hiding the dialog and
  pressing play) and never changes YouTube's player or streaming data, so it
  cannot stop a real video from loading. It is a moving target, so it may need
  further updates as YouTube changes its detection.
- **Fullscreen** can't start on its own (browsers require a click or key), so
  "Automatically enable fullscreen" starts on your first interaction.
## Install (Chrome / Edge / Brave, unpacked)

1. Unzip this folder somewhere permanent (don't delete it after installing —
   Chrome loads the extension from this folder each time).
2. Go to `chrome://extensions` (or `edge://extensions`, `brave://extensions`).
3. Turn on **Developer mode** (top right toggle).
4. Click **Load unpacked** and select this folder.
5. Click the extension's icon in the toolbar (pin it via the puzzle-piece
   icon if it's hidden) to see the settings. Pick a section from the dropdown at the top of the popup.

## Shelf menu and Remove all

- **3-dot menu on every shelf video** (shows on hover): Remove from Watch later
  (with an Undo toast) and Copy link.
- **Remove all videos** sits on the right of the shelf's title row and asks
  before emptying your whole Watch Later playlist.
- Edits are sent to YouTube's own edit-playlist endpoint using your existing
  signed-in session, the same call YouTube's own buttons make.

## Live updates and Clear button
- **Clear Watch Later:** on `youtube.com/playlist?list=WL` a single "Clear Watch Later"
  button appears in the playlist header (one button, not one per video). It asks first, then
  removes every video using YouTube's own "Remove from Watch later" menu entry one by one.
  Click it again to stop; videos already removed stay removed. It relies on YouTube's English menu wording.

- **Live shelf:** the shelf refreshes by itself when you add or remove a Watch
  Later video anywhere in this browser, when you return to the tab, and about
  every 90 seconds while the home page is open (this also catches changes made
  on another tab or device).

## How "From Your Watch Later" works

- `background.js` (service worker) fetches
  `https://www.youtube.com/playlist?list=WL` with your existing YouTube
  session and reads the video list from the page's embedded data.
- `watch-later.js` draws the shelf, measuring YouTube's own cards so sizes match.
- `page-bridge.js` runs in the page's own context so shelf clicks can use
  YouTube's in-page navigation (no reload).

If clicked videos don't start playing, allow autoplay for
`https://www.youtube.com` in `brave://settings/content/autoplay` (or your
browser's equivalent) and check Brave Shields isn't blocking it.
Not signed in, or an empty list, shows a short message instead of videos.

## Notes

- The home-page settings only affect `youtube.com/`; theatre mode and
  comments only affect `youtube.com/watch`. Search results and
  subscriptions feeds are untouched either way.
- If you had an earlier version of this extension installed, reload it
  from `chrome://extensions` to pick up these changes — this version adds
  a `host_permissions` entry for youtube.com and a background service
  worker, both needed for the Watch Later shelf.
- Settings are stored locally in the browser via `chrome.storage.local` —
  nothing is sent anywhere.
- YouTube changes its markup and internal data structure periodically. If
  a future change renames classes, restructures metadata, moves the
  theatre-mode container IDs, or changes the Watch Later page's data
  format, the corresponding feature may need updating.
- No data collection, no third-party servers — the only network request
  this extension makes is to youtube.com itself, for the Watch Later
  shelf.

## Dislike count
"Show dislike count" (Video page) adds the estimated dislike number next to the dislike button using the community Return YouTube Dislike API (returnyoutubedislikeapi.com). YouTube no longer publishes real counts, so the number is an estimate. Turn it off in the Video page section.

## Comment sorter
Replaces YouTube's "Sort by" button with one that offers Top (featured comments), Newest (recent comments, including potential spam), Most liked and Most replied. Top and Newest use YouTube's own sorting; Most liked and Most replied reorder the loaded Top comments and always keep pinned comments first. Your choice is remembered (Comments section in the popup).

## Exact upload dates
"Show exact upload date and time" (Metrics section) replaces "3 days ago" with `DD/MM/YYYY HH:MM` (your local time) on the home page, subscriptions, search, recommendations, the video page, and Shorts (shown above the channel name). If YouTube only provides a date, no time is shown; if it provides nothing, the original text stays. Dates for list pages are looked up as you scroll and cached. The option is skipped while "Hide publication date" or "Hide time since publication" is on.

## Better channel search
On channel pages a search bar is added above the channel's content (clicking YouTube's own magnifier focuses it too, and /@channel/search?query=... URLs use it). The channel's full upload list (videos, Shorts and live streams) is read once, cached on your computer and refreshed incrementally, then searched locally: every word must match, "quoted phrases" must appear exactly, -word excludes, small typos are tolerated, and there are Sort / Type / Uploaded / Duration filters like the main search page. Optionally it also asks YouTube's own search for matches in descriptions and transcripts and merges them in. Upload dates in this list are approximate (YouTube only gives "2 years ago" for lists).

## Channel search placement, grid view, global thumbnails
- The channel search box now sits in the tab row (Home / Videos / Playlists / Posts) and replaces YouTube's own search tab. If the tab row can't be found it falls back to a bar above the channel's content. Results (with filters) open below the tabs; the View filter switches between a list and a grid (the grid follows your channel "videos per row" setting if set).
- "Hide all thumbnails (everywhere)" in the Thumbnails section is now one switch for the whole site, including the Watch Later shelf and channel search results. The per-page thumbnail switches were removed from the Subscriptions and Channel pages sections.

## One thumbnail switch, one grid slider
- The Watch Later page's "Hide thumbnails" switch and the Thumbnails section's "Hide all thumbnails" are the same global setting now, and cover every page, the shelf and channel search.
- With "Set the number of videos per row on the Home page" on, the slider also sets the column count of the Search page results and of the channel search grid.

## Search in the menu
The popup has a "Search all settings" box under the title. It matches setting names, alternative names, descriptions and section names across every section; results can be changed right there, and "Open section" jumps to the full section. Esc clears it.
