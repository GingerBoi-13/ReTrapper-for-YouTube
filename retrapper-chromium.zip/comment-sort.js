// Comment sorter. Reorders the loaded top-level comments with CSS `order`
// (the page's own list is never touched), keeping pinned comments first.
(function () {
  'use strict';
  const RT = window.RT;
  if (!RT) return;
  const OPTIONS = [
    ['top', 'Top', 'Featured comments'],
    ['newest', 'Newest', 'Recent comments, including potential spam'],
    ['likes', 'Most liked', 'Pinned comments stay first'],
    ['replies', 'Most replied', 'Pinned comments stay first']
  ];
  const NAME = { top: 'Top', newest: 'Newest', likes: 'Most liked', replies: 'Most replied' };
  const YT_INDEX = { top: 0, newest: 1 };
  const PIN = -2147483000, LAST = 2147483000;

  const mode = () => {
    const v = RT.state && RT.state.S && RT.state.S.commentSort;
    return NAME[v] ? v : 'top';
  };
  let ytSort = 'top'; // which of YouTube's own sorts is showing

  function count(str) {
    const m = String(str || '').replace(/,/g, '').match(/([\d.]+)\s*([KMB])?/i);
    if (!m) return 0;
    const mult = { K: 1e3, M: 1e6, B: 1e9 }[(m[2] || '').toUpperCase()] || 1;
    return Math.round(parseFloat(m[1]) * mult) || 0;
  }
  const own = (thread, sel) => [...thread.querySelectorAll(sel)].find((e) => !e.closest('#replies'));

  function likes(thread) {
    const v = own(thread, '#vote-count-middle');
    const t = v && v.textContent.trim();
    if (t) return count(t);
    const b = own(thread, '#like-button button, like-button-view-model button, #like-button');
    const a = (b && b.getAttribute('aria-label')) || '';
    const m = a.match(/along with ([\d,.]+\s*[KMB]?)/i);
    return m ? count(m[1]) + 1 : 0;
  }
  function replies(thread) {
    const r = thread.querySelector('ytd-comment-replies-renderer');
    if (!r) return 0;
    const els = [...r.querySelectorAll('#more-replies button, #more-replies, .more-button')];
    for (const el of els) {
      const n = count(el.getAttribute('aria-label') || el.textContent || '');
      if (n) return n;
    }
    return 0;
  }
  const pinned = (thread) => !!own(thread, 'ytd-pinned-comment-badge-renderer');

  function clear(parent) {
    if (!parent) return;
    parent.style.removeProperty('display');
    parent.style.removeProperty('flex-direction');
    [...parent.children].forEach((c) => c.style.removeProperty('order'));
  }

  function run() {
    const threads = [...document.querySelectorAll('ytd-comments ytd-comment-thread-renderer')]
      .filter((t) => !t.closest('ytd-comment-replies-renderer'));
    const parents = new Set(threads.map((t) => t.parentElement));
    const m = RT.page() === 'watch' ? mode() : 'top';
    const client = m === 'likes' || m === 'replies' ? m : 'off';
    parents.forEach((p) => {
      if (!p) return;
      if (client === 'off') { if (p.__rtSorted) { clear(p); p.__rtSorted = false; } return; }
      p.__rtSorted = true;
      p.style.display = 'flex';
      p.style.flexDirection = 'column';
      [...p.children].forEach((c) => {
        if (c.tagName === 'YTD-COMMENT-THREAD-RENDERER') {
          const score = client === 'replies' ? replies(c) * 1e6 + likes(c) : likes(c);
          c.style.order = String(pinned(c) ? PIN : -Math.min(score, 2e9));
        } else if (/CONTINUATION/.test(c.tagName)) c.style.order = String(LAST);
      });
    });
    chip();
    onVideo();
  }

  // Drives YouTube's own (hidden) sort menu for Top / Newest.
  function ytSelect(which, tries) {
    const menu = document.querySelector('ytd-comments-header-renderer #sort-menu');
    if (!menu) { if ((tries || 0) < 10) setTimeout(() => ytSelect(which, (tries || 0) + 1), 400); return; }
    const trigger = menu.querySelector('#trigger, tp-yt-paper-button, #label, button');
    if (!trigger) return;
    trigger.click();
    setTimeout(() => {
      const items = menu.querySelectorAll('tp-yt-paper-listbox a, #menu a, a[role="option"], tp-yt-paper-item');
      const item = items[YT_INDEX[which]];
      if (item) item.click();
      else trigger.click(); // close again
      ytSort = which;
    }, 180);
  }

  function choose(v) {
    try { chrome.storage.local.set({ commentSort: v }); } catch (err) { /* ignore */ }
    if (RT.state && RT.state.S) RT.state.S.commentSort = v;
    const want = v === 'newest' ? 'newest' : 'top'; // likes/replies sort YouTube's Top list
    if (want !== ytSort) ytSelect(want);
    run();
  }

  // Colours come from ReTrapper's theme detector, so they follow the page's
  // real light / dark state instead of relying on YouTube's CSS variables.
  function pal() {
    const t = (RT.theme && RT.theme.theme) || (RT.detectTheme && RT.detectTheme().theme) || 'light';
    return t === 'dark'
      ? { fg: '#f1f1f1', sub: '#aaaaaa', menu: '#282828', hover: 'rgba(255,255,255,.15)', shadow: '0 4px 32px rgba(0,0,0,.6)' }
      : { fg: '#0f0f0f', sub: '#606060', menu: '#ffffff', hover: 'rgba(0,0,0,.08)', shadow: '0 4px 32px rgba(0,0,0,.25)' };
  }
  function paintChip() {
    const el = document.getElementById('rt-comment-sort');
    if (el) { el.style.color = pal().fg; el.style.background = 'transparent'; }
  }
  RT.bus.addEventListener('theme', () => { paintChip(); closePopup(); });

  let popup = null;
  const closePopup = () => { if (popup) { popup.remove(); popup = null; } };
  function openPopup(btn) {
    closePopup();
    popup = document.createElement('div');
    popup.id = 'rt-comment-sort-menu';
    popup.style.cssText = 'position:absolute;z-index:3000;min-width:260px;padding:8px 0;border-radius:12px;' +
      'background:' + pal().menu + ';color:' + pal().fg + ';box-shadow:' + pal().shadow + ';font-family:Roboto,Arial,sans-serif';
    OPTIONS.forEach(([id, label, sub]) => {
      const row = document.createElement('div');
      row.style.cssText = 'padding:8px 16px 8px 40px;cursor:pointer;position:relative;line-height:1.3';
      const t = document.createElement('div'); t.textContent = label; t.style.cssText = 'font-size:14px;font-weight:' + (id === mode() ? 600 : 400);
      const d = document.createElement('div'); d.textContent = sub; d.style.cssText = 'font-size:12px;color:' + pal().sub;
      if (id === mode()) { const ck = document.createElement('span'); ck.textContent = '✓'; ck.style.cssText = 'position:absolute;left:14px;top:8px;font-size:14px'; row.appendChild(ck); }
      row.append(t, d);
      row.addEventListener('mouseenter', () => { row.style.background = pal().hover; });
      row.addEventListener('mouseleave', () => { row.style.background = ''; });
      row.addEventListener('click', (e) => { e.stopPropagation(); closePopup(); choose(id); });
      popup.appendChild(row);
    });
    document.body.appendChild(popup);
    const r = btn.getBoundingClientRect();
    popup.style.left = Math.max(8, Math.min(r.left + scrollX, scrollX + innerWidth - 276)) + 'px';
    popup.style.top = r.bottom + scrollY + 6 + 'px';
  }
  document.addEventListener('click', (e) => { if (popup && !popup.contains(e.target) && e.target.id !== 'rt-comment-sort') closePopup(); }, true);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closePopup(); });

  // Our "Sort by" button replaces YouTube's, in the same spot.
  function chip() {
    const hdr = document.querySelector('ytd-comments-header-renderer');
    let el = document.getElementById('rt-comment-sort');
    if (!hdr || RT.page() !== 'watch') { if (el) el.remove(); closePopup(); return; }
    const menu = hdr.querySelector('#sort-menu');
    if (menu && !menu.__rtHidden) {
      menu.__rtHidden = true;
      // Kept in the page (we drive it for Top / Newest) but invisible.
      menu.style.cssText += ';position:absolute !important;opacity:0 !important;pointer-events:none !important;width:1px;height:1px;overflow:hidden';
    }
    if (!el) {
      el = document.createElement('button');
      el.id = 'rt-comment-sort';
      el.type = 'button';
      el.style.cssText = 'display:inline-flex;align-items:center;gap:6px;vertical-align:middle;margin-left:8px;padding:0 12px;height:36px;border-radius:18px;border:0;cursor:pointer;' +
        'font:500 14px Roboto,Arial,sans-serif;background:transparent;color:' + pal().fg;
      el.addEventListener('mouseenter', () => { el.style.background = pal().hover; });
      el.addEventListener('mouseleave', () => { el.style.background = 'transparent'; });
      el.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); popup ? closePopup() : openPopup(el); });
    }
    const head = menu ? menu.parentElement : hdr.querySelector('#title') || hdr;
    if (menu) { if (el.previousElementSibling !== menu) menu.after(el); }
    else if (el.parentElement !== head) head.appendChild(el);
    paintChip();
    const text = 'Sort by: ' + NAME[mode()] + ' ▾';
    if (el.textContent !== text) el.textContent = text;
  }

  // New video: YouTube starts on Top again; apply the saved choice.
  let lastVid = '';
  function onVideo() {
    const id = new URLSearchParams(location.search).get('v') || '';
    if (!id || id === lastVid || RT.page() !== 'watch') return;
    lastVid = id;
    ytSort = 'top';
    if (mode() === 'newest') setTimeout(() => ytSelect('newest'), 1500);
  }

  let t = 0;
  const soon = () => { clearTimeout(t); t = setTimeout(run, 150); };
  ['apply', 'navigate', 'dom'].forEach((ev) => RT.bus.addEventListener(ev, soon));
  setInterval(() => { if (RT.page() === 'watch') run(); }, 2500);
})();
