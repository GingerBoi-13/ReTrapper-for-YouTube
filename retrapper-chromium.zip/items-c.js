// Items: Sidebar, Header, Recommendations, Content filtering, Ads, Comments, Metrics, Notifications, Buttons.
(function () {
  'use strict';
  const RT = window.RT;
  const { toggle, number, select, range, text, area, multi } = RT._h;
  const { WATCH, HOME, SUBS, CHAN, SRCH } = RT.SEL;
  const both = (href) => [`ytd-guide-entry-renderer:has(a[href="${href}"])`, `ytd-mini-guide-entry-renderer:has(a[href="${href}"])`];

  // ---- Sidebar ----------------------------------------------------------------
  toggle('hideSidebarAll', 'Hide entire sidebar', {
    css: ['tp-yt-app-drawer', 'ytd-guide-renderer', 'ytd-mini-guide-renderer', '#guide-button'],
    rules: [['ytd-page-manager', 'margin-left:0'], ['ytd-app', '--ytd-mini-guide-width:0px']]
  });
  toggle('hideNavHome', 'Hide Home button', { css: both('/') });
  toggle('hideNavSubs', 'Hide Subscriptions button', { css: both('/feed/subscriptions') });
  toggle('hideNavLibrary', 'Hide Library button', { css: both('/feed/library').concat(both('/feed/you')) });
  toggle('hideExploreButton', 'Hide Explore button', { css: both('/feed/explore').concat(both('/feed/trending')) });
  toggle('hideMoreFromYT', 'Hide More From YouTube', {
    css: ['ytd-guide-section-renderer:has(a[href*="youtube.com/premium"])', 'ytd-guide-section-renderer:has(a[href*="music.youtube.com"])']
  });
  toggle('hideLibrarySection', 'Hide Library section', { css: ['ytd-guide-section-renderer:has(a[href="/feed/history"])'] });
  toggle('hideSubsSection', 'Hide Subscriptions section', {
    css: ['ytd-guide-section-renderer:has(a[href^="/@"])', 'ytd-guide-section-renderer:has(a[href^="/channel/"])']
  });
  toggle('hideHelperButtons', 'Hide helper buttons', {
    hint: 'Settings, Report history, Help, Send feedback.',
    css: ['ytd-guide-entry-renderer:has(a[href="/account"])', 'ytd-guide-entry-renderer:has(a[href="/reporthistory"])',
      'ytd-guide-entry-renderer:has(a[href*="support.google.com/youtube"])', 'ytd-guide-entry-renderer:has(a[href*="feedback"])']
  });
  toggle('hideGuideFooter', 'Hide footer', {
    css: ['ytd-guide-renderer #footer', '#footer.ytd-guide-renderer', 'ytd-guide-renderer #guide-links-primary', 'ytd-guide-renderer #guide-links-secondary', 'ytd-guide-renderer #copyright']
  });
  area('navSectionNames', 'Hide individual navigation sections (names, one per line)', { placeholder: 'Explore\nMore from YouTube' });
  area('navButtonNames', 'Hide individual navigation buttons (names, one per line)', { placeholder: 'History\nPlaylists' });
  area('sidebarSelectors', 'Customize sidebar (CSS selectors to hide, one per line)', { placeholder: 'ytd-guide-entry-renderer:nth-child(5)' });
  toggle('sidebarAutoCollapse', 'Collapse sidebar by default');

  // ---- Header -------------------------------------------------------------------
  toggle('hideHeader', 'Hide top header', {
    css: ['ytd-masthead', '#masthead-container'],
    rules: [['ytd-app', '--ytd-masthead-height:0px'], ['ytd-page-manager', 'margin-top:0']]
  });
  toggle('hideSearchBtn', 'Hide search button', { css: ['ytd-masthead #search-icon-legacy', 'ytd-searchbox #search-icon-legacy', 'yt-searchbox button.ytSearchboxComponentSearchButton'] });
  toggle('hideSearchBar', 'Hide search bar', { css: ['ytd-masthead #center', 'ytd-masthead ytd-searchbox', 'ytd-masthead yt-searchbox'] });
  toggle('hideLogo', 'Hide YouTube logo', { css: ['ytd-masthead ytd-topbar-logo-renderer', 'ytd-masthead #logo'] });
  toggle('disableLogoLink', 'Disable YouTube logo link', {
    rules: [['ytd-masthead ytd-topbar-logo-renderer a', 'pointer-events:none'], ['ytd-masthead #logo a', 'pointer-events:none']]
  });
  toggle('hideBell', 'Hide notifications bell', {
    alts: ['Hide notification bell'], css: ['ytd-masthead ytd-notification-topbar-button-renderer', 'ytd-notification-topbar-button-renderer']
  });
  toggle('hideCreate', 'Hide Create button', {
    css: ['ytd-masthead ytd-topbar-menu-button-renderer:has(#create-icon)', 'ytd-masthead ytd-topbar-menu-button-renderer:has(button[aria-label^="Create" i])',
      'ytd-masthead #buttons ytd-button-renderer:has(button[aria-label^="Create" i])', 'ytd-masthead #create-icon']
  });
  toggle('hideVoice', 'Hide voice-search button', { css: ['#voice-search-button', 'ytd-masthead #voice-search-button'] });
  toggle('hideHeaderControls', 'Hide header controls', {
    css: ['ytd-masthead #end #buttons > *:not(:has(#avatar-btn))', '#voice-search-button']
  });
  toggle('hideHeaderNav', 'Hide header navigation', { css: ['ytd-masthead #guide-button', '#guide-button'] });
  toggle('headerAutoHide', 'Auto-hide header', { hint: 'Header slides away; move the mouse to the top edge to bring it back.' });
  area('headerSelectors', 'Customize header (CSS selectors to hide, one per line)', { placeholder: 'ytd-masthead #end' });

  // ---- Recommendations ------------------------------------------------------------
  toggle('hideSuggestedContent', 'Hide suggested content', { implies: ['hideForYou', 'hidePeopleAlso', 'hideSearchRecs', 'hidePersonalized'] });
  area('recKeywords', 'Filter recommended videos (keywords)', { placeholder: 'reaction\nprank' });
  area('recTopics', 'Filter recommendation topics', { placeholder: 'politics\ncelebrity' });
  area('recBlockedChannels', 'Block recommendation sources (channels)', { placeholder: '@somechannel' });

  // ---- Content filtering ------------------------------------------------------------
  const list = (id, label, ph, o) => area(id, label, Object.assign({ placeholder: ph }, o));
  toggle('filtersEnabled', 'Block unwanted content', { def: true, hint: 'Master switch for the filter lists below.' });
  list('blockVideos', 'Block videos (IDs or URLs)', 'dQw4w9WgXcQ');
  list('blockChannels', 'Block channels (name, @handle or ID)', '@channel\nSome Channel');
  list('filterChannelIds', 'Filter by channel ID', 'UCxxxxxxxxxxxxxxxxxxxxxx');
  list('filterChannelKeywords', 'Filter channels by keyword', 'news');
  list('blockKeywords', 'Block keywords (title, channel, description)', 'giveaway');
  list('filterVideoKeywords', 'Filter videos by keyword (title)', 'shocking');
  list('blockTopics', 'Block topics', 'crypto\nastrology');
  list('muteTopics', 'Mute topics (dimmed, not hidden)', 'sports');
  list('filterRegex', 'Filter by regular expression', '/\\bepisode \\d+\\b/i');
  list('blockCommentAuthors', 'Block comments from users', '@someuser');
  list('commentKeywords', 'Filter comments by keyword', 'subscribe to my');
  list('commentRegex', 'Filter comments by regular expression', '/https?:\\/\\//i');
  toggle('matchVideos', 'Hide matching videos', { def: true });
  toggle('matchChannels', 'Hide matching channels', { def: true });
  toggle('matchComments', 'Hide matching comments', { def: true });
  toggle('matchTopics', 'Hide matching topics', { def: true });
  toggle('parentalFilter', 'Parental-control filtering', { hint: 'Hides videos matching a built-in list of adult terms plus yours.' });
  list('parentalWords', 'Extra parental-control words', 'word', { showIf: 'parentalFilter' });
  number('minDurationMin', 'Content-based filtering: hide videos shorter than (min)', 0, { max: 600 });
  number('maxDurationMin', 'Hide videos longer than (min)', 0, { max: 1440 });
  toggle('hideMixes', 'Hide mixes in feeds');
  toggle('filterFeeds', 'Feed filtering', { def: true, hint: 'Apply filters in Home, Subscriptions, Search and channels.' });
  toggle('filterRecsOn', 'Recommendation filtering', { def: true, hint: 'Apply filters to videos next to the player.' });

  // ---- Ads & promotions ----------------------------------------------------------------
  toggle('hideVideoAds', 'Hide video ads', { implies: ['hidePlayerAds', 'hideVideoPromos'], hint: 'Hides ad overlays. Does not block ad videos.' });
  toggle('hideBannerAds', 'Hide banner ads', {
    css: ['#masthead-ad', 'ytd-banner-promo-renderer', 'ytd-statement-banner-renderer', 'ytd-video-masthead-ad-v3-renderer',
      'ytd-primetime-promo-renderer', 'ytd-brand-video-shelf-renderer', 'ytd-brand-video-singleton-renderer', '#player-ads']
  });
  toggle('hideAdSlots', 'Hide advertisement slots', {
    css: ['ytd-ad-slot-renderer', 'ytd-in-feed-ad-layout-renderer', 'ytd-display-ad-renderer', 'ytd-promoted-sparkles-web-renderer',
      'ytd-promoted-video-renderer', 'ytd-companion-slot-renderer', 'ytd-action-companion-ad-renderer',
      'ytd-rich-item-renderer:has(ytd-ad-slot-renderer)', 'ytd-rich-section-renderer:has(ytd-ad-slot-renderer)', 'ytd-search-pyv-renderer']
  });
  toggle('removePromoUI', 'Remove promotional UI', {
    css: ['ytd-mealbar-promo-renderer', 'yt-mealbar-promo-renderer', 'ytd-feed-nudge-renderer', 'ytd-rich-section-renderer:has(ytd-feed-nudge-renderer)',
      'ytd-guide-entry-renderer:has(a[href*="/premium"])', 'ytd-mini-guide-entry-renderer:has(a[href*="/premium"])',
      'ytd-masthead ytd-button-renderer:has(a[href*="premium"])']
  });

  // ---- Comments -----------------------------------------------------------------------------
  multi('commentFilters', 'Content-filter comments', [
    { v: 'links', l: 'Links' }, { v: 'spam', l: 'Self-promo / spam' }, { v: 'caps', l: 'ALL CAPS' },
    { v: 'emoji', l: 'Emoji only' }, { v: 'short', l: 'Very short' }
  ]);
  select('commentSort', 'Sort comments', [['top', 'Top (featured comments)'], ['newest', 'Newest (recent, may include spam)'], ['likes', 'Most liked'], ['replies', 'Most replied']], 'top', {
    hint: 'Replaces YouTube\'s Sort by button. Most liked / replied reorder the loaded comments and keep pinned comments on top.'
  });

  // ---- Metrics -----------------------------------------------------------------------------------
  toggle('hideOtherMetrics', 'Hide other engagement metrics', { hint: 'Watching-now, video counts, member counts.' });
  toggle('hideBadges', 'Hide hype/trending badges', { def: false });

  // ---- Notifications ---------------------------------------------------------------------------------
  toggle('removeNotifications', 'Remove notifications', { implies: ['hideBell'], hint: 'Also strips the "(3)" unread count from the tab title.' });
  toggle('hideNotificationUI', 'Hide notification UI', {
    css: ['ytd-notification-renderer', 'ytd-notification-topbar-button-renderer #notification-count', 'yt-icon-badge #notification-count',
      'ytd-notification-topbar-button-renderer .yt-spec-icon-badge-shape__badge']
  });
  toggle('hideNotificationRelated', 'Hide notification-related elements', {
    css: ['ytd-subscription-notification-toggle-button-renderer-next', '#notification-preference-button', 'ytd-mealbar-promo-renderer']
  });

  // ---- Buttons -----------------------------------------------------------------------------------------
  toggle('hideActionButtons', 'Hide action buttons', {
    css: [`${WATCH} ytd-watch-metadata #actions`, 'ytd-comment-engagement-bar #toolbar', 'ytd-comment-view-model #toolbar']
  });
  toggle('hideLikeDislike', 'Hide Like/Dislike controls', { implies: ['hideLike', 'hideDislike'] });
  toggle('hideOtherPlayerButtons', 'Hide other player/page buttons', {
    implies: ['hideOtherButtons'], css: ['.ytp-remote-button', '.ytp-miniplayer-button', '.ytp-pip-button']
  });
  multi('customVisibleButtons', 'Customize visible buttons', [
    { v: 'subscribe', l: 'Subscribe', css: [`${WATCH} #subscribe-button`, `${WATCH} yt-subscribe-button-view-model`] },
    { v: 'join', l: 'Join', css: [`${WATCH} #sponsor-button`] },
    { v: 'bell', l: 'Notify bell', css: [`${WATCH} ytd-subscription-notification-toggle-button-renderer-next`] },
    { v: 'thanks', l: 'Thanks', css: RT.btn('Thanks') },
    { v: 'ask', l: 'Ask', css: RT.btn('Ask') },
    { v: 'autoplay', l: 'Autoplay switch', css: ['.ytp-autonav-toggle-button-container'] }
  ]);
})();
