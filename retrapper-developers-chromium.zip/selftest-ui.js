// Full self-test driver. Part 1: opens the popup inside this page and uses every section and setting.
// Part 2: opens YouTube and asks selftest.js there to crawl the pages. Settings are restored at the end.
(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const get = (k) => new Promise((r) => chrome.storage.local.get(k, r));
  const set = (o) => new Promise((r) => chrome.storage.local.set(o, r));
  const remove = (k) => new Promise((r) => chrome.storage.local.remove(k, r));
  const CTRL = ['rtSelfTestResult', 'rtSelfTestProgress', 'rtSelfTestBackup', 'rtSelfTestPlan', 'rtSelfTestPopup'];
  const SKIP_IDS = new Set(['homeRedirect', 'homeRedirectUrl', 'openingDelay', 'accessIntent', 'sessionLimitMin', 'dailyLimitMin', 'focusRestrictions', 'focusMode',
    'distractionBlocking', 'autoFocusMode', 'autoDistractionBlock', 'autoDistractAfterMin', 'focusSchedule', 'customRules', 'presetAuto', 'presetSchedule',
    'wPassword', 'wTimerBlock', 'wTimerFocus', 'wTimerDistract', 'wPresets', 'timeReminderMin', 'fullTitles', 'useDearrow',
    'channelDefaultTab', 'autoPip', 'autoFullscreen', 'redirectShorts', 'shortsAsVideos']);
  const SKIP_RE = /dearrow|password|^hk_|^wTimer/i;
  const OK = new Set(['applied', 'hides it', 'nothing here to hide']);
  const report = { popup: { sections: [], options: [] }, pages: null, notes: [] };
  let stop = false, orig = null;

  const say = (t, d) => { $('status').textContent = t; $('detail').textContent = d || ''; };
  const log = (t, bad) => { const d = document.createElement('div'); if (bad) d.className = 'bad'; d.textContent = t; $('log').appendChild(d); };

  async function backup() {
    const all = await get(null);
    CTRL.forEach((k) => delete all[k]);
    orig = all;
    await set({ rtSelfTestBackup: { orig, at: Date.now() } });
  }
  async function restore() {
    if (!orig) return;
    const now = await get(null);
    const gone = Object.keys(now).filter((k) => !(k in orig) && !CTRL.includes(k));
    if (gone.length) await remove(gone);
    await set(orig);
    await remove('rtSelfTestBackup');
  }

  // ---- part 1: the popup -----------------------------------------------------------------------------
  function loadFrame() {
    return new Promise((res) => { const f = $('frame'); f.onload = () => res(f); f.src = 'popup.html'; });
  }
  const ctl = (row, it) => {
    switch (it.type) {
      case 'toggle': return row.querySelector('.switch input');
      case 'select': return row.querySelector('select');
      case 'range': return row.querySelector('input[type=range]');
      case 'number': return row.querySelector('input[type=number]');
      case 'text': return row.querySelector('input[type=text]');
      case 'textarea': return row.querySelector('textarea');
      case 'multi': return row.querySelector('.chk input');
      default: return null;
    }
  };
  async function stored(id) { return (await get(id))[id]; }
  const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);

  async function testRow(win, rec, secTitle) {
    const it = rec.it, row = rec.el, c = ctl(row, it);
    const out = { id: it.id, section: secTitle, status: 'applied' };
    if (!c) { out.status = 'nothing here to hide'; out.note = 'custom control, not driven'; return out; }
    const doc = win.document;
    const fire = (type) => c.dispatchEvent(new win.Event(type, { bubbles: true }));
    let want;
    try {
      switch (it.type) {
        case 'toggle': c.checked = !c.checked; want = c.checked; fire('change'); await sleep(90); break;
        case 'select': { const o = [...c.options].find((x) => x.value !== c.value); if (!o) return out; c.value = o.value; want = o.value; fire('change'); await sleep(90); break; }
        case 'range': c.value = c.max; want = +c.value; fire('input'); await sleep(90); break;
        case 'number': c.value = String(Math.min(it.max != null ? it.max : 1e9, (+c.value || 0) + 1)); want = +c.value; fire('change'); await sleep(90); break;
        case 'text': c.value = 'test'; want = 'test'; fire('input'); await sleep(420); break;
        case 'textarea': c.value = 'test'; want = 'test'; fire('input'); await sleep(520); break;
        case 'multi': c.checked = !c.checked; fire('change'); await sleep(90); want = undefined; break;
      }
      const got = await stored(it.id);
      if (it.type === 'multi') { if (!Array.isArray(got)) out.status = 'NOT SAVED'; }
      else if (it.type === 'select') { if (String(got) !== String(want)) { out.status = 'NOT SAVED'; out.got = got; } }
      else if (!same(got, want)) { out.status = 'NOT SAVED'; out.got = got; out.want = want; }
    } catch (e) { out.status = 'ERROR'; out.error = String(e && e.message).slice(0, 120); }
    return out;
  }

  async function popupPart() {
    say('Part 1 of 2: the popup', 'Opening every section.');
    const f = await loadFrame();
    const win = f.contentWindow, doc = f.contentDocument;
    const errs = [];
    win.addEventListener('error', (e) => errs.push(String(e.message).slice(0, 140)));
    await sleep(600);
    const ids = () => {
      doc.getElementById('secBtn').click();
      const out = [...doc.querySelectorAll('#secMenu button[data-id]')].map((b) => ({ id: b.dataset.id, title: b.textContent }));
      doc.getElementById('secBtn').click();
      return out;
    };
    const main = ids();
    const gear = doc.getElementById('gearBtn');
    const clickSection = async (id) => {
      doc.getElementById('secBtn').click();
      const b = doc.querySelector('#secMenu button[data-id="' + id + '"]');
      if (!b) return null;
      b.click(); await sleep(250);
      return b.textContent;
    };
    let n = 0;
    for (const s of main) {
      if (stop) break;
      const title = await clickSection(s.id);
      const shown = doc.getElementById('secName').textContent;
      const rec = { id: s.id, title: s.title, opened: shown === s.title, rows: 0 };
      const rows = win.__rtRows ? win.__rtRows().slice() : [];
      rec.rows = rows.length;
      report.popup.sections.push(rec);
      log('Popup section "' + s.title + '": ' + (rec.opened ? 'opened' : 'DID NOT OPEN') + ', ' + rows.length + ' options', !rec.opened);
      for (const r of rows) {
        if (stop) break;
        const it = r.it;
        if (!it || SKIP_IDS.has(it.id) || SKIP_RE.test(it.id)) continue;
        n++;
        if (n % 4 === 0) say('Part 1 of 2: the popup', s.title + ' - ' + n + ' options checked');
        const prev = (await get(it.id))[it.id];
        const res = await testRow(win, r, s.title);
        report.popup.options.push(res);
        if (!OK.has(res.status)) log('  ' + it.id + ': ' + res.status, true);
        if (prev === undefined) await remove(it.id); else await set({ [it.id]: prev });
        await sleep(30);
      }
      await get(null);
      // re-load the section so the controls match the restored values
      await clickSection(s.id);
    }
    // settings pages through the gear
    if (!stop) {
      gear.click(); await sleep(250);
      const sets = ids();
      for (const s of sets) {
        const shown0 = await clickSection(s.id);
        const shown = doc.getElementById('secName').textContent;
        const hasBody = !!(doc.getElementById('dyn').children.length || !doc.getElementById('settingsPanel').hidden || !doc.getElementById('reportPanel').hidden || !doc.getElementById('orderPanel').hidden);
        const ok = shown === s.title && hasBody;
        report.popup.sections.push({ id: s.id, title: s.title, opened: ok, settings: true });
        log('Settings page "' + s.title + '": ' + (ok ? 'opened' : 'DID NOT OPEN'), !ok);
      }
      doc.getElementById('gearBtn').click(); await sleep(250);
      const back = doc.getElementById('secName').textContent;
      log('Back button returns to a main section: ' + back, !back);
    }
    if (errs.length) { report.popup.errors = errs.slice(0, 10); errs.slice(0, 5).forEach((e) => log('Popup error: ' + e, true)); }
    await restore();
    await set({ rtSelfTestPopup: { at: new Date().toISOString(), sections: report.popup.sections.length, options: report.popup.options.length } });
    // restore removes the backup key; take a fresh backup for the YouTube part
    await backup();
  }

  // ---- part 2: YouTube ------------------------------------------------------------------------------
  const tabsQuery = (q) => new Promise((r) => chrome.tabs.query(q, r));
  async function findTab() {
    const t = (await tabsQuery({ url: ['https://www.youtube.com/*'] })).filter((x) => !/\/embed\//.test(x.url));
    if (t.length) return t[0];
    return new Promise((r) => chrome.tabs.create({ url: 'https://www.youtube.com/', active: true }, r));
  }
  const send = (id, msg) => new Promise((r) => chrome.tabs.sendMessage(id, msg, (x) => r(chrome.runtime.lastError ? null : x)));

  async function pagesPart() {
    say('Part 2 of 2: YouTube', 'Opening YouTube.');
    const tab = await findTab();
    await chrome.tabs.update(tab.id, { active: true });
    await remove(['rtSelfTestProgress', 'rtSelfTestResult']);
    const crawlStart = Date.now();
    let started = null;
    for (let i = 0; i < 3 && !started && !stop; i++) {
      await sleep(1500);
      started = await send(tab.id, { type: 'RT_SELFTEST_CRAWL' });
    }
    if (!started && !stop) {
      // A YouTube tab opened before the extension was updated still runs the old code. Reload it and try again.
      say('Part 2 of 2: YouTube', 'Reloading the YouTube tab.');
      await new Promise((r) => chrome.tabs.reload(tab.id, {}, () => r()));
      await sleep(6000);
      for (let i = 0; i < 20 && !started && !stop; i++) {
        await sleep(1500);
        started = await send(tab.id, { type: 'RT_SELFTEST_CRAWL' });
      }
    }
    if (!started) { report.notes.push('Could not start on YouTube. Reload the YouTube tab and try again.'); log('Could not reach the YouTube page. Reload it and try again.', true); return; }
    let last = '';
    for (;;) {
      await sleep(1500);
      const st = await get(['rtSelfTestProgress', 'rtSelfTestPlan']);
      const p = st.rtSelfTestProgress || {};
      const msg = p.note || ('Testing the ' + (p.page || '...') + ' page' + (p.total ? ': ' + p.done + ' of ' + p.total : ''));
      const head = p.steps ? 'Part 2 of 2: YouTube, page ' + Math.min(p.step || 1, p.steps) + ' of ' + p.steps : 'Part 2 of 2: YouTube';
      if (head + msg !== last) { say(head, msg); last = head + msg; }
      if (p.state === 'done' && p.crawl) { if (p.skipped && p.skipped.length) report.notes.push('Could not reach these pages: ' + p.skipped.join(', ')); if (p.error) report.notes.push('Stopped: ' + p.error); break; }
      if (!st.rtSelfTestPlan && p.state !== 'running' && Date.now() - crawlStart > 90000) { report.notes.push('The YouTube part stopped without finishing.'); break; }
      if (stop) { await send(tab.id, { type: 'RT_SELFTEST_STOP' }); }
    }
    report.pages = (await get('rtSelfTestResult')).rtSelfTestResult || null;
  }

  // ---- results --------------------------------------------------------------------------------------
  function summarize() {
    const L = [];
    const po = report.popup.options, bad = po.filter((r) => !OK.has(r.status));
    const sbad = report.popup.sections.filter((s) => !s.opened);
    L.push('Popup: ' + report.popup.sections.length + ' sections, ' + po.length + ' options, ' + (bad.length + sbad.length) + ' problem(s).');
    bad.forEach((r) => L.push('  ' + r.section + ' / ' + r.id + ': ' + r.status + (r.error ? ' ' + r.error : '')));
    sbad.forEach((s) => L.push('  section did not open: ' + s.title));
    if (report.pages && report.pages.pages) {
      Object.keys(report.pages.pages).forEach((pg) => {
        const rows = report.pages.pages[pg].results || [], b = rows.filter((r) => !OK.has(r.status));
        const hid = rows.filter((r) => r.status === 'hides it').length;
        L.push('YouTube ' + pg + ' page: ' + rows.length + ' options, ' + b.length + ' problem(s), ' + hid + ' confirmed hiding.');
        b.forEach((r) => L.push('  ' + r.id + ': ' + r.status + (r.errors ? ' ' + r.errors.join(' | ') : '')));
      });
    } else L.push('YouTube pages: not tested.');
    report.notes.forEach((n) => L.push('Note: ' + n));
    return L;
  }
  function show() {
    const L = summarize();
    const total = L.filter((l) => /^(Popup|YouTube)/.test(l)).join(' ');
    const anyBad = L.some((l) => /[1-9]\d* problem|^Note:|DID NOT|ERROR|NOT SAVED/.test(l));
    say('Done. ' + (anyBad ? 'Some problems were found.' : 'No problems found.'), 'Your settings were put back. Press Copy results and paste them into the chat.');
    $('status').className = anyBad ? 'bad' : 'good';
    $('log').textContent = '';
    L.forEach((l) => log(l, /problem\(s\)\.$/.test(l) && !/ 0 problem/.test(l) || /^  /.test(l)));
    $('copy').hidden = false;
    $('copy').onclick = async () => {
      const compact = { version: (report.pages && report.pages.version) || '', userAgent: navigator.userAgent, summary: L, popupProblems: report.popup.options.filter((r) => !OK.has(r.status)), notes: report.notes, pages: {} };
      if (report.pages && report.pages.pages) Object.keys(report.pages.pages).forEach((pg) => { const rows = report.pages.pages[pg].results; compact.pages[pg] = { tested: rows.length, problems: rows.filter((r) => !OK.has(r.status)), all: rows.map((r) => r.id + ':' + r.status) }; });
      const t = JSON.stringify(compact, null, 1);
      try { await navigator.clipboard.writeText(t); $('detail').textContent = 'Results copied. Paste them into the chat.'; }
      catch (e) { const a = document.createElement('textarea'); a.style.cssText = 'width:100%;height:160px'; a.value = t; document.body.appendChild(a); a.select(); $('detail').textContent = 'Select all in the box below and copy it.'; }
    };
  }

  let startedAt = 0;
  $('go').onclick = async () => {
    $('go').hidden = true; $('stop').hidden = false; $('copy').hidden = true; $('log').textContent = ''; stop = false; $('status').className = '';
    startedAt = Date.now();
    report.popup = { sections: [], options: [] }; report.pages = null; report.notes = [];
    try {
      await backup();
      await popupPart();
      if (!stop) await pagesPart();
    } catch (e) { report.notes.push('Stopped: ' + String(e && e.message)); }
    try { await restore(); } catch (e) { /* ignore */ }
    $('stop').hidden = true; $('go').hidden = false; $('go').textContent = 'Run again';
    show();
    // Bring this page back to the front so the results are the first thing you see.
    try {
      chrome.tabs.getCurrent((me) => {
        if (!me) return;
        chrome.tabs.update(me.id, { active: true });
        if (chrome.windows && chrome.windows.update) chrome.windows.update(me.windowId, { focused: true });
      });
    } catch (e) { /* ignore */ }
  };
  $('stop').onclick = () => { stop = true; $('stop').hidden = true; say('Stopping...', 'Putting your settings back.'); };
  window.addEventListener('beforeunload', () => { /* settings are restored by selftest.js if the tab is closed mid-run */ });
})();
