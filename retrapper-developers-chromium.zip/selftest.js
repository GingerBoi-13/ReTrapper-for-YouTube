// Self-test. Turns each option on, one at a time, checks that nothing breaks and that "hide" options really
// hide something, then puts every setting back. It can test the page that is open, or "crawl": go through
// Home, Subscriptions, Search, a video, a channel and Shorts by itself, clicking from one to the next.
// Options that could lock, redirect or block the page, and DeArrow-related ones, are skipped.
(function () {
  'use strict';
  if (window.top !== window || !window.RT || !chrome.storage) return;
  const RT = window.RT;
  const RESULT = 'rtSelfTestResult', PROGRESS = 'rtSelfTestProgress', BACKUP = 'rtSelfTestBackup', PLAN = 'rtSelfTestPlan';
  const CTRL = [RESULT, PROGRESS, BACKUP, PLAN, 'rtSelfTestPopup'];
  const STEPS = ['home', 'subs', 'search', 'watch', 'channel', 'shorts'];
  const SKIP_IDS = new Set(['homeRedirect', 'homeRedirectUrl', 'openingDelay', 'accessIntent', 'sessionLimitMin', 'dailyLimitMin', 'focusRestrictions', 'focusMode',
    'distractionBlocking', 'autoFocusMode', 'autoDistractionBlock', 'autoDistractAfterMin', 'focusSchedule', 'customRules', 'presetAuto', 'presetSchedule',
    'wPassword', 'wTimerBlock', 'wTimerFocus', 'wTimerDistract', 'wPresets', 'timeReminderMin', 'fullTitles', 'useDearrow',
    'channelDefaultTab', 'autoPip', 'autoFullscreen', 'redirectShorts', 'shortsAsVideos']);
  const SKIP_RE = /dearrow|password|^hk_|^wTimer/i;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const get = (k) => new Promise((r) => chrome.storage.local.get(k, r));
  const set = (o) => new Promise((r) => chrome.storage.local.set(o, r));
  const remove = (k) => new Promise((r) => chrome.storage.local.remove(k, r));
  const q = (s) => { try { return document.querySelector(s); } catch (e) { return null; } };
  let running = false, stopFlag = false, beat = 0;

  chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch[PLAN] && ch[PLAN].newValue && ch[PLAN].newValue.stop) stopFlag = true; });

  // A reload in the middle of a single-page test would leave test values behind, so restore from the backup.
  // A crawl moves between pages on purpose and keeps its own heartbeat, so it is left alone.
  async function restoreBackup(force) {
    const b = (await get(BACKUP))[BACKUP];
    if (!b) return false;
    const plan = (await get(PLAN))[PLAN];
    if (!force && plan && Date.now() - plan.at < 20000) return false;
    const now = await get(null);
    const gone = Object.keys(now).filter((k) => !(k in b.orig) && !CTRL.includes(k));
    if (gone.length) await remove(gone);
    await set(b.orig);
    await remove(BACKUP);
    return true;
  }
  restoreBackup(false).then((did) => { if (did) set({ [PROGRESS]: { state: 'restored', note: 'The page was reloaded during a self-test; your settings were put back.' } }); });

  const val = (m) => {
    switch (m.type) {
      case 'toggle': return true;
      case 'select': { const o = (m.options || []).map((x) => (Array.isArray(x) ? x[0] : x && x.value !== undefined ? x.value : x)); return o.find((x) => x !== m.def) ?? m.def; }
      case 'range': return m.max;
      case 'number': return (m.def || 0) + 1;
      case 'text': case 'textarea': return 'test';
      case 'multi': { const o = m.options || []; return o.length ? [o[0].v !== undefined ? o[0].v : o[0]] : undefined; }
      default: return undefined;
    }
  };
  const selectorsOf = (m) => [].concat(m.css || [], (m.rules || []).map((r) => r[0])).filter(Boolean);
  const isHidden = (e) => {
    const cs = getComputedStyle(e);
    if (cs.display === 'none' || cs.visibility === 'hidden') return true;
    const r = e.getBoundingClientRect();
    return r.width === 0 && r.height === 0;
  };

  // Tests every option on the page that is open. Each option is put back to its original value afterwards.
  async function testPage(orig, info) {
    const errors = [];
    const onErr = (e) => { const m = String(e.message || e.reason || e); if (/ResizeObserver loop/i.test(m)) { if (e.preventDefault) e.preventDefault(); return; } errors.push(m.slice(0, 160)); };
    window.addEventListener('error', onErr);
    window.addEventListener('unhandledrejection', onErr);
    const ce = console.error;
    console.error = function () { try { errors.push([].map.call(arguments, (a) => (a && a.message) || String(a)).join(' ').slice(0, 160)); } catch (e) { /* ignore */ } return ce.apply(this, arguments); };
    const page = RT.page();
    const results = [];
    try {
      const items = Object.values(RT.ITEMS).filter((m) => !SKIP_IDS.has(m.id) && !SKIP_RE.test(m.id) && val(m) !== undefined);
      let n = 0;
      for (const m of items) {
        if (stopFlag) break;
        n++;
        if (n % 5 === 0) await set({ [PROGRESS]: Object.assign({ state: 'running', page, done: n, total: items.length }, info || {}) });
        const sels = m.type === 'toggle' ? selectorsOf(m) : [];
        let bad = false;
        const query = () => { const out = []; sels.forEach((s) => { try { document.querySelectorAll(s).forEach((e) => out.push(e)); } catch (e) { bad = true; } }); return out; };
        const before = errors.length;
        // Options that are on by default are switched off first so turning them on is a real change.
        if (m.type === 'toggle' && m.def) { await set({ [m.id]: false }); await sleep(110); }
        await set({ [m.id]: val(m) });
        await sleep(200);
        const el = query();
        const matched = el.length;
        const hidden = el.filter(isHidden).length;
        const token = m.type !== 'toggle' || !sels.length || new RegExp('(^|\\s)' + m.id + '(\\s|$)').test(document.documentElement.getAttribute('data-rt') || '');
        let status = 'applied';
        if (errors.length > before) status = 'ERROR';
        else if (bad) status = 'BAD SELECTOR';
        else if (!document.body || !document.body.children.length) status = 'PAGE EMPTIED';
        else if (!token) status = 'NOT APPLIED';
        else if (m.type === 'toggle' && sels.length && m.css && m.css.length && !m.rules) status = matched === 0 ? 'nothing here to hide' : hidden > 0 ? 'hides it' : 'DID NOT HIDE';
        const row = { id: m.id, status };
        if (status === 'ERROR') row.errors = errors.slice(before, before + 3);
        if (status === 'DID NOT HIDE' || status === 'hides it') row.matched = matched;
        results.push(row);
        if (m.id in orig) await set({ [m.id]: orig[m.id] }); else await remove(m.id);
      }
    } catch (e) {
      results.push({ id: '(test stopped)', status: 'ERROR', errors: [String(e && e.message)] });
    } finally {
      window.removeEventListener('error', onErr);
      window.removeEventListener('unhandledrejection', onErr);
      console.error = ce;
    }
    const prev = (await get(RESULT))[RESULT] || { pages: {} };
    prev.version = String(document.documentElement.getAttribute('data-rt-version') || '');
    prev.userAgent = navigator.userAgent;
    prev.pages[page] = { at: new Date().toISOString(), tested: results.length, results };
    await set({ [RESULT]: prev });
    return { page, tested: results.length };
  }

  async function snapshot() {
    const orig = await get(null);
    CTRL.forEach((k) => delete orig[k]);
    await set({ [BACKUP]: { orig, at: Date.now() } });
    return orig;
  }

  // ---- test the page that is open -----------------------------------------------------------------
  async function singleRun() {
    if (running) return;
    running = true; stopFlag = false;
    try {
      const orig = await snapshot();
      const r = await testPage(orig);
      await restoreBackup(true);
      await set({ [PROGRESS]: { state: 'done', page: r.page, total: r.tested } });
    } finally { running = false; }
  }

  // ---- crawl: go through the pages by itself ------------------------------------------------------
  async function settle() {
    for (let i = 0; i < 60 && document.readyState !== 'complete'; i++) await sleep(250);
    for (let i = 0; i < 40 && !(q('ytd-app') && RT.state); i++) await sleep(250);
    await sleep(3500);
  }
  const hrefOf = (sel) => { const a = q(sel); return a ? a.getAttribute('href') : null; };
  function collectLinks(plan) {
    const L = plan.links = plan.links || {};
    if (!L.video) { const a = [...document.querySelectorAll('a[href^="/watch?v="]')].find((x) => /^\/watch\?v=[\w-]{11}/.test(x.getAttribute('href'))); if (a) L.video = a.getAttribute('href'); }
    if (!L.channel) { const a = [...document.querySelectorAll('a[href^="/@"]')].find((x) => /^\/@[^/?#]+/.test(x.getAttribute('href'))); if (a) L.channel = a.getAttribute('href').split('?')[0].replace(/\/$/, ''); }
    if (!L.shorts) { const s = hrefOf('a[href^="/shorts/"]'); if (s) L.shorts = s; }
  }
  const onStep = (step) => {
    const p = RT.page();
    if (step === 'search') return location.pathname === '/results';
    return p === step;
  };
  async function waitFor(step, ms) {
    for (let t = 0; t < ms; t += 400) { if (onStep(step)) return true; await sleep(400); }
    return onStep(step);
  }
  // Click through to the next page like a person would; fall back to loading its address.
  async function goTo(step, plan) {
    const L = plan.links || {};
    const byHref = (h) => (h ? [...document.querySelectorAll('a[href]')].find((a) => a.getAttribute('href') === h) : null);
    const target = {
      home: () => q('ytd-guide-entry-renderer a[href="/"], ytd-mini-guide-entry-renderer a[href="/"]') || q('a#logo'),
      subs: () => q('a[href="/feed/subscriptions"]'),
      watch: () => byHref(L.video) || q('a[href^="/watch?v="]'),
      channel: () => byHref(L.channel) || q('a[href^="/@"]'),
      shorts: () => byHref(L.shorts) || q('a[href^="/shorts/"]')
    };
    const fallback = { home: '/', subs: '/feed/subscriptions', search: '/results?search_query=test', watch: L.video, channel: L.channel ? L.channel + '/videos' : null, shorts: L.shorts };
    try {
      if (step === 'search') {
        const box = q('input#search') || q('ytd-searchbox input') || q('input[name="search_query"]');
        if (box) {
          box.focus(); box.value = 'test'; box.dispatchEvent(new Event('input', { bubbles: true }));
          const btn = q('button#search-icon-legacy') || q('ytd-searchbox button[aria-label="Search"]') || q('#search-icon-legacy');
          if (btn) btn.click(); else box.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
        }
      } else {
        const a = target[step] && target[step]();
        if (a) a.click();
      }
    } catch (e) { /* fall back below */ }
    if (await waitFor(step, 12000)) return true;
    if (fallback[step]) { location.assign(fallback[step]); return 'reload'; }
    return false;
  }
  async function crawl() {
    if (running) return;
    running = true; stopFlag = false;
    clearInterval(beat);
    beat = setInterval(async () => { const p = (await get(PLAN))[PLAN]; if (p) { p.at = Date.now(); set({ [PLAN]: p }); } }, 6000);
    let reloading = false;
    try {
      for (;;) {
        let plan = (await get(PLAN))[PLAN];
        if (!plan || !plan.crawl || stopFlag || plan.stop || Date.now() - plan.startedAt > 45 * 60000) break;
        const step = plan.steps[plan.idx];
        if (!step) break;
        await settle();
        collectLinks(plan);
        if (!onStep(step)) {
          plan.tries = plan.tries || {};
          plan.tries[step] = (plan.tries[step] || 0) + 1;
          if (plan.tries[step] > 2) { plan.skipped = (plan.skipped || []).concat(step); plan.idx++; await set({ [PLAN]: plan }); continue; }
          await set({ [PLAN]: plan });
          await set({ [PROGRESS]: { state: 'running', page: step, step: plan.idx + 1, steps: plan.steps.length, done: 0, total: 0, note: 'Going to the ' + step + ' page' } });
          const r = await goTo(step, plan);
          if (r === 'reload') { reloading = true; return; }
          if (!r) { plan.skipped = (plan.skipped || []).concat(step); plan.idx++; await set({ [PLAN]: plan }); continue; }
          await settle();
          collectLinks(plan);
        }
        const b = (await get(BACKUP))[BACKUP];
        await testPage(b ? b.orig : {}, { step: plan.idx + 1, steps: plan.steps.length });
        plan = (await get(PLAN))[PLAN];
        if (!plan) break;
        collectLinks(plan);
        plan.idx++;
        await set({ [PLAN]: plan });
      }
      const plan = (await get(PLAN))[PLAN];
      await restoreBackup(true);
      await remove(PLAN);
      await set({ [PROGRESS]: { state: 'done', crawl: true, skipped: (plan && plan.skipped) || [], stopped: stopFlag } });
    } catch (e) {
      await restoreBackup(true); await remove(PLAN);
      await set({ [PROGRESS]: { state: 'done', crawl: true, error: String(e && e.message) } });
    } finally {
      if (!reloading) { clearInterval(beat); running = false; }
    }
  }
  async function startCrawl() {
    if (running) return;
    await snapshot();
    await remove([RESULT]);
    await set({ [PLAN]: { crawl: true, steps: STEPS.slice(), idx: 0, links: {}, tries: {}, at: Date.now(), startedAt: Date.now() } });
    crawl();
  }
  // After a full reload (the fallback when clicking did not work) pick up where the crawl was.
  (async () => {
    const plan = (await get(PLAN))[PLAN];
    if (plan && plan.crawl && !plan.stop && Date.now() - plan.at < 20000) crawl();
  })();

  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (!msg) return false;
    if (msg.type === 'RT_SELFTEST_RUN') { singleRun(); reply({ started: true }); }
    else if (msg.type === 'RT_SELFTEST_CRAWL') { startCrawl(); reply({ started: true }); }
    else if (msg.type === 'RT_SELFTEST_STOP') { stopFlag = true; get(PLAN).then((s) => { if (s[PLAN]) { s[PLAN].stop = true; set({ [PLAN]: s[PLAN] }); } }); reply({ stopped: true }); }
    return false;
  });
})();
