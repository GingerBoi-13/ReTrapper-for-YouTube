// Bug report page (reached from the gear). Same collector as the ReTrapper Bug Report companion.
(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const msg = (t, err) => { $('brMsg').textContent = t; $('brMsg').className = err ? 'err' : ''; };
  let tab = null, lastReport = '';
  const KEY = 'rtBugReportOptions', EMAIL_KEY = 'rtBugReportEmail', DEV_EMAIL = 'retrapper.skyward225@passmail.net';
  const BOXES = { brMask: 'mask', brMarkup: 'markup', brLookups: 'lookups' };
  const ids = Object.keys(BOXES);
  try {
    const saved = JSON.parse(localStorage.getItem(KEY) || '{}');
    ids.forEach((id) => { if (typeof saved[BOXES[id]] === 'boolean') $(id).checked = saved[BOXES[id]]; });
    $('brEmail').value = localStorage.getItem(EMAIL_KEY) || '';
  } catch (e) { /* ignore */ }
  const showSend = (on) => { $('brSend').hidden = !on; $('brSendNote').hidden = !on; };
  ids.forEach((id) => $(id).addEventListener('change', () => {
    showSend(false);
    try { localStorage.setItem(KEY, JSON.stringify(Object.fromEntries(ids.map((b) => [BOXES[b], $(b).checked])))); } catch (e) { /* ignore */ }
  }));
  $('brNote').addEventListener('input', () => showSend(false));
  $('brEmail').addEventListener('input', () => { try { localStorage.setItem(EMAIL_KEY, $('brEmail').value.trim()); } catch (e) { /* ignore */ } });

  function refresh() {
    msg(''); $('brOut').style.display = 'none';
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      tab = tabs && tabs[0];
      const ok = tab && /^https:\/\/www\.youtube\.com\//.test(tab.url || '');
      ['brCopy', 'brSave', 'brView'].forEach((id) => { $(id).disabled = !ok; });
      $('brWhere').textContent = ok ? 'Describe the problem, then copy or save the report and send it to the developer.'
        : 'This only works on a YouTube page. Open the page with the problem, then open this page again.';
    });
  }
  window.RTReport = { refresh };

  async function generate() {
    if (!tab) throw new Error('No YouTube tab');
    const opts = { note: $('brNote').value.trim(), mask: $('brMask').checked, markup: $('brMarkup').checked, lookups: $('brLookups').checked };
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', files: ['report.js'] });
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', args: [opts], func: (o) => window.__rtBugReportBuild(o) });
    if (!res || typeof res.result !== 'string') throw new Error('No report returned');
    return res.result;
  }
  async function run(fn) {
    msg('Collecting...');
    try { await fn(await generate()); } catch (e) { msg('Failed: ' + (e && e.message || e), true); }
  }
  $('brCopy').onclick = () => run(async (t) => {
    lastReport = t;
    try { await navigator.clipboard.writeText(t); msg('Copied to clipboard. Press Send To Developer, or paste it wherever you like.'); }
    catch (e) { const o = $('brOut'); o.style.display = 'block'; o.value = t; o.select(); msg('Select all in the box below and copy it, then press Send To Developer.'); }
    showSend(true);
  });
  $('brSave').onclick = () => run((t) => {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([t], { type: 'application/json' })); a.download = 'retrapper-bug-report.json';
    document.body.appendChild(a); a.click(); a.remove(); msg('Saved retrapper-bug-report.json');
  });
  $('brView').onclick = () => run((t) => { const o = $('brOut'); o.style.display = 'block'; o.value = t; msg(''); });
  $('brSend').onclick = async () => {
    const email = $('brEmail').value.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { msg('Add your email above so the developer can reply.', true); $('brEmail').focus(); return; }
    try { await navigator.clipboard.writeText(lastReport); } catch (e) { /* the box below still holds the report */ }
    const note = $('brNote').value.trim().slice(0, 700);
    const body = 'Reply to: ' + email + '\n\n' + (note ? 'What happened:\n' + note + '\n\n' : '') +
      'Paste the report below this line (it is already copied: press Ctrl+V, or Cmd+V on a Mac):\n\n';
    const a = document.createElement('a');
    a.href = 'mailto:' + DEV_EMAIL + '?subject=' + encodeURIComponent('ReTrapper bug report') + '&body=' + encodeURIComponent(body);
    document.body.appendChild(a); a.click(); a.remove();
    msg('Your mail app should open. Paste the report into the message and press Send.');
  };

  // @selftest-begin
  // ---- self-test (runs in the YouTube page, see selftest.js) ----------------------------------------
  const RESULT = 'rtSelfTestResult', PROGRESS = 'rtSelfTestProgress';
  const OK = new Set(['applied', 'hides it', 'nothing here to hide']);
  const stMsg = (t) => { $('stMsg').textContent = t; };
  function showResults(res) {
    const out = $('stOut'); out.textContent = '';
    if (!res || !res.pages) { $('stCopy').hidden = true; return; }
    $('stCopy').hidden = false;
    Object.keys(res.pages).forEach((pg) => {
      const d = res.pages[pg], rows = d.results || [];
      const bad = rows.filter((r) => !OK.has(r.status));
      const hid = rows.filter((r) => r.status === 'hides it').length, none = rows.filter((r) => r.status === 'nothing here to hide').length;
      const head = document.createElement('div'); head.className = 'row2';
      head.textContent = pg + ' page: ' + rows.length + ' options tested, ' + bad.length + ' problem' + (bad.length === 1 ? '' : 's') + ' (' + hid + ' confirmed hiding, ' + none + ' had nothing to hide here).';
      out.appendChild(head);
      bad.slice(0, 40).forEach((r) => { const l = document.createElement('div'); l.className = 'row2 bad'; l.textContent = r.id + ': ' + r.status + (r.errors ? ' - ' + r.errors.join(' | ') : ''); out.appendChild(l); });
    });
  }
  function refreshSelfTest() {
    chrome.storage.local.get([RESULT, PROGRESS], (st) => {
      const p = st[PROGRESS];
      if (p && p.state === 'running') stMsg('Running on the ' + p.page + ' page: ' + p.done + ' of ' + p.total + '. Leave the page alone.');
      else if (p && p.state === 'done' && p.crawl) stMsg('Done. Went through every page. Your settings were put back.');
      else if (p && p.state === 'done') stMsg('Done. Tested ' + p.total + ' options on the ' + p.page + ' page. Your settings were put back.');
      else if (p && p.state === 'restored') stMsg(p.note);
      showResults(st[RESULT]);
    });
  }
  chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && (ch[PROGRESS] || ch[RESULT])) refreshSelfTest(); });
  const baseRefresh = window.RTReport.refresh;
  window.RTReport.refresh = () => { baseRefresh(); refreshSelfTest(); };
  $('stFull').onclick = () => { chrome.tabs.create({ url: chrome.runtime.getURL('selftest.html') }); };
  $('stRun').onclick = () => {
    if (!tab) { stMsg('Open a YouTube page first.'); return; }
    stMsg('Starting...');
    chrome.tabs.sendMessage(tab.id, { type: 'RT_SELFTEST_RUN' }, (r) => {
      if (chrome.runtime.lastError || !r) stMsg('Could not reach the page. Reload the YouTube tab and try again.');
    });
  };
  $('stCopy').onclick = () => {
    chrome.storage.local.get(RESULT, async (st) => {
      const res = st[RESULT]; if (!res) return;
      const compact = { version: res.version, userAgent: res.userAgent, pages: {} };
      Object.keys(res.pages).forEach((pg) => { const rows = res.pages[pg].results; compact.pages[pg] = { tested: rows.length, problems: rows.filter((r) => !OK.has(r.status)), all: rows.map((r) => r.id + ':' + r.status) }; });
      const t = JSON.stringify(compact, null, 1);
      try { await navigator.clipboard.writeText(t); stMsg('Results copied. Paste them into the chat.'); } catch (e) { const o = $('brOut'); o.style.display = 'block'; o.value = t; o.select(); stMsg('Select all in the box above and copy it.'); }
    });
  };
  // @selftest-end
})();
